sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/viz/ui5/controls/VizFrame"
], function (Controller,VizFrame) {
	"use strict";

	return Controller.extend("com.ramesh.zLineCharts4.controller.ViewOne", {
		
		displayDetail : function(oEvent){
			var selectedChart = oEvent.getSource().getId();
				
				if (!this.chartDialog) {
				this.chartDialog = new sap.m.Dialog({
					contentWidth : "1300px",
					contentHeight : "900px",
					title: "Chart Detail",
					beginButton: new sap.m.Button({
						text: "Close",
						press: function () {
							this.chartDialog.close();
						}.bind(this)
					})
				});
			var frame=	new VizFrame({id:"idVizFrameDialog" , height:"600px", width:"1300px", vizType:"line"});
							this.chartDialog.addContent(frame);
			//this.fillChart(sap.ui.getCore().getModel("dataCollection").getProperty("/data"),"idVizFrameDialog","12 Months");
			
				//to get access to the global model
				this.getView().addDependent(this.chartDialog);
				
			}
		
					   if(selectedChart ==  "__xmlview0--firstFrameBtn"){
					       	this.fillChart(sap.ui.getCore().getModel("dataCollection").getProperty("/data"),"idVizFrameDialog","12 Months");
					   }
					   else  if(selectedChart ==  "__xmlview0--secondFrameBtn"){
					   
					      	this.fillChart(sap.ui.getCore().getModel("dataCollection").getProperty("/data"),"idVizFrameDialog","16 Months");
					   }
					    else  if(selectedChart ==  "__xmlview0--thirdFrameBtn"){
					       	this.fillChart(sap.ui.getCore().getModel("dataCollection").getProperty("/data"),"idVizFrameDialog","20 Months");
					    }
					    else if ( selectedChart ==  "__xmlview0--fourthFrameBtn"){
					       	this.fillChart(sap.ui.getCore().getModel("dataCollection").getProperty("/data"),"idVizFrameDialog","24 Months");
					    }
					  
				
			
			
				
			this.chartDialog.open();
		},
		onInit : function(){
		
			 var dataModel = new sap.ui.model.json.JSONModel();
        	 dataModel.loadData("./model/ExpPlotChassis24JSON.json","",false);
        	  var data = dataModel.getProperty("/d/results");
        
        	  var yearsAarry = ["2013","2014","2015","2016","2017"];
        	  
        	  var allObj = [];
        	  var data12 = [];
        	  var data16 = [];
        	  var data20 = [];
        	   for(var count = 0 ; count < 24; count++){
        	   	var obj = {};
        	   		obj.MIS = data[count].MIS;
	        	   	for(var yearVal = 0; yearVal < yearsAarry.length;yearVal++){
	        	   		obj[["Year_" +yearsAarry[yearVal]]] = data[count+(24*yearVal)].EW_PER_UNIT;
	        			/*obj[yearsAarry[1]] = data[count+(24*1)].EW_PER_UNIT;
	        			obj[yearsAarry[2]] = data[count+(24*2)].EW_PER_UNIT;
	        	   		obj[yearsAarry[3]] = data[count+(24*3)].EW_PER_UNIT;
	        	  		obj[yearsAarry[4]] = data[count+(24*4)].EW_PER_UNIT;*/
	        	   	}
        	   	allObj.push(obj);
        	   	if(count <20){
        	   		data20.push(obj);
        	   	}
        	   		if(count <12){
        	   				data12.push(obj);
        	   			}
        	   		if(count < 16){
        	   		data16.push(obj);
        	   		}
        	   }
        	//   console.log(allObj);
        	   this.fillChart(data12,"idVizFrameOne","12 Months");
        	   this.fillChart(data16,"idVizFrameTwo","16 Months");
        	     this.fillChart(data20,"idVizFrameThree","20 Months");
        	   this.fillChart(allObj,"idVizFrameFour","24 Months");
        	   	var dataCollectionModel = new sap.ui.model.json.JSONModel();
        	dataCollectionModel.setData({data:allObj});
        	sap.ui.getCore().setModel(dataCollectionModel, "dataCollection");
        	
		},
/* getChartData : function(range){
        	 var dataModel = new sap.ui.model.json.JSONModel();
        	 dataModel.loadData("./model/data.json","",false);
        	 var data = dataModel.getProperty("/data");
        	 var finalData = [];
        	 var total = data.length;
        	 var step = parseInt(total / range,10) * 4;
        	var stepObj={"60":4,"48":3,"36":3,"24":2};
        	 var i = total - 1;
        	 var minVal = range;
        	 var count = 0;
        	while(i >= 0){
        			finalData.push(data[i]);
        			count ++;
        			i--;
        			if(count >= range){
        				break;
        			}
        	}
        	 
        	 
        	 return finalData.reverse();
        	 
        },*/

	fillChart : function(monthData,chartId, chartTitle){
		
        	 
    	//	var monthData =	 this.getChartData(24);
    	//	console.log(monthData);
        	var LineChartOne=this.getView().byId(chartId) || sap.ui.getCore().getElementById(chartId);
        	var dataModel = new sap.ui.model.json.JSONModel();
        	dataModel.setData({data:monthData});
            LineChartOne.setModel(dataModel);
			LineChartOne.setUiConfig({
				"applicationSet": "fiori"
			});
			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					axis: 1,
					name: 'MIS',
					value: '{MIS}'
				}],
				measures: [
					{
					name: 'Year_2013',
					value: '{Year_2013}'
					},
					{
					name: 'Year_2014',
					value: '{Year_2014}'
					},
					{
					name: 'Year_2015',
					value: '{Year_2015}'
					},
					{
					name: 'Year_2016',
					value: '{Year_2016}'
					},
					{
					name: 'Year_2017',
					value: '{Year_2017}'
					}
					],
				data: {
					path: '/data'
						// Filter: "oFilters"
				}
			});
			LineChartOne.setDataset(oDataset);


	var dimentionFeed = new sap.viz.ui5.controls.common.feeds.FeedItem({
				    'uid': "categoryAxis",
			//	   'id' :"categoryAxisFeed",
					'type': "Dimension",
					'values': ["MIS"]
				});
	/*		var valueFeed = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Year_2013","Year_2014","Year_2015","Year_2016","Year_2017"]
				});*/
			var valueFeed1 = new sap.viz.ui5.controls.common.feeds.FeedItem({
				//	'id' :"valueAxisFeed1",
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Year_2013"]
				});
					var valueFeed2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
				//	'id' :"valueAxisFeed2",
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Year_2014"]
				});
					var valueFeed3 = new sap.viz.ui5.controls.common.feeds.FeedItem({
				//	'id' :"valueAxisFeed3",
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Year_2015"]
				});
					var valueFeed4 = new sap.viz.ui5.controls.common.feeds.FeedItem({
				//			'id' :"valueAxisFeed4",
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Year_2016"]
				});
					var valueFeed5 = new sap.viz.ui5.controls.common.feeds.FeedItem({
				//			'id' :"valueAxisFeed5",
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Year_2017"]
				});
				LineChartOne.destroyFeeds();
			LineChartOne.addFeed(valueFeed1);
				LineChartOne.addFeed(valueFeed2);
					LineChartOne.addFeed(valueFeed3);
						LineChartOne.addFeed(valueFeed4);
							LineChartOne.addFeed(valueFeed5);
		
			LineChartOne.addFeed(dimentionFeed);
			
			LineChartOne.setVizProperties({
				dataLabel: {
                    visible: true
                },
				legend: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text : chartTitle
				},
				valueAxis: {

					title: {
						visible: true,
						text: "EW_PER_UNIT Cost" //Add custom title to Value Axis  
					}
				}
			});	
        
	}
	});
});
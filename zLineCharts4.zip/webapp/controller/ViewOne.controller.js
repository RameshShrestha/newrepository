sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.ramesh.zLineCharts4.controller.ViewOne", {
		onInit : function(){
		
			 var dataModel = new sap.ui.model.json.JSONModel();
        	 dataModel.loadData("./model/ExpPlotChassis24JSON.json","",false);
        	  var data = dataModel.getProperty("/d/results");
        
        	  var yearsAarry = ["2013","2014","2015","2016","2017"];
        	  
        	  var allObj = [];
        	   for(var count = 0 ; count < 24; count++){
        	   	var obj = {};
        	   		obj.MIS = data[count].MIS;
	        	   	for(var yearVal = 0; yearVal < yearsAarry.length;yearVal++){
	        	   		obj[["Year_" +yearsAarry[yearVal]]] = data[count+(24*yearVal)].EW_PER_UNIT;
	        			/*obj[yearsAarry[1]] = data[count+(24*1)].EW_PER_UNIT;
	        			obj[yearsAarry[2]] = data[count+(24*2)].EW_PER_UNIT;
	        	   		obj[yearsAarry[3]] = data[count+(24*3)].EW_PER_UNIT;
	        	  		obj[yearsAarry[4]] = data[count+(24*4)].EW_PER_UNIT;*/
	        	   	}
        	   	allObj.push(obj);
        	   }
        	//   console.log(allObj);
        	   this.fillChart(allObj,"idVizFrameOne");
        	   this.fillChart(allObj,"idVizFrameTwo");
        	     this.fillChart(allObj,"idVizFrameThree");
        	   this.fillChart(allObj,"idVizFrameFour");
        	
		},
/* getChartData : function(range){
        	 var dataModel = new sap.ui.model.json.JSONModel();
        	 dataModel.loadData("./model/data.json","",false);
        	 var data = dataModel.getProperty("/data");
        	 var finalData = [];
        	 var total = data.length;
        	 var step = parseInt(total / range,10) * 4;
        	var stepObj={"60":4,"48":3,"36":3,"24":2};
        	 var i = total - 1;
        	 var minVal = range;
        	 var count = 0;
        	while(i >= 0){
        			finalData.push(data[i]);
        			count ++;
        			i--;
        			if(count >= range){
        				break;
        			}
        	}
        	 
        	 
        	 return finalData.reverse();
        	 
        },*/

	fillChart : function(monthData,chartId){
		
        	 
    	//	var monthData =	 this.getChartData(24);
    	//	console.log(monthData);
        	var LineChartOne=this.getView().byId(chartId);
        	var dataModel = new sap.ui.model.json.JSONModel();
        	dataModel.setData({data:monthData});
            LineChartOne.setModel(dataModel);
			LineChartOne.setUiConfig({
				"applicationSet": "fiori"
			});
			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					axis: 1,
					name: 'MIS',
					value: '{MIS}'
				}],
				measures: [
					{
					name: 'Year_2013',
					value: '{Year_2013}'
					},
					{
					name: 'Year_2014',
					value: '{Year_2014}'
					},
					{
					name: 'Year_2015',
					value: '{Year_2015}'
					},
					{
					name: 'Year_2016',
					value: '{Year_2016}'
					},
					{
					name: 'Year_2017',
					value: '{Year_2017}'
					}
					],
				data: {
					path: '/data'
						// Filter: "oFilters"
				}
			});
			LineChartOne.setDataset(oDataset);


/*	var dimentionFeed = new sap.viz.ui5.controls.common.feeds.FeedItem({
				    'uid': "categoryAxis",
				   'id' :"categoryAxisFeed",
					'type': "Dimension",
					'values': ["MIS"]
				});
			var valueFeed = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "size",
					'type': "Measure",
					'values': ["Year_2013","Year_2014","Year_2015","Year_2016","Year_2017"]
				});
		
			LineChartOne.addFeed(valueFeed);
			LineChartOne.addFeed(dimentionFeed);*/
			
			LineChartOne.setVizProperties({
				dataLabel: {
                    visible: true
                },
				legend: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text : "24 Months"
				},
				valueAxis: {

					title: {
						visible: true,
						text: "EW_PER_UNIT Cost" //Add custom title to Value Axis  
					}
				}
			});	
        
	}
	});
});
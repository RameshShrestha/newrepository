sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.costCurvezCostCurve.controller.MainView", {
		onInit : function(){
			
		
				 var dataModel = new sap.ui.model.json.JSONModel();
        			 dataModel.loadData("./model/tempdata.json","",false);
        		this.getView().byId("CostCurveTable").setModel(dataModel);
        	var	oView = this.getView();
        					oView.byId("multiHeader36").setHeaderSpan([4,1]);
							oView.byId("multiHeader48").setHeaderSpan([4,1]);
							oView.byId("multiHeader60").setHeaderSpan([4,1]);
							oView.byId("multiHeader72").setHeaderSpan([4,1]);
        		
        		
		},
		checkIconVisible : function(code){
			if(code == "Y"){
				return true;
			}else{
				return false;
			}
		}

	});
});
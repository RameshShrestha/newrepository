sap.ui.define([], function () {
	"use strict";
	return {
		AUFFactorValue: function (value) {
			if(value){
			    value = value + " %";
			    return value;
			}
			else{
			    return "";
			}
		},
		
		costCurveTitleDisplay: function(value){
		    
		  	if(value){
			    ;
			    return value;
			}
			else{
			    
			   value =  this.getView().getModel("local").getData().CostCurveViewRatePlan.CVRG_GROUP;
			    return value;
			}
		}
	};
});
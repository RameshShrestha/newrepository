sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/m/MessageBox",
	"sap/viz/ui5/controls/Popover",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	"sap/m/MessageToast",
	"DtnaAspRP_ss/model/formatter",
	"sap/m/Dialog",
	"sap/m/Text",
	"sap/m/Button"

], function(Controller, ChartFormatter, MessageBox, Popover, Filter, FilterOperator, MessageToast, formatter, Dialog, Text, Button) {
	"use strict";

	return Controller.extend("DtnaAspRP_ss.controller.CostCurveChassis", {
		formatter: formatter,
		onInit: function() {
			this.router = this.getOwnerComponent().getRouter();
			var json = new sap.ui.model.json.JSONModel(jQuery.sap.getModulePath("DtnaAspRP_ss.model", "/testmodel.json"));
			this.getView().setModel(json);

			this._Fragments = [];

			this.router.getRoute("CostCurveChassis").attachPatternMatched(this._onRouteObjectMatched, this);
		},

		_onRouteObjectMatched: function() {
			sap.ui.core.BusyIndicator.hide();
		},

		onAfterRendering: function() {

		},
		_showFormFragment: function(view, sFragmentname, vizId) {

			var controller = view.getController();
			var dialog = controller._Fragments[sFragmentname]
			if (!dialog) {

				dialog = sap.ui.xmlfragment(view.getId(), "DtnaAspRP_ss.Fragment." + sFragmentname, this);
				controller._Fragments[sFragmentname] = dialog;
				view.addDependent(dialog);

				//add tooltip

				if (vizId) {
					new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId(vizId).getVizUid());
				}
			}

			if (sFragmentname == "CostCurveChassisStatus") {
				view.byId("multiheader").setHeaderSpan([4, 1]);
			}
			dialog.open();

		},

		_hideFormFragment: function(controller, sFragmentname) {

			//var controller = view.getController();
			var dialog = controller._Fragments[sFragmentname]
			if (dialog) {

				dialog.close();
			}
			// 			sap.ui.core.BusyIndicator.hide();
			// 			alert("forecast saved");

		},

		onRatePlanPopover: function(oEvent) {

			var dialog = this._Fragments["ratePlanInfoPopover"]
			if (!dialog) {

				dialog = sap.ui.xmlfragment(this.getView().getId(), "DtnaAspRP_ss.Fragment." + "ratePlanInfoPopover", this);
				this._Fragments["ratePlanInfoPopover"] = dialog;
				this.getView().addDependent(dialog);
			}
			dialog.openBy(oEvent.getSource());

		},
		/*_getAUFValue: function(months, viewController) {
			var mParameters = {
				success: function(oData) {
					alert("success");

					that.getView().getModel("local").getData().AUFValue = oData.results;

				},
				error: function(oError) {
					alert("error");

				}

			};
			viewController.getOwnerComponent().getModel().read("/CV_TF_COST_CURVE_AUFParameters(parIN_SRVC_YR=" + viewController.getView().getModel(
					"local").getProperty(
					"/ViewRatePlan/BASELINE_YEAR") + ",parVOC_CATEGORY='" + viewController.getView().byId(
					"vocation").getValue().toUpperCase() + "',parPRODUCT_TYPE='" + viewController.getView().getModel("local").getProperty(
					"/ViewRatePlan/PRODUCT_TYPE") + "',parPRD_TYP_CD='" + viewController.getView().getModel("local").getProperty(
					"/ViewRatePlan/PORTFOLIO_NAME") +
				"',parDATE=datetime'" + viewController.getView().getModel("local").getProperty(
					"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "',parCVRG_MONTHS=" + months + ",parDOMCL_CNTRY_CD='" + viewController.getView().byId(
					"domicile")
				.getSelectedItem().getKey() + "',parRATE_PLAN_ID=" + viewController.getView().getModel("local").getProperty(
					"/ViewRatePlan/RATE_PLAN_ID") + ",parDEDUCT_AMT=0,parCVRG_GROUP='" + viewController.getView().byId("coverage").getValue() +
				"',parTORQUE='')/Execute", mParameters);
		},*/

		generateCostcurve: function() {
			var that = this;
			if (this.getView().byId("vocation").getValue().length == 0 || this.getView().byId("coverage").getValue().length == 0 || this.getView()
				.byId("domicile").getValue() == 0) {

				sap.m.MessageBox.error("Please Enter/Select Vocation, Domicile and Coverage");
			} else {
				//popover
				for (var i = 1; i <= 4; i++) {
					new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrame" + i).getVizUid());
				}
				//end of popover

				this.getView().byId("idVizFrame1").addEventDelegate({

					onclick: function(oEvent) {

						var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
						that._showFormFragment(that.getView(), "ChassisChart24months", "vizChart24");
						that._GetMilegeData(24);
						that.getView().getModel("local").getData().AUFValue = [];
						that.getView().byId("auffactor24").setBusy(true);
						/*get the AUF value*/
						var mParameters = {
							success: function(oData) {
								var data = [];
								for (var i = 0; i < oData.results.length; i++) {

									data[oData.results[i].GROUP_ID] = oData.results[i];
								}
								that.getView().getModel("local").getData().AUFValue = data;

								that.getView().byId("auffactor24").setBusy(false);
							},
							error: function(oError) {

								that.getView().byId("auffactor24").setBusy(false);
								sap.m.MessageBox.error(oError.responseText);
							}

						};

						//parameterized
						that.getOwnerComponent().getModel().read("/CV_TF_COST_CURVE_AUFParameters(parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/BASELINE_YEAR") + ",parVOC_CATEGORY='" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "',parPRODUCT_TYPE='" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "',parPRD_TYP_CD='" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "',parDATE=datetime'" + that.getView().getModel(
								"local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT") +
							"',parCVRG_MONTHS=24,parDOMCL_CNTRY_CD='" + that._CountryCode() + "',parRATE_PLAN_ID=" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID") + ",parDEDUCT_AMT=0,parCVRG_GROUP='" + that.getView()
							.byId("coverage").getValue() +
							"',parTORQUE='')/Execute", mParameters);
						/*end of get AUF Value*/

					}
				});

				this.getView().byId("idVizFrame2").addEventDelegate({

					onclick: function(oEvent) {

						var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
						that._showFormFragment(that.getView(), "ChassisChart36months", "vizChart36");
						that._GetMilegeData(36);
						that.getView().getModel("local").getData().AUFValue = [];
						that.getView().byId("auffactor36").setBusy(true);

						var mParameters = {
							success: function(oData) {
								var data = [];
								for (var i = 0; i < oData.results.length; i++) {

									data[oData.results[i].GROUP_ID] = oData.results[i];
								}
								that.getView().getModel("local").getData().AUFValue = data;
								that.getView().byId("auffactor36").setBusy(false);

							},
							error: function(oError) {
								that.getView().byId("auffactor36").setBusy(false);
								sap.m.MessageBox.error(oError.responseText);

							}

						};
						//parameterized
						view.getController().getOwnerComponent().getModel().read("/CV_TF_COST_CURVE_AUFParameters(parIN_SRVC_YR=" + that.getView().getModel(
								"local").getProperty("/ViewRatePlan/BASELINE_YEAR") + ",parVOC_CATEGORY='" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "',parPRODUCT_TYPE='" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "',parPRD_TYP_CD='" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "',parDATE=datetime'" + that.getView().getModel(
								"local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT") +
							"',parCVRG_MONTHS=36,parDOMCL_CNTRY_CD='" + that._CountryCode() + "',parRATE_PLAN_ID=" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID") + ",parDEDUCT_AMT=0,parCVRG_GROUP='" + that.getView()
							.byId("coverage").getValue() +
							"',parTORQUE='')/Execute", mParameters);

					}
				});

				this.getView().byId("idVizFrame3").addEventDelegate({
					onclick: function(oEvent) {
						var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
						that._showFormFragment(that.getView(), "ChassisChart48months", "vizChart48");
						that._GetMilegeData(48);
						that.getView().getModel("local").getData().AUFValue = [];
						that.getView().byId("auffactor48").setBusy(true);

						var mParameters = {
							success: function(oData) {
								//	alert("success");

								var data = [];
								for (var i = 0; i < oData.results.length; i++) {

									data[oData.results[i].GROUP_ID] = oData.results[i];
								}
								that.getView().getModel("local").getData().AUFValue = data;
								that.getView().byId("auffactor48").setBusy(false);

							},
							error: function(oError) {
								that.getView().byId("auffactor48").setBusy(false);
								sap.m.MessageBox.error(oError.responseText);

							}

						};
						//parameterized
						view.getController().getOwnerComponent().getModel().read("/CV_TF_COST_CURVE_AUFParameters(parIN_SRVC_YR=" + that.getView().getModel(
								"local").getProperty("/ViewRatePlan/BASELINE_YEAR") + ",parVOC_CATEGORY='" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "',parPRODUCT_TYPE='" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "',parPRD_TYP_CD='" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "',parDATE=datetime'" + that.getView().getModel(
								"local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT") +
							"',parCVRG_MONTHS=48,parDOMCL_CNTRY_CD='" + that._CountryCode() + "',parRATE_PLAN_ID=" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID") + ",parDEDUCT_AMT=0,parCVRG_GROUP='" + that.getView()
							.byId("coverage").getValue() +
							"',parTORQUE='')/Execute", mParameters);

					}
				});
				this.getView().byId("idVizFrame4").addEventDelegate({
					onclick: function(oEvent) {

						var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
						that._showFormFragment(that.getView(), "ChassisChart60months", "vizChart60");
						that._GetMilegeData(60);
						that.getView().getModel("local").getData().AUFValue = [];
						that.getView().byId("auffactor60").setBusy(true);

						/*get the AUF value*/

						var mParameters = {
							success: function(oData) {

								var data = [];
								for (var i = 0; i < oData.results.length; i++) {

									data[oData.results[i].GROUP_ID] = oData.results[i];
								}
								that.getView().getModel("local").getData().AUFValue = data;
								that.getView().byId("auffactor60").setBusy(false);

							},
							error: function(oError) {
								that.getView().byId("auffactor60").setBusy(false);
								sap.m.MessageBox.error(oError.responseText);

							}

						};
						//parameterized
						view.getController().getOwnerComponent().getModel().read("/CV_TF_COST_CURVE_AUFParameters(parIN_SRVC_YR=" + that.getView().getModel(
								"local").getProperty("/ViewRatePlan/BASELINE_YEAR") + ",parVOC_CATEGORY='" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "',parPRODUCT_TYPE='" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "',parPRD_TYP_CD='" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "',parDATE=datetime'" + that.getView().getModel(
								"local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT") +
							"',parCVRG_MONTHS=60,parDOMCL_CNTRY_CD='" + that._CountryCode() + "',parRATE_PLAN_ID=" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID") + ",parDEDUCT_AMT=0,parCVRG_GROUP='" + that.getView()
							.byId("coverage").getValue() +
							"',parTORQUE='')/Execute", mParameters);

					}
				});

				this._GetcostCurveValue("24M");
				this._GetcostCurveValue("36M");
				this._GetcostCurveValue("48M");
				this._GetcostCurveValue("60M");

			}

		},

		RefreshMinMax36: function() {

			if (this.getView().byId("max36").getValue() > this.getView().byId("min36").getValue()) {

				var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
				var that = this;
				//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
				var newDate = new Date();
				var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
				var currentUser = this.getView().getModel("UserInfo").getData().userName;

				var insertData = {
					RATE_PLAN_ID: parseInt(this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
					VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
					CVRG_GROUP: this.getView().byId("coverage").getValue(),
					ENGINE_TORQUE: " ",
					DEDUCT_AMT: 0,
					DOMCL_CNTRY_CD_GRP: this._CountryCode(),
					CVRG_MONTHS: 36,
					MIN_MIS: parseInt(this.getView().byId("min36").getValue()),
					MAX_MIS: parseInt(this.getView().byId("max36").getValue()),
					SELECTED_FCST_MTHD: " ",
					CREATED_DATE: createdDate,
					CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
					MODIFIED_DATE: currentDate,
					MODIFIED_USER: currentUser
				};

				var newData = JSON.stringify(insertData);
				jQuery.ajax({

					url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
					type: "POST",
					async: false,
					method: 'GET',
					dataType: 'text',
					data: {
						dataObject: newData
					},
					success: function(data) {

						//alert("success");
						var mParameters = {

							success: function(oData) {
								sap.ui.core.BusyIndicator.hide();
								that.getView().getModel("local").getData().Overlay36 = oData.results;
								that.getView().byId("vizChart36").getDataset().bindData("local>/Overlay36");

							},
							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();

							}
						};

						sap.ui.core.BusyIndicator.show();
						that.getOwnerComponent().getModel().read(
							"/CV_COST_CURVE_FINALParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" +
							"'" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=36M" + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel("local")
							.getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE=''" + "," + "parDOMCL_CNTRY_CD=" + "'" + that._CountryCode() + "'," +
							"parDEDUCT_AMT=0" + "," + "parRATE_PLAN_ID=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute",
							mParameters);
					},

					error: function(error) {

					}

				});

			} else {
				sap.m.MessageBox.error("MIN should be less than MAX ");
			}

		},

		RefreshMinMax24: function() {

			if (this.getView().byId("maxinput24").getValue() > this.getView().byId("mininput24").getValue()) {

				var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
				var that = this;
				var newDate = new Date();
				var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
				var currentUser = this.getView().getModel("UserInfo").getData().userName;

				var insertData = {
					RATE_PLAN_ID: parseInt(this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
					VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
					CVRG_GROUP: this.getView().byId("coverage").getValue(),
					ENGINE_TORQUE: " ",
					DEDUCT_AMT: 0,
					DOMCL_CNTRY_CD_GRP: this._CountryCode(),
					CVRG_MONTHS: 24,
					MIN_MIS: parseInt(this.getView().byId("mininput24").getValue()),
					MAX_MIS: parseInt(this.getView().byId("maxinput24").getValue()),
					SELECTED_FCST_MTHD: " ",
					CREATED_DATE: createdDate,
					CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
					MODIFIED_DATE: currentDate,
					MODIFIED_USER: currentUser
				};

				var newData = JSON.stringify(insertData);
				jQuery.ajax({

					url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
					type: "POST",
					async: false,
					method: 'GET',
					dataType: 'text',
					data: {
						dataObject: newData
					},
					success: function(data) {

						//alert("success");
						var mParameters = {

							success: function(oData) {
								sap.ui.core.BusyIndicator.hide();
								that.getView().getModel("local").getData().Overlay24 = oData.results;
								that.getView().byId("vizChart24").getDataset().bindData("local>/Overlay24");

							},
							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();

							}
						};

						sap.ui.core.BusyIndicator.show();
						that.getOwnerComponent().getModel().read(
							"/CV_COST_CURVE_FINALParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" +
							"'" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=24M" + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel("local")
							.getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE=''" + "," + "parDOMCL_CNTRY_CD=" + "'" + that._CountryCode() + "'," +
							"parDEDUCT_AMT=0" + "," + "parRATE_PLAN_ID=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute",
							mParameters);

					},

					error: function(error) {

					}

				});
			} else {
				sap.m.MessageBox.error("MIN should be less than MAX ");
			}
		},

		RefreshMinMax48: function() {
			if (this.getView().byId("maxinput48").getValue() > this.getView().byId("mininput48").getValue()) {

				var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
				//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
				var that = this;

				var newDate = new Date();
				var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
				var currentUser = this.getView().getModel("UserInfo").getData().userName;

				var insertData = {
					RATE_PLAN_ID: parseInt(this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
					VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
					CVRG_GROUP: this.getView().byId("coverage").getValue(),
					ENGINE_TORQUE: " ",
					DEDUCT_AMT: 0,
					DOMCL_CNTRY_CD_GRP: this._CountryCode(),
					CVRG_MONTHS: 48,
					MIN_MIS: parseInt(this.getView().byId("mininput48").getValue()),
					MAX_MIS: parseInt(this.getView().byId("maxinput48").getValue()),
					SELECTED_FCST_MTHD: " ",
					CREATED_DATE: createdDate,
					CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
					MODIFIED_DATE: currentDate,
					MODIFIED_USER: currentUser
				};
				var newData = JSON.stringify(insertData);
				jQuery.ajax({

					url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
					type: "POST",
					async: false,
					method: 'GET',
					dataType: 'text',
					data: {
						dataObject: newData
					},
					success: function(data) {

						//alert("success");
						var mParameters = {

							success: function(oData) {
								sap.ui.core.BusyIndicator.hide();

								that.getView().getModel("local").getData().Overlay48 = oData.results;
								that.getView().byId("vizChart48").getDataset().bindData("local>/Overlay48");

							},
							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();

							}
						};

						sap.ui.core.BusyIndicator.show();
						that.getOwnerComponent().getModel().read(
							"/CV_COST_CURVE_FINALParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" +
							"'" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=48M" + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel("local")
							.getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE=''" + "," + "parDOMCL_CNTRY_CD=" + "'" + that._CountryCode() + "'," +
							"parDEDUCT_AMT=0" + "," + "parRATE_PLAN_ID=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute",
							mParameters);

					},

					error: function(error) {

					}

				});
			} else {
				sap.m.MessageBox.error("MIN should be less than MAX ");
			}
		},

		RefreshMinMax60: function() {
			if (this.getView().byId("maxinput60").getValue() > this.getView().byId("mininput60").getValue()) {
				var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
				var that = this;
				//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
				var newDate = new Date();
				var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
				var currentUser = this.getView().getModel("UserInfo").getData().userName;

				var insertData = {
					RATE_PLAN_ID: parseInt(this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
					VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
					CVRG_GROUP: this.getView().byId("coverage").getValue(),
					ENGINE_TORQUE: " ",
					DEDUCT_AMT: 0,
					DOMCL_CNTRY_CD_GRP: this._CountryCode(),
					CVRG_MONTHS: 60,
					MIN_MIS: parseInt(this.getView().byId("mininput60").getValue()),
					MAX_MIS: parseInt(this.getView().byId("maxinput60").getValue()),
					SELECTED_FCST_MTHD: " ",
					CREATED_DATE: createdDate,
					CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
					MODIFIED_DATE: currentDate,
					MODIFIED_USER: currentUser
				};

				var newData = JSON.stringify(insertData);
				jQuery.ajax({

					url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
					type: "POST",
					async: false,
					method: 'GET',
					dataType: 'text',
					data: {
						dataObject: newData
					},
					success: function(data) {

						//alert("success");
						var mParameters = {

							success: function(oData) {
								sap.ui.core.BusyIndicator.hide();

								that.getView().getModel("local").getData().Overlay60 = oData.results;
								that.getView().byId("vizChart60").getDataset().bindData("local>/Overlay60");

							},
							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();

							}
						};

						sap.ui.core.BusyIndicator.show();
						that.getOwnerComponent().getModel().read(
							"/CV_COST_CURVE_FINALParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" +
							"'" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=60M" + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel("local")
							.getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE=''" + "," + "parDOMCL_CNTRY_CD=" + "'" + that._CountryCode() + "'," +
							"parDEDUCT_AMT=0" + "," + "parRATE_PLAN_ID=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute",
							mParameters);
					},

					error: function(error) {

					}

				});
			} else {
				sap.m.MessageBox.error("MIN should be less than MAX ");
			}
		},

		save24: function() {

			if (!this.getView().byId("ForecastMthd24").getSelectedKey()) {

				sap.m.MessageBox.error("Please select Forecast method to be applied");

			} else if ((this.getView().byId("ForecastMthd24").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd24").getSelectedKey() ==
				'QUADRATIC WITH POINTS') && (!this.getView().byId("mininput24").getValue() || !this.getView().byId("maxinput24").getValue())) {

				MessageBox.error("MIN MAX cannot be blank");

			} else {
				if ((this.getView().byId("ForecastMthd24").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd24").getSelectedKey() ==
					'QUADRATIC WITH POINTS') && (this.getView().byId("mininput24").getValue() > this.getView().byId("maxinput24").getValue())) {
					MessageBox.error("MIN should be less than MAX");
				} else { //values fine
					sap.ui.core.BusyIndicator.show();

					//var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;

					//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];

					var that = this;
					var createdDate = that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
					//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];

					var newDate = new Date();
					var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
					var currentUser = that.getView().getModel("UserInfo").getData().userName;

					var insertData = {
						RATE_PLAN_ID: parseInt(this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
						VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
						CVRG_GROUP: this.getView().byId("coverage").getValue(),
						ENGINE_TORQUE: " ",
						DEDUCT_AMT: 0,
						DOMCL_CNTRY_CD_GRP: this._CountryCode(),
						CVRG_MONTHS: 24,
						MIN_MIS: parseInt(this.getView().byId("mininput24").getValue()),
						MAX_MIS: parseInt(this.getView().byId("maxinput24").getValue()),
						SELECTED_FCST_MTHD: this.getView().byId("ForecastMthd24").getValue().toUpperCase(),
						CREATED_DATE: createdDate,
						CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
						MODIFIED_DATE: currentDate,
						MODIFIED_USER: currentUser
					};

					var newData = JSON.stringify(insertData);
					jQuery.ajax({

						url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
						type: "POST",
						async: false,
						method: 'GET',
						dataType: 'text',
						data: {
							dataObject: newData
						},
						success: function(data) {
							var jsonData = JSON.parse(data);
							that.getView().getModel("local").getData().ViewRatePlan = jsonData[0];
							that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT = jsonData[0].CREATED_DT.split("/")[2] + "-" + jsonData[0].CREATED_DT
								.split("/")[0] + "-" + jsonData[0].CREATED_DT.split("/")[1];
							that.getView().getModel("local").getData().ViewRatePlan.MODIFIED_DT = jsonData[0].MODIFIED_DT.split("/")[2] + "-" + jsonData[0].MODIFIED_DT
								.split("/")[0] + "-" + jsonData[0].MODIFIED_DT.split("/")[1];

							//							sap.ui.core.BusyIndicator.hide();
							/*	that._GetcostCurveValue("24M");
							MessageToast.show("Forecast Saved");

							// hide the dialog
							that._hideFormFragment(that, "ChassisChart24months");*/
							// Start of AUF Insert  

							var AufInsertData = [{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 1,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/1/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/1/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group1_24").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 24,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_24").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_24")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},
								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 2,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/2/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/2/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group2_24").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 24,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_24").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_24")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},

								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 3,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/3/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/3/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group3_24").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 24,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_24").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_24")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},
								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 4,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/4/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/4/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group4_24").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 24,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_24").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_24")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					}
				];
							newData = JSON.stringify(AufInsertData);

							jQuery.ajax({

								url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUFInsertUpdate.xsjs",
								type: "POST",
								async: false,
								method: 'POST',
								dataType: 'text',
								data: {
									dataObject: newData
								},
								success: function(data) {
									that._AUFMCFCall(that.getView().byId("coverage").getValue(), that.getView().byId("vocation").getValue().toUpperCase(), 24, '',
										that._CountryCode(), 0, parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID));
								},

								error: function(error) {
									sap.ui.core.BusyIndicator.hide();
								}

							});

							// End of AUF insert  
						},

						error: function(error) {
							sap.ui.core.BusyIndicator.hide();
						}

					});

				}
			}
		},

		save36: function() {

			if (!this.getView().byId("ForecastMthd36").getSelectedKey()) {

				sap.m.MessageBox.error("Please select Forecast method to be applied");

			} else if ((this.getView().byId("ForecastMthd36").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd36").getSelectedKey() ==
				'QUADRATIC WITH POINTS') && (!this.getView().byId("min36").getValue() || !this.getView().byId("max36").getValue())) {

				MessageBox.error("MIN MAX cannot be blank");

			} else {
				if ((this.getView().byId("ForecastMthd36").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd36").getSelectedKey() ==
					'QUADRATIC WITH POINTS') && (this.getView().byId("min36").getValue() > this.getView().byId("max36").getValue())) {
					MessageBox.error("MIN should be less than MAX");
				} else { //values fine
					sap.ui.core.BusyIndicator.show();
					var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
					var that = this;
					//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
					var newDate = new Date();
					var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
					var currentUser = that.getView().getModel("UserInfo").getData().userName;

					var insertData = {
						RATE_PLAN_ID: parseInt(this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
						VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
						CVRG_GROUP: this.getView().byId("coverage").getValue(),
						ENGINE_TORQUE: " ",
						DEDUCT_AMT: 0,
						DOMCL_CNTRY_CD_GRP: this._CountryCode(),
						CVRG_MONTHS: 36,
						MIN_MIS: parseInt(this.getView().byId("min36").getValue()),
						MAX_MIS: parseInt(this.getView().byId("max36").getValue()),
						SELECTED_FCST_MTHD: this.getView().byId("ForecastMthd36").getValue().toUpperCase(),
						CREATED_DATE: createdDate,
						CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
						MODIFIED_DATE: currentDate,
						MODIFIED_USER: currentUser
					};

					var newData = JSON.stringify(insertData);
					jQuery.ajax({

						url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
						type: "POST",
						async: false,
						method: 'GET',
						dataType: 'text',
						data: {
							dataObject: newData
						},
						success: function(data) {

							//	alert("success");
							var jsonData = JSON.parse(data);
							that.getView().getModel("local").getData().ViewRatePlan = jsonData[0];
							that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT = jsonData[0].CREATED_DT.split("/")[2] + "-" + jsonData[0].CREATED_DT
								.split("/")[0] + "-" + jsonData[0].CREATED_DT.split("/")[1];
							that.getView().getModel("local").getData().ViewRatePlan.MODIFIED_DT = jsonData[0].MODIFIED_DT.split("/")[2] + "-" + jsonData[0].MODIFIED_DT
								.split("/")[0] + "-" + jsonData[0].MODIFIED_DT.split("/")[1];

							//	sap.ui.core.BusyIndicator.hide();
							/*	that._GetcostCurveValue("36M");
							MessageToast.show("Forecast Saved");

							that._hideFormFragment(that, "ChassisChart36months");*/

							// Start of AUF Insert  

							var AufInsertData = [{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 1,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/1/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/1/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group1_36").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 36,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_36").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_36")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},
								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 2,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/2/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/2/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group2_36").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 36,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_36").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_36")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},

								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 3,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/3/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/3/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group3_36").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 36,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_36").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_36")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},
								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 4,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/4/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/4/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group4_36").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 36,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_36").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_36")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					}
				];
							newData = JSON.stringify(AufInsertData);

							jQuery.ajax({

								url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUFInsertUpdate.xsjs",
								type: "POST",
								async: false,
								method: 'POST',
								dataType: 'text',
								data: {
									dataObject: newData
								},
								success: function(data) {
									that._AUFMCFCall(that.getView().byId("coverage").getValue(), that.getView().byId("vocation").getValue().toUpperCase(), 36, '',
										that._CountryCode(), 0, parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID));
								},

								error: function(error) {
									sap.ui.core.BusyIndicator.hide();
								}

							});

							// End of AUF insert  

						},

						error: function(error) {
							sap.ui.core.BusyIndicator.hide();
						}

					});

				}
			}
		},

		save48: function() {

			if (!this.getView().byId("ForecastMthd48").getSelectedKey()) {

				sap.m.MessageBox.error("Please select Forecast method to be applied");

			} else if ((this.getView().byId("ForecastMthd48").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd48").getSelectedKey() ==
				'QUADRATIC WITH POINTS') && (!this.getView().byId("mininput48").getValue() || !this.getView().byId("maxinput48").getValue())) {

				MessageBox.error("MIN MAX cannot be blank");

			} else {
				if ((this.getView().byId("ForecastMthd48").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd48").getSelectedKey() ==
					'QUADRATIC WITH POINTS') && (this.getView().byId("mininput48").getValue() > this.getView().byId("maxinput48").getValue())) {
					MessageBox.error("MIN should be less than MAX");
				} else { //values fine
					sap.ui.core.BusyIndicator.show();
					var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
					var that = this;
					//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
					var newDate = new Date();
					var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
					var currentUser = that.getView().getModel("UserInfo").getData().userName;

					var insertData = {
						RATE_PLAN_ID: parseInt(this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
						VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
						CVRG_GROUP: this.getView().byId("coverage").getValue(),
						ENGINE_TORQUE: " ",
						DEDUCT_AMT: 0,
						DOMCL_CNTRY_CD_GRP: this._CountryCode(),
						CVRG_MONTHS: 48,
						MIN_MIS: parseInt(this.getView().byId("mininput48").getValue()),
						MAX_MIS: parseInt(this.getView().byId("maxinput48").getValue()),
						SELECTED_FCST_MTHD: this.getView().byId("ForecastMthd48").getValue().toUpperCase(),
						CREATED_DATE: createdDate,
						CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
						MODIFIED_DATE: currentDate,
						MODIFIED_USER: currentUser
					};

					var newData = JSON.stringify(insertData);
					jQuery.ajax({

						url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
						type: "POST",
						async: false,
						method: 'GET',
						dataType: 'text',
						data: {
							dataObject: newData
						},
						success: function(data) {
							var jsonData = JSON.parse(data);
							that.getView().getModel("local").getData().ViewRatePlan = jsonData[0];
							that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT = jsonData[0].CREATED_DT.split("/")[2] + "-" + jsonData[0].CREATED_DT
								.split("/")[0] + "-" + jsonData[0].CREATED_DT.split("/")[1];
							that.getView().getModel("local").getData().ViewRatePlan.MODIFIED_DT = jsonData[0].MODIFIED_DT.split("/")[2] + "-" + jsonData[0].MODIFIED_DT
								.split("/")[0] + "-" + jsonData[0].MODIFIED_DT.split("/")[1];

							//sap.ui.core.BusyIndicator.hide();
							/*	that._GetcostCurveValue("48M");
							MessageToast.show("Forecast Saved");

							//hide the dialog
							that._hideFormFragment(that, "ChassisChart48months");*/

							// Start of AUF Insert  

							var AufInsertData = [{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 1,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/1/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/1/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group1_48").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 48,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_48").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_48")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},
								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 2,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/2/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/2/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group2_48").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 48,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_48").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_48")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},

								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 3,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/3/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/3/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group3_48").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 48,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_48").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_48")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},
								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 4,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/4/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/4/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group4_48").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 48,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_48").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_48")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					}
				];
							newData = JSON.stringify(AufInsertData);

							jQuery.ajax({

								url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUFInsertUpdate.xsjs",
								type: "POST",
								async: false,
								method: 'POST',
								dataType: 'text',
								data: {
									dataObject: newData
								},
								success: function(data) {
									that._AUFMCFCall(that.getView().byId("coverage").getValue(), that.getView().byId("vocation").getValue().toUpperCase(), 48, '',
										that._CountryCode(), 0, parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID));
								},

								error: function(error) {
									sap.ui.core.BusyIndicator.hide();
								}

							});

							// End of AUF insert  

						},

						error: function(error) {

						}

					});

				}
			}
		},

		save60: function() {

			if (!this.getView().byId("ForecastMthd60").getSelectedKey()) {

				sap.m.MessageBox.error("Please select Forecast method to be applied");

			} else if ((this.getView().byId("ForecastMthd60").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd60").getSelectedKey() ==
				'QUADRATIC WITH POINTS') && (!this.getView().byId("mininput60").getValue() || !this.getView().byId("maxinput60").getValue())) {

				MessageBox.error("MIN MAX cannot be blank");

			} else {
				if ((this.getView().byId("ForecastMthd60").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd60").getSelectedKey() ==
					'QUADRATIC WITH POINTS') && (this.getView().byId("mininput60").getValue() > this.getView().byId("maxinput60").getValue())) {
					MessageBox.error("MIN should be less than MAX");
				} else { //values fine
					sap.ui.core.BusyIndicator.show();
					var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
					var that = this;
					//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
					var newDate = new Date();
					var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
					var currentUser = that.getView().getModel("UserInfo").getData().userName;

					var insertData = {
						RATE_PLAN_ID: parseInt(this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
						VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
						CVRG_GROUP: this.getView().byId("coverage").getValue(),
						ENGINE_TORQUE: " ",
						DEDUCT_AMT: 0,
						DOMCL_CNTRY_CD_GRP: this._CountryCode(),
						CVRG_MONTHS: 60,
						MIN_MIS: parseInt(this.getView().byId("mininput60").getValue()),
						MAX_MIS: parseInt(this.getView().byId("maxinput60").getValue()),
						SELECTED_FCST_MTHD: this.getView().byId("ForecastMthd60").getValue().toUpperCase(),
						CREATED_DATE: createdDate,
						CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
						MODIFIED_DATE: currentDate,
						MODIFIED_USER: currentUser
					};

					var newData = JSON.stringify(insertData);
					jQuery.ajax({

						url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
						type: "POST",
						async: false,
						method: 'GET',
						dataType: 'text',
						data: {
							dataObject: newData
						},
						success: function(data) {

							//alert("success");
							var jsonData = JSON.parse(data);
							that.getView().getModel("local").getData().ViewRatePlan = jsonData[0];
							that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT = jsonData[0].CREATED_DT.split("/")[2] + "-" + jsonData[0].CREATED_DT
								.split("/")[0] + "-" + jsonData[0].CREATED_DT.split("/")[1];
							that.getView().getModel("local").getData().ViewRatePlan.MODIFIED_DT = jsonData[0].MODIFIED_DT.split("/")[2] + "-" + jsonData[0].MODIFIED_DT
								.split("/")[0] + "-" + jsonData[0].MODIFIED_DT.split("/")[1];
							//	sap.ui.core.BusyIndicator.hide();
							/*that._GetcostCurveValue("60M");
							MessageToast.show("Forecast Saved");

							//hide the dialog
							that._hideFormFragment(that, "ChassisChart60months");*/

							// Start of AUF Insert  

							var AufInsertData = [{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 1,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/1/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/1/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group1_60").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 60,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_60").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_60")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},
								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 2,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/2/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/2/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group2_60").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 60,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_60").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_60")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},

								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 3,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/3/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/3/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group3_60").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 60,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_60").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_60")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					},
								{
									RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
									GROUP_ID: 4,
									EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/4/EW_UNITS")),
									AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/4/ACCELERATED_USAGE_FACTOR")),
									SELECTED_GROUP_ID: parseInt(that.getView().byId("group4_60").getSelectedKey()),
									CREATED_DATE: createdDate,
									CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
									MODIFIED_DATE: currentDate,
									MODIFIED_USER: currentUser,
									VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
									CVRG_GROUP: that.getView().byId("coverage").getValue(),
									DOMCL_CNTRY_CD_GRP: that._CountryCode(),
									ENGINE_TORQUE: '',
									DEDUCT_AMT: 0,
									CVRG_MONTHS: 60,
									SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_60").getSelectedKey() +
										"/ACCELERATED_USAGE_FACTOR")),
									AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_60")
										.getSelectedKey() +
										"/AVG_CONTRACTUAL_MILES"))

					}
				];
							newData = JSON.stringify(AufInsertData);

							jQuery.ajax({

								url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUFInsertUpdate.xsjs",
								type: "POST",
								async: false,
								method: 'POST',
								dataType: 'text',
								data: {
									dataObject: newData
								},
								success: function(data) {
									that._AUFMCFCall(that.getView().byId("coverage").getValue(), that.getView().byId("vocation").getValue().toUpperCase(), 60, '',
										that._CountryCode(), 0, parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID));
								},

								error: function(error) {
									sap.ui.core.BusyIndicator.hide();
								}

							});

							// End of AUF insert  

						},

						error: function(error) {

						}

					});

				}
			}
		},

		_GetcostCurveValue: function(month) {
			sap.ui.core.BusyIndicator.show();

			var that = this;

			var mParameters = {
				// filter : aFilters,
				success: function(oData) {
					sap.ui.core.BusyIndicator.hide();

					if (month == "24M") {
						that.getView().getModel("local").getData().costcurve24 = oData.results;
					} else if (month == "36M") {
						that.getView().getModel("local").getData().costcurve36 = oData.results;

					} else if (month == "48M") {
						that.getView().getModel("local").getData().costcurve48 = oData.results;

					} else if (month == "60M") {
						that.getView().getModel("local").getData().costcurve60 = oData.results;

					}
				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error(oError.responseText);

				}

			};

			this.getOwnerComponent().getModel().read(
				"/CV_COST_CURVE_FINALParameters(parCVRG_GROUP=" + "'" + this.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" + "'" +
				this.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + this.getView().byId(
					"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + this.getView().getModel("local").getProperty(
					"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=" + month + "," + "parPRODUCT_TYPE=" + "'" + this.getView().getModel(
					"local")
				.getProperty(
					"/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + this.getView().getModel("local").getProperty(
					"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE=''" + "," + "parDOMCL_CNTRY_CD=" + "'" + this._CountryCode() + "'," +
				"parDEDUCT_AMT=0" + "," + "parRATE_PLAN_ID=" + this.getView().getModel("local").getProperty(
					"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute",
				mParameters);

		},

		//To read data for Milege table 

		_GetMilegeData: function(month) {

			var that = this
			this.getView().getModel("local").getData().Milege = [];
			this.getView().byId("milege" + month).setBusy(true);
			var mParameters = {
				success: function(oData) {
					that.getView().byId("milege" + month).setBusy(false);
					sap.ui.core.BusyIndicator.hide();

					that.getView().getModel("local").getData().Milege = oData.results;
				},
				error: function(oError) {
					that.getView().byId("milege" + month).setBusy(false);
					MessageBox.error(oError.responseText);

				}

			};

			//	that.getOwnerComponent().getModel().read("/CVRG_UNITSParameters(parCVRG_GROUP='EXTENDED BASIC VEHICLE',parPRD_TYP_CD='CHASSIS',parVOC_CATEGORY='STANDARD',parIN_SRVC_YR=2015,parCVRG_MONTHS=48,parPRODUCT_TYPE='HD',parDATE=datetime'2018-03-01',parTORQUE='',parDOMCL_CNTRY_CD='USA AND CAN',parDEDUCT_AMT=0)/Execute", mParametersone);

			that.getOwnerComponent().getModel().read("/CVRG_UNITSParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() +
				"'," + "parPRD_TYP_CD=" + "'" +
				that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
					"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
					"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=" + month + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel(
					"local").getProperty("/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
					"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE=''" + "," + "parDOMCL_CNTRY_CD=" + "'" + this._CountryCode() + "'," +
				"parDEDUCT_AMT=0)/Execute",
				mParameters);

		},

		ForecastStatus: function() {

			this._showFormFragment(this.getView(), "CostCurveChassisStatus");
			this.getView().getModel("local").getData().CostCurveStatus = [];
			var that = this;

			var mParameters = {

				success: function(oData) {
					that.getView().getModel("local").getData().CostCurveStatus = oData.results;

				},
				error: function(oError) {

				}

			};
			//CV_COST_CURVE_STATUSParameters
			that.getOwnerComponent().getModel().read("/CV_COST_CURVE_STATUSParameters(Par_RATE_PLAN_ID=" + that.getView().getModel("local").getProperty(
				"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute", mParameters);

		},

		_CountryCode: function() {
			var countrygrp;
			if (this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen === 1) {

				countrygrp = this.getView().byId("domicile").getSelectedItem().getKey();

			} else if (this.getView().byId("domicile").getSelectedItem()) {

				countrygrp = this.getView().byId("domicile").getSelectedItem().getKey();

			} else {

				countrygrp = this.getView().byId("domicile").getValue().toUpperCase();
			}

			return countrygrp;

		},

		//on Coverage Change
		onCoverageChange: function(oEvent) {
			var coverageValue = oEvent.getSource().getValue();
			this.getView().getModel("local").getData().costCurveTitle.chassisTitle = coverageValue;
		},
		//end of  coverage 

		_AUFMCFCall: function(cvrgGroup, vocation, cvrgMonth, torque, domicile, deductAmt, ratePlanId) {
			//sap.ui.core.BusyIndicator.show();
			var that = this;
			/*/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUF_MCF_Procedure_Call.xsjs?cvrgGroup=EXTENDED BASIC VEHICLE&vocation=STANDARD&cvrgMonth=24&torque=
		    &domicile=USA AND CAN&deductAmt=0&ratePlanId=5555*/
			var serviceUrl = '/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUF_MCF_Procedure_Call.xsjs?cvrgGroup=' + cvrgGroup +
				'&vocation=' + vocation + '&cvrgMonth=' + cvrgMonth + '&torque=' + torque + '&domicile=' + domicile + '&deductAmt=' + deductAmt +
				'&ratePlanId=' + ratePlanId;
			jQuery.ajax({

				url: serviceUrl,
				type: "POST",
				async: true,
				method: 'GET',
				success: function(data) {
					// sap.ui.core.BusyIndicator.hide();
					//alert("success");

					that._GetcostCurveValue(cvrgMonth + "M");

					that._hideFormFragment(that, "ChassisChart" + cvrgMonth + "months");

					sap.m.MessageBox.success("Cost Curve updates have been saved successfully", {

						actions: [sap.m.MessageBox.Action.CLOSE],

						contentWidth: "100px"

					});
					sap.ui.core.BusyIndicator.hide();
					//	sap.ui.core.BusyIndicator.hide();

				},

				error: function(error) {
					sap.ui.core.BusyIndicator.hide();
				}

			});

		},

		Reference24: function() {

			var RplCoverageMonth;
			var CvrgMonth = 24;
			var minMis;
			var maxMis;
            var selectedForecastMethod;
			

			if (this.getView().byId("copy24").getValue() == "36 Months") {

				RplCoverageMonth = 36;
				minMis = this.getView().getModel("local").getData().costcurve36[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve36[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan24.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("copy24").getValue() == "48 Months") {

				RplCoverageMonth = 48;
				minMis = this.getView().getModel("local").getData().costcurve48[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve48[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan48.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("copy24").getValue() == "60 Months") {

				RplCoverageMonth = 60;
				minMis = this.getView().getModel("local").getData().costcurve60[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve60[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan60.SELECTED_FCST_MTHD;
			}

			this._ReferenceMonthInsert(RplCoverageMonth, CvrgMonth, minMis, maxMis, selectedForecastMethod);
		},

		Reference36: function() {

			var RplCoverageMonth;
			var CvrgMonth = 36;
			var minMis;
			var maxMis;
			var selectedForecastMethod;
		

			if (this.getView().byId("copy36").getValue() == "24 Months") {

				RplCoverageMonth = 24;
				minMis = this.getView().getModel("local").getData().costcurve24[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurv24[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan24.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("copy36").getValue() == "48 Months") {

				RplCoverageMonth = 48;
				minMis = this.getView().getModel("local").getData().costcurve48[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve48[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan48.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("copy36").getValue() == "60 Months") {

				RplCoverageMonth = 60;
				minMis = this.getView().getModel("local").getData().costcurve60[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve60[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan60.SELECTED_FCST_MTHD;
			}

			this._ReferenceMonthInsert(RplCoverageMonth, CvrgMonth, minMis, maxMis, selectedForecastMethod);
		},

		Reference48: function() {

			var RplCoverageMonth;
			var CvrgMonth = 48;
			var minMis;
			var maxMis;
			
			var selectedForecastMethod;  
			

			if (this.getView().byId("copy48").getValue() == "36 Months") {

				RplCoverageMonth = 36;
				minMis = this.getView().getModel("local").getData().costcurve36[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve36[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan36.SELECTED_FCST_MTHD;

			}

			if (this.getView().byId("copy48").getValue() == "24 Months") {

				RplCoverageMonth = 24;
				minMis = this.getView().getModel("local").getData().costcurve24[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve24[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan24.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("copy48").getValue() == "60 Months") {

				RplCoverageMonth = 60;
				minMis = this.getView().getModel("local").getData().costcurve60[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve60[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan60.SELECTED_FCST_MTHD;
			}

			this._ReferenceMonthInsert(RplCoverageMonth, CvrgMonth, minMis, maxMis, selectedForecastMethod);
		},

		Reference60: function() {

			var RplCoverageMonth;
			var CvrgMonth = 60;
			var minMis;
			var maxMis;
			var selectedForecastMethod;
			

			if (this.getView().byId("copy60").getValue() == "36 Months") {

				RplCoverageMonth = 36;
				minMis = this.getView().getModel("local").getData().costcurve36[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve36[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan36.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("copy60").getValue() == "24 Months") {

				RplCoverageMonth = 24;
				minMis = this.getView().getModel("local").getData().costcurve24[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve24[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan24.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("copy60").getValue() == "48 Months") {

				RplCoverageMonth = 48;
				minMis = this.getView().getModel("local").getData().costcurve48[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve48[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan48.SELECTED_FCST_MTHD;
			}

			this._ReferenceMonthInsert(RplCoverageMonth, CvrgMonth, minMis, maxMis, selectedForecastMethod);
		},

		_ReferenceMonthInsert: function(RplCoverageMonth, CvrgMonth, minMis, maxMis, selectedForecastMethod) {
			var dialog = this.getView().byId("Reference");
			var that = this;
			var newData;
			var view = this.getView();

			if (!dialog) {
				dialog = new Dialog({
					id: "Reference",
					title: 'Confirm',
					type: 'Message',
					content: new Text({
						text: "Are you sure you want " + CvrgMonth + " Month Cost Curve to be based on " + RplCoverageMonth + " Month data ?"
					}),
					beginButton: new Button({
						text: 'Yes',
						press: function(oEvent) {
							var newDate = new Date();
							var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
							var currentUser = view.getModel("UserInfo").getData().userName;

							var referenceInsertData = {
								RATE_PLAN_ID: parseInt(view.getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
								VOC_CATEGORY_GRP: view.byId("vocation").getValue().toUpperCase(),
								CVRG_GROUP: view.byId("coverage").getValue(),
								DOMCL_CNTRY_CD_GRP: that._CountryCode(),
								ENGINE_TORQUE: "",
								DEDUCT_AMT: 0,
								MIN_MIS: parseInt(minMis),
								MAX_MIS: parseInt(maxMis),
                                SELECTED_FCST_MTHD: selectedForecastMethod,
								CVRG_MONTHS: CvrgMonth,
								REPL_CVRG_MONTHS: RplCoverageMonth,
								CREATED_DATE: view.getModel("local").getData().ViewRatePlan.CREATED_DT,
								CREATED_USER: view.getModel("local").getData().ViewRatePlan.CREATED_USER,
								MODIFIED_DATE: currentDate,
								MODIFIED_USER: view.getModel("UserInfo").getData().userName

							}
							var newData = JSON.stringify(referenceInsertData);

							// ajax call  to insert Reference term the rateplan ID
							jQuery.ajax({

								url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/Referenceterm.xsjs",
								type: "POST",
								async: false,
								method: 'GET',
								dataType: 'text',
								data: {
									dataObject: newData
								},
								success: function(data) {
								    sap.ui.core.BusyIndicator.show();
								    that._AUFMCFCall(that.getView().byId("coverage").getValue(), that.getView().byId("vocation").getValue().toUpperCase(), CvrgMonth, '',
										that._CountryCode(), 0, parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID));

								/*	sap.m.MessageBox.show(+ CvrgMonth + "Month copied from " + RplCoverageMonth + "Successfully", {
										icon: sap.m.MessageBox.Icon.SUCCESS,
										title: "Success",
										actions: [sap.m.MessageBox.Action.CLOSE],

										contentWidth: "100px"

									});*/

								},
								error: function(oError) {
									sap.m.MessageBox.error(oError.responseText);
								}
							});
							//close the dialog
							dialog.close();

						}
					}),
					endButton: new Button({
						text: 'No',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				this.getView().addDependent(dialog);
			}

			dialog.open();

		}

	});
});
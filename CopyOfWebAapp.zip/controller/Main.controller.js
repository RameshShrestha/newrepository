sap.ui.define([
	"sap/ui/core/mvc/Controller",
		'sap/m/Dialog',
		'sap/m/Text',
		'sap/m/Button',
        'sap/m/MessageToast',
], function(Controller, Dialog, Text, Button, MessageToast) {
	"use strict";

	return Controller.extend("DtnaAspRP_ss.controller.Main", {
		onHomeClick: function() {
			this.router.navTo("Main");
		},
		onInit: function() {
			this.router = this.getOwnerComponent().getRouter();

		},

		onCreateRatePlanClick: function() {

			//clear the fields
			if (this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID) {
				var that = this;
				var dialog = new Dialog({
					title: 'Confirm',
					type: 'Message',
					content: new Text({
						text: 'Any unsaved changes  will be lost. Are you sure you want to proceed with new Rate Plan ?'
					}),
					beginButton: new Button({
						text: 'Submit',
						press: function(oEvent) {
							var createView = that.getOwnerComponent().getTargets().getViews()._oViews["DtnaAspRP_ss.view.CreateRatePlan"];
							/*Clear CC data*/
							that.getView().getModel("local").getData().costcurve24 = [];
							that.getView().getModel("local").getData().costcurve36 = [];
							that.getView().getModel("local").getData().costcurve48 = [];
							that.getView().getModel("local").getData().costcurve60 = [];
							that.getView().getModel("local").getData().costcurve72 = [];
							that.getView().getModel("local").getData().Overlay24 = [];
							that.getView().getModel("local").getData().Overlay36 = [];
							that.getView().getModel("local").getData().Overlay48 = [];
							that.getView().getModel("local").getData().Overlay60 = [];
							that.getView().getModel("local").getData().Overlay72 = [];
							/*Reset BL Screen*/
							createView.byId("ratetable").removeSelections();
							that.getView().getModel("local").getData().NewRatePlan.PORTFOLIO_NAME = "";
							that.getView().getModel("local").getData().ViewRatePlan = {}; // Initialize View Rate Plan
							that.getView().getModel("local").getData().NewRatePlan = {}; //Initialize  new Rate created
							that.getView().getModel("local").getData().CostCurveViewRatePlan = {};
							that.getView().getModel("local").getData().Baseline = []; //Initialize Maturity Months
							createView.byId("generatedriver").setEnabled(false); //disabling Generate Cost Driver Button

							/*Reset Pareto*/
							that.getView().getModel("local").getData().pareto = []; //clear model for Pareto table

							/*Reset Plot*/
							that.getView().getModel("local").getData().vmrsSelection = []; //clear model from vmrsSelection

							that.getOwnerComponent().getTargets().getViews()._oViews["DtnaAspRP_ss.view.CreateRatePlan"].byId("port").setValue("");

							/*WizardSteps*/

							var wizard = createView.byId("CreateRatePlanWizard");
							wizard.goToStep("blSelection");
							that.getView().getModel("local").getData().rateplanvisibility.selectedStep = 1
							while (wizard.getCurrentStep() != createView.getId() + "--" + "blSelection") {
								wizard.previousStep();
							}

							dialog.close();
							that.router.navTo("createrateplan");

						}
					}),
					endButton: new Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});

				dialog.open();

			} else {

				this.router.navTo("createrateplan");
			}
		},
		onViewRatePlanClick: function() {

		},
		onRateQuoteCalculationClick: function() {

		}
	});
});
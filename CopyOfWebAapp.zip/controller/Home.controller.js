sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/Dialog',
	'sap/m/Text',
	'sap/m/Button',
	'sap/m/MessageBox',
    'sap/m/MessageToast'

], function(Controller, Dialog, Text, Button, MessageBox, MessageToast) {
		"use strict";

		return Controller.extend("DtnaAspRP_ss.controller.Home", {
					onInit: function(oEvent) {
						this.router = this.getOwnerComponent().getRouter();
					},
					clearAllFilters_Sorters: function() {

						var table = this.byId("ratePlanTable");
						var binding = table.getBinding("rows");

						//remove filters
						binding.filter();
						for (var i = 0; i < table.getColumns().length; i++) {
							table.filter(table.getColumns()[i], null);
						}

						//remove Sorters
						table.getBinding("rows").sort(null);
						this._resetSortingState();
					},
					_resetSortingState: function() {
						var oTable = this.byId("ratePlanTable");
						for (var i = 0; i < oTable.getColumns().length; i++) {
							oTable.getColumns()[i].setSorted(false);
						}
					},
					/*	onRatePlanPress_one: function(oEvent) {
			sap.ui.core.BusyIndicator.show();
			var rateplanterm = this.getView().getModel().getProperty(oEvent.getSource().getBindingContext().getPath()).RATE_PLAN_TERM;
			var rateplanId = this.getView().getModel().getProperty(oEvent.getSource().getBindingContext().getPath()).RATE_PLAN_ID;
			this.getView().byId("ratePlanTable").setVisible(false);
			var that = this;
			if (!this.VMRS) {
				this.VMRS = sap.ui.xmlfragment(this.getView().getId(), "DtnaAspRP_ss.Fragment.CostDriversForSelectionforHome", this);
				this.getView().byId("Home").addContent(this.VMRS);
			} else {

				this.getView().byId("costDrivergrid").setVisible(true);

			}
			this.getView().byId("plotsTitle").setText("Plots for " + rateplanterm);
			var omodel = this.getOwnerComponent().getModel();
			var mParameters = {

				success: function(oData) {
					that.getView().getModel("local").getData().vmrsHomeSelection = oData.results;
					that.getView().getModel("local").refresh(true);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(error) {

				}
			};
			omodel.read("/CV_VMRS_SELECTION_ALL_OTHERSParameters(ParRATE_PLAN_ID=" + rateplanId + ")/Execute", mParameters);

		},*/

					onRatePlanPress: function(oEvent) {
						var rateplanId = this.getView().getModel().getProperty(oEvent.getSource().getBindingContext().getPath()).RATE_PLAN_ID;
						var createView = this.getOwnerComponent().getTargets().getViews()._oViews["DtnaAspRP_ss.view.CreateRatePlan"];

						this.getView().getModel("local").getData().costcurve24 = [];
						this.getView().getModel("local").getData().costcurve36 = [];
						this.getView().getModel("local").getData().costcurve48 = [];
						this.getView().getModel("local").getData().costcurve60 = [];
						this.getView().getModel("local").getData().costcurve72 = [];
						this.getView().getModel("local").getData().Overlay24 = [];
						this.getView().getModel("local").getData().Overlay36 = [];
						this.getView().getModel("local").getData().Overlay48 = [];
						this.getView().getModel("local").getData().Overlay60 = [];
						this.getView().getModel("local").getData().Overlay72 = [];
						this.getView().getModel("local").getData().NewRatePlan.PORTFOLIO_NAME = "";
						this.getView().getModel("local").getData().ViewRatePlan = {}; // Initialize View Rate Plan
						this.getView().getModel("local").getData().NewRatePlan = {};
						this.getView().getModel("local").getData().CostCurveViewRatePlan = {};
						this.getView().getModel("local").getData().rateplanvisibility.selectedStep = 1;

						this.getView().getModel("local").getData().pareto = []; //clear model for Pareto table

						/*Reset Plot*/
						this.getView().getModel("local").getData().vmrsSelection = []; //clear model from vmrsSelection
						this.router.navTo("createrateplan", {
							rate_plan_id: rateplanId

						});

					},

					onCostClaimPress: function(oEvent) {
						// 			console.log(oEvent);
						var vmrsCode = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
						var vmrsDescription = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
						var oData = this.getView().getModel("local").getData().vmrsHomeSelection;
						var oCommonModel = this.getOwnerComponent().getModel("oCommonModel");
						oCommonModel.setProperty("/VMRS_33_CD", oData[vmrsCode].VMRS_33_CD);
						oCommonModel.setProperty("/VMRS_33_ASSEMB_DESC", oData[vmrsCode].VMRS_33_DESC);
						this.router.navTo("CostPerClaim");
					},
					onNavBack: function() {
						this.getView().byId("costDrivergrid").setVisible(false);
						this.getView().byId("ratePlanTable").setVisible(true);
					},
					/*on Delete RatePlan*/
					onDeleteRatePlanClick: function(oEvent) {

						this._rateplanId = this.getView().getModel().getProperty(oEvent.getSource().getBindingContext().getPath()).RATE_PLAN_ID;
						var view = this.getView();
						var that = this;
						var dialog = this.getView().byId("confirm");

						if (!dialog) {
							dialog = new Dialog({
								id: "confirm",
								title: 'Confirm',
								type: 'Message',
								content: new Text({
									text: 'Are you sure you want to delete the Rate Plan?'
								}),
								beginButton: new Button({
									text: 'Yes',
									press: function(oEvent) {
										var ratePlanId = oEvent.getSource().getParent().getParent().getController()._rateplanId;
										/* ajax call  to delete the rateplan ID*/
										jQuery.ajax({

											url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/DeleteRatePlan.xsjs?ratePlanId=" + ratePlanId,
											type: "GET",
											async: false,
											method: 'GET',
											dataType: 'text',
											success: function(data) {
												/*refresh the table data after successful deletion*/
												that.getView().getModel().refresh(true);

											},
											error: function(oError) {
												sap.m.MessageBox.error(oError.responseText);
											}
										});
										/*close the dialog*/
										dialog.close();

									}
								}),
								endButton: new Button({
									text: 'No',
									press: function() {
										dialog.close();
									}
								}),
								afterClose: function() {
									dialog.destroy();
								}
							});
							view.addDependent(dialog);
						}
						dialog.open();
					},

					/*on Click of Finalize*/
					onFinalizeClick: function(oEvent) {

						this._rateplanId = this.getView().getModel().getProperty(oEvent.getSource().getBindingContext().getPath()).RATE_PLAN_ID;
						var view = this.getView();
						var that = this;
						var dialog = this.getView().byId("Finalized");

						if (!dialog) {
							dialog = new Dialog({
									id: "Finalized",
									title: 'Confirm',
									type: 'Message',
									content: new Text({
										text: 'Are you sure you want to Finalize the Rate Plan?'
									}),
									beginButton: new Button({
											text: 'Yes',
											press: function(oEvent) {
												var ratePlanId = oEvent.getSource().getParent().getParent().getController()._rateplanId;
												var newDate = new Date();
												var finalizedDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();

												var insertData = {

													ratePlanId : ratePlanId,
													finalizedDate : finalizedDate

												};
												var newData = JSON.stringify(insertData);
							// ajax call  to Finalize the rateplan ID
								jQuery.ajax({

					           	url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/FinalizeRatePlan.xsjs",
								type: "POST",
								async: false,
								method: 'GET',
								dataType: 'text',
									data: {
						dataObject: newData
					},
								success: function(data) {
									//refresh the table data after successful updation
									that.getView().getModel().refresh(true);
									
										sap.m.MessageBox.show("Rate Plan ID " + ratePlanId +
									" is Now Finalized", {
										icon: sap.m.MessageBox.Icon.SUCCESS,
										title: "Success",
										actions: [sap.m.MessageBox.Action.CLOSE],

										contentWidth: "100px"

									});
									

								},
								error: function(oError) {
									sap.m.MessageBox.error(oError.responseText);
								}
							});
							//close the dialog
							dialog.close();

						}
					}),
					endButton: new Button({
						text: 'No',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				view.addDependent(dialog);
			}
			
			dialog.open();
		    
		    

		}

	});
});
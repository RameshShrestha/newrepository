sap.ui.define([
	"sap/ui/core/mvc/Controller",
		'sap/m/Dialog',
		'sap/m/Text',
		'sap/m/Button',
        'sap/m/MessageToast',
        'sap/ui/model/json/JSONModel',
        "sap/m/MessageBox",
        "sap/viz/ui5/controls/VizTooltip",
], function(Controller, Dialog, Text, Button, MessageToast, JSONModel, MessageBox, VizTooltip) {
	"use strict";

	return Controller.extend("DtnaAspRP_ss.controller.FailureRate", {
		onInit: function() {
			/*array to store fragments for Failure Rate*/
			this._Fragments = [];
			this.router = this.getOwnerComponent().getRouter();
			this.router.getRoute("FailureRate").attachPatternMatched(this._onRouteObjectMatched, this);

			var data = {
				portfolio: '',
				saveVisibility: false
			};

			var model = new JSONModel(data);
			this.getView().setModel(model, "FLModel");

		},
		_onRouteObjectMatched: function(oEvent) {

			sap.ui.core.BusyIndicator.hide();
			if (oEvent.getParameter("arguments").vmrsCode === 'ALL OTHERS') {
				this._vmrsCode = 'ALL_OTHERS';
			} else {
				this._vmrsCode = oEvent.getParameter("arguments").vmrsCode;
			}
			this._vmrsDesc = oEvent.getParameter("arguments").vmrsDesc;
			this.getView().getModel("FLModel").getData().VMRSDESC = this._vmrsDesc;
			this.getView().getModel("FLModel").refresh();

			if (this.getOwnerComponent().getModel("local").getData().rateplanvisibility.costCurveBtn == 1) {
				this.getView().getModel("FLModel").getData().portfolio = 'chassis';
				this.getView().getModel("FLModel").refresh();
				this.goToChassis();
			} else if (this.getOwnerComponent().getModel("local").getData().rateplanvisibility.costCurveBtn == 2) {
				this.getView().getModel("FLModel").getData().portfolio = 'engine';
				this.getView().getModel("FLModel").refresh();
				this.goToEngine();
			}
			//to be removed
			else {
				this.getView().getModel("FLModel").getData().portfolio = 'engine';
				this.getView().getModel("FLModel").refresh();
				this.goToEngine();
			}
		},
		goToEngine: function() {

			this._showFormFragment("FailureRateEngine");
			/*add the popover to charts*/
			new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrameEngine36").getVizUid());
			new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrameEngine48").getVizUid());
			new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrameEngine60").getVizUid());
			new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrameEngine72").getVizUid());

			var that = this;
			//chart 36
			this.getView().byId("idVizFrameEngine36").addEventDelegate({

				onclick: function(oEvent) {

					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					that.getView().getModel("local").getData().AdjData = [];
					that._displayPopover(that.getView(), "OverlayFailure36", "vizChart36");
					//that._GetAdjustmentTableData(36);
					that._GetAdjustmentTableData_new(36, that.getView().getModel("local").getProperty("/FRChartSelection/coverage"), that.getView()
						.getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/vocation"), that.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"), that.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), parseInt(that.getView()
							.getModel("local").getProperty("/ViewRatePlan/BASELINE_YEAR")), that.getView().getModel("local").getProperty(
							"/FRChartSelection/torque"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/domicile"),
						parseInt(that.getView().getModel("local").getProperty("/FRChartSelection/deductible")), that._vmrsCode, parseInt(that.getView().getModel(
							"local").getProperty("/ViewRatePlan/RATE_PLAN_ID")));
				}

			});

			//chart 48
			this.getView().byId("idVizFrameEngine48").addEventDelegate({

				onclick: function(oEvent) {

					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					that.getView().getModel("local").getData().AdjData = [];
					that._displayPopover(that.getView(), "OverlayFailure48", "vizChart48");
					//that._GetAdjustmentTableData(48);
					that._GetAdjustmentTableData_new(48, that.getView().getModel("local").getProperty("/FRChartSelection/coverage"), that.getView()
						.getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/vocation"), that.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"), that.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), parseInt(that.getView()
							.getModel("local").getProperty("/ViewRatePlan/BASELINE_YEAR")), that.getView().getModel("local").getProperty(
							"/FRChartSelection/torque"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/domicile"),
						parseInt(that.getView().getModel("local").getProperty("/FRChartSelection/deductible")), that._vmrsCode, parseInt(that.getView().getModel(
							"local").getProperty("/ViewRatePlan/RATE_PLAN_ID")));
				}

			});

			//chart 60
			this.getView().byId("idVizFrameEngine60").addEventDelegate({

				onclick: function(oEvent) {

					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					that.getView().getModel("local").getData().AdjData = [];
					that._displayPopover(that.getView(), "OverlayFailure60", "vizChart60");
					//that._GetAdjustmentTableData(60);
					that._GetAdjustmentTableData_new(60, that.getView().getModel("local").getProperty("/FRChartSelection/coverage"), that.getView()
						.getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/vocation"), that.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"), that.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), parseInt(that.getView()
							.getModel("local").getProperty("/ViewRatePlan/BASELINE_YEAR")), that.getView().getModel("local").getProperty(
							"/FRChartSelection/torque"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/domicile"),
						parseInt(that.getView().getModel("local").getProperty("/FRChartSelection/deductible")), that._vmrsCode, parseInt(that.getView().getModel(
							"local").getProperty("/ViewRatePlan/RATE_PLAN_ID")));
				}

			});

			//chart 72
			this.getView().byId("idVizFrameEngine72").addEventDelegate({

				onclick: function(oEvent) {

					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					that.getView().getModel("local").getData().AdjData = [];
					that._displayPopover(that.getView(), "OverlayFailure72", "vizChart72");
					//that._GetAdjustmentTableData(72);
					that._GetAdjustmentTableData_new(72, that.getView().getModel("local").getProperty("/FRChartSelection/coverage"), that.getView()
						.getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/vocation"), that.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"), that.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), parseInt(that.getView()
							.getModel("local").getProperty("/ViewRatePlan/BASELINE_YEAR")), that.getView().getModel("local").getProperty(
							"/FRChartSelection/torque"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/domicile"),
						parseInt(that.getView().getModel("local").getProperty("/FRChartSelection/deductible")), that._vmrsCode, parseInt(that.getView().getModel(
							"local").getProperty("/ViewRatePlan/RATE_PLAN_ID")));
				}

			});
			/*end of popover*/
		},
		goToChassis: function() {
			this._showFormFragment("FailureRateChassis");

			//add tooltip
			new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrameChassis24").getVizUid());
			new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrameChassis36").getVizUid());
			new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrameChassis48").getVizUid());
			new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrameChassis60").getVizUid());

			var that = this;

			//chart 24
			this.getView().byId("idVizFrameChassis24").addEventDelegate({

				onclick: function(oEvent) {

					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					that.getView().getModel("local").getData().AdjData = [];
					that._displayPopover(that.getView(), "OverlayFailure24", "vizChart24");
					//that._GetAdjustmentTableData(24);
					that._GetAdjustmentTableData_new(24, that.getView().getModel("local").getProperty("/FRChartSelection/coverage"), that.getView()
						.getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/vocation"), that.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"), that.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), parseInt(that.getView()
							.getModel("local").getProperty("/ViewRatePlan/BASELINE_YEAR")), '', that.getView().getModel("local").getProperty(
							"/FRChartSelection/domicile"),
						0, that._vmrsCode, parseInt(that.getView().getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID")));
				}

			});

			//chart 36
			this.getView().byId("idVizFrameChassis36").addEventDelegate({

				onclick: function(oEvent) {

					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					that.getView().getModel("local").getData().AdjData = [];
					that._displayPopover(that.getView(), "OverlayFailure36", "vizChart36");
					//that._GetAdjustmentTableData(36);
					that._GetAdjustmentTableData_new(36, that.getView().getModel("local").getProperty("/FRChartSelection/coverage"), that.getView()
						.getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/vocation"), that.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"), that.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), parseInt(that.getView()
							.getModel("local").getProperty("/ViewRatePlan/BASELINE_YEAR")), '', that.getView().getModel("local").getProperty(
							"/FRChartSelection/domicile"),
						0, that._vmrsCode, parseInt(that.getView().getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID")));
				}

			});

			//chart 48
			this.getView().byId("idVizFrameChassis48").addEventDelegate({

				onclick: function(oEvent) {

					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					that.getView().getModel("local").getData().AdjData = [];
					that._displayPopover(that.getView(), "OverlayFailure48", "vizChart48");
					//that._GetAdjustmentTableData(48);
					that._GetAdjustmentTableData_new(48, that.getView().getModel("local").getProperty("/FRChartSelection/coverage"), that.getView()
						.getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/vocation"), that.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"), that.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), parseInt(that.getView()
							.getModel("local").getProperty("/ViewRatePlan/BASELINE_YEAR")), '', that.getView().getModel("local").getProperty(
							"/FRChartSelection/domicile"),
						0, that._vmrsCode, parseInt(that.getView().getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID")));
				}

			});

			//chart 60
			this.getView().byId("idVizFrameChassis60").addEventDelegate({

				onclick: function(oEvent) {

					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					that.getView().getModel("local").getData().AdjData = [];
					that._displayPopover(that.getView(), "OverlayFailure60", "vizChart60");
					//that._GetAdjustmentTableData(60);
					that._GetAdjustmentTableData_new(60, that.getView().getModel("local").getProperty("/FRChartSelection/coverage"), that.getView()
						.getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME"), that.getView().getModel("local").getProperty(
							"/FRChartSelection/vocation"), that.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"), that.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), parseInt(that.getView()
							.getModel("local").getProperty("/ViewRatePlan/BASELINE_YEAR")), '', that.getView().getModel("local").getProperty(
							"/FRChartSelection/domicile"),
						0, that._vmrsCode, parseInt(that.getView().getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID")));
				}

			});

			/*end of popover*/
		},

		_GetAdjustmentTableData_new: function(cvrgMonth, cvrgGrp, prodTypeCD, vocCat, prodType, cutOffDate, inSrvcYr, torque, domicile,
			deductAmt, vmrsCode, ratePlanId) {

			var that = this;
			this._errorFields = 0;
			this.getView().getModel("local").getData().AdjData = [];
			//	sap.ui.core.BusyIndicator.show();
			this.getView().byId("techAdjTable" + cvrgMonth).setBusy(true);
			var mParameters = {
				success: function(oData) {
					that.getView().byId("techAdjTable" + cvrgMonth).setBusy(false);
					//	sap.ui.core.BusyIndicator.hide();

					that.getView().getModel("local").getData().AdjData = oData.results;
				},
				error: function(oError) {
					that.getView().byId("techAdjTable" + cvrgMonth).setBusy(false);
					MessageBox.error(oError.responseText);
					//	sap.ui.core.BusyIndicator.hide();

				}

			};

			/*this.getOwnerComponent().getModel().read(
				"/CV_RP_FAILURE_RATE_BASELINEDParameters(parCVRG_GROUP=" + "'" + cvrgGrp + "'," + "parPRD_TYP_CD=" + "'" +
				prodTypeCD + "'," + "parVOC_CATEGORY=" + "'" + vocCat + "'," + "parIN_SRVC_YR=" + inSrvcYr + "," + "parCVRG_MONTHS=" + cvrgMonth +
				"," + "parPRODUCT_TYPE=" + "'" + prodType + "'," + "parDATE=datetime" + "'" + cutOffDate + "'," + "parTORQUE='" + torque + "'," +
				"parDOMCL_CNTRY_CD=" + "'" + domicile + "'," + "parDEDUCT_AMT=" + deductAmt + "," + "parVMRS_CODE='" + vmrsCode +
				"',parRATE_PLAN_ID=" + ratePlanId + ")/Execute",
				mParameters);*/

			/*http://vhdtahaddb01.us164.corpintra.net:8006/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/ASPRATEPLAN.xsodata
				/CV_RP_FAILURE_RATE_FINALISEDParameters(parCVRG_GROUP='EXTENDED%20BASIC%20VEHICLE',parPRD_TYP_CD='CHASSIS',parVOC_CATEGORY='STANDARD',
				parIN_SRVC_YR=2015,parCVRG_MONTHS=24,parPRODUCT_TYPE='HD',parDATE=datetime'2018-11-01',
				parTORQUE='',parDOMCL_CNTRY_CD='USA%20AND%20CAN',parDEDUCT_AMT=0,parVMRS_CODE='032-002-001',parRATE_PLAN_ID=5820)/Execute*/

			this.getOwnerComponent().getModel().read(
				"/CV_RP_FAILURE_RATE_FINALISEDParameters(parCVRG_GROUP=" + "'" + cvrgGrp + "'," + "parPRD_TYP_CD=" + "'" +
				prodTypeCD + "'," + "parVOC_CATEGORY=" + "'" + vocCat + "'," + "parIN_SRVC_YR=" + inSrvcYr + "," + "parCVRG_MONTHS=" + cvrgMonth +
				"," + "parPRODUCT_TYPE=" + "'" + prodType + "'," + "parDATE=datetime" + "'" + cutOffDate + "'," + "parTORQUE='" + torque + "'," +
				"parDOMCL_CNTRY_CD=" + "'" + domicile + "'," + "parDEDUCT_AMT=" + deductAmt + "," + "parVMRS_CODE='" + vmrsCode +
				"',parRATE_PLAN_ID=" + ratePlanId + ")/Execute",
				mParameters);

		},
		/*save adjustment records for 36*/
		save36: function(oEvent) {
			if (this.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") == 'ENGINE') {
				this._formAdjQuery(36, parseInt(this.getView().getModel("local").getProperty("/FRChartSelection/deductible")), this.getView().getModel(
					"local").getProperty("/FRChartSelection/torque"));
			} else {
				this._formAdjQuery(36, 0, '');
			}
		},
		save48: function(oEvent) {
			if (this.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") == 'ENGINE') {
				this._formAdjQuery(48, parseInt(this.getView().getModel("local").getProperty("/FRChartSelection/deductible")), this.getView().getModel(
					"local").getProperty("/FRChartSelection/torque"));
			} else {
				this._formAdjQuery(48, 0, '');
			}
		},
		save24: function(oEvent) {

			this._formAdjQuery(24, 0, '');

		},
		save60: function(oEvent) {
			if (this.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") == 'ENGINE') {
				this._formAdjQuery(60, parseInt(this.getView().getModel("local").getProperty("/FRChartSelection/deductible")), this.getView().getModel(
					"local").getProperty("/FRChartSelection/torque"));
			} else {
				this._formAdjQuery(60, 0, '');
			}
		},
		save72: function(oEvent) {

			this._formAdjQuery(72, parseInt(this.getView().getModel("local").getProperty("/FRChartSelection/deductible")), this.getView().getModel(
				"local").getProperty("/FRChartSelection/torque"));

		},
		_formAdjQuery: function(cvrgMonth, deductAmt, torque) {
			this._saveAdjustments(cvrgMonth, this.getView().getModel("local").getProperty("/FRChartSelection/coverage"), this.getView()
				.getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME"), this.getView().getModel("local").getProperty(
					"/FRChartSelection/vocation"), this.getView().getModel(
					"local")
				.getProperty(
					"/ViewRatePlan/PRODUCT_TYPE"), this.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), parseInt(this.getView()
					.getModel("local").getProperty("/ViewRatePlan/BASELINE_YEAR")), torque, this.getView().getModel("local").getProperty(
					"/FRChartSelection/domicile"),
				deductAmt, this._vmrsCode, parseInt(this.getView().getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID")));
		},
		/*save adjustment records by calling xsjs*/
		_saveAdjustments: function(cvrgMonth, cvrgGrp, prodTypeCD, vocCat, prodType, cutOffDate, inSrvcYr, torque, domicile, deductAmt,
			vmrsCode, ratePlanId) {
			    if(this._errorFields == 0){
			var table = this.getView().byId("techAdjTable" + cvrgMonth);
			var tableItems = this.getView().byId("techAdjTable" + cvrgMonth).getItems();
			var data = table.getModel("local").getProperty(table.getBinding("items").getPath());
			var insertData = [];
			var path;
			var that = this;
			var newDate = new Date();
			var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
			if(tableItems.length > 0){
			    //loop to get the adjustment data ready for insert
			for (var i = 0; i < tableItems.length; i++) {
				path = tableItems[i].getBindingContextPath("local");
				insertData.push({
					RATE_PLAN_ID: parseInt(this.getView().getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID")),
					VMRS_33_CD: this._vmrsCode,
					CVRG_GROUP: cvrgGrp,
					CVRG_MONTHS: cvrgMonth,
					VOC_CATEGORY: vocCat,
					DOMCL_CNTRY_CD: domicile,
					ENGINE_TORQUE: torque,
					DEDUCT_AMT: deductAmt,
					IN_SRVC_YEAR: parseInt(this.getView().getModel("local").getProperty("/ViewRatePlan/BASELINE_YEAR")),
					BASELINE_INDICATOR: parseInt(this.getView().getModel("local").getProperty(path).YEAR),
					TECH_ADJ_1: parseFloat(this.getView().getModel("local").getProperty(path).CC_TECH_ADJ1_OUT),
					TECH_ADJ_1_COMMENTS: this.getView().getModel("local").getProperty(path).CC_TECH_ADJ1_CMT_OUT,
					REAL_FAILURE_RATE: parseFloat(this.getView().getModel("local").getProperty(path).CC_REAL_FAILURE_RATE),
					TECH_ADJ_2: parseFloat(this.getView().getModel("local").getProperty(path).CC_TECH_ADJ2_OUT),
					TECH_ADJ_2_COMMENTS: this.getView().getModel("local").getProperty(path).CC_TECH_ADJ2_CMT_OUT,
					STRATEGIC_FAILURE_RATE: parseFloat(this.getView().getModel("local").getProperty(path).CC_STRATAGIC_FAILURE_RATE),
					CREATED_DATE: this.getView().getModel("local").getProperty("/ViewRatePlan/CREATED_DT"),
					CREATED_USER: this.getView().getModel("local").getProperty("/ViewRatePlan/CREATED_USER"),
					MODIFIED_DATE: currentDate,
					MODIFIED_USER: this.getView().getModel("UserInfo").getData().userName,
					PRODUCT_TYP: prodType,
					PRD_TYP_CD: prodTypeCD
				});
			}
			/*end of loop*/

			// call xsjs to insert/update adjustment records
			var newData = JSON.stringify(insertData);
			jQuery.ajax({

				url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/FailureRateInsertUpdate.xsjs",
				type: "POST",
				async: false,
				method: 'POST',
				dataType: 'text',
				data: {
					dataObject: newData
				},
				success: function(data) {
					var dialog = that._Fragments["OverlayFailure" + cvrgMonth];

					if (dialog) {
						dialog.close();
					}

					sap.m.MessageBox.success("Failure Rate Adjustments have been saved successfully", {

						actions: [sap.m.MessageBox.Action.CLOSE],

						contentWidth: "100px"

					});

				},
				error: function(oError) {
					var dialog = that._Fragments["OverlayFailure" + cvrgMonth];

					if (dialog) {
						dialog.close();
					}
					sap.m.MessageBox.error(oError.responseText);
				}
			});
			// new sxjs
			}
			else{
			    	sap.m.MessageBox.information("No Adjustments saved", {

						actions: [sap.m.MessageBox.Action.CLOSE],

						contentWidth: "100px"

					});
			}
			    }
			    else{
			        	sap.m.MessageBox.error("Please enter the correct values for the highlighted fields");
			    }

		},
		_displayPopover: function(view, sFragmentname, vizId) {

			var controller = view.getController();
			var dialog = controller._getFragment(sFragmentname);

			//add tooltip
			new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId(vizId).getVizUid());

			dialog.open();

		},

		_getFragment: function(sFragmentName) {
			var oFragment = this._Fragments[sFragmentName];

			if (oFragment) {
				return oFragment;
			}

			oFragment = sap.ui.xmlfragment(this.getView().getId(), "DtnaAspRP_ss.Fragment." + sFragmentName, this);

			this.getView().addDependent(oFragment);
			this._Fragments[sFragmentName] = oFragment;

			return this._Fragments[sFragmentName];
		},

		_showFormFragment: function(sFragmentName) {
			var oPage = this.byId("failureRatePage");
			oPage.removeAllContent();
			oPage.insertContent(this._getFragment(sFragmentName));
		},
		handleLiveChange: function(oEvent) { // for comment popup text area
			var oTextArea = oEvent.getSource(),
				iValueLength = oTextArea.getValue().length,
				iMaxLength = oTextArea.getMaxLength(),
				sState = iValueLength > iMaxLength ? "Warning" : "None";

			oTextArea.setValueState(sState);
		},
		/*reset the status of the inout for comment once the value is changed*/
		/*onValueCommentChange: function(oEvent) {
			var input = oEvent.getSource();
			input.setValueState("None");
		},*/
		onValueTechCommentChange: function(oEvent) {
			var input = oEvent.getSource();
			if(	input.getValueState() == 'Error'){
			     this._errorFields = this._errorFields - 1;
			}
			input.setValueState("None");
		},
		/*change the state of the comment field once value has been changed*/
		onAfterCommentClose: function(oEvent) {
			this.getView().byId("comment").setValueState("None");
		},

		/*show popover to get user comment*/

		openTechAdjComment1: function(oEvent) { //open with comment

			var popup = this._getFragment("UserComment");
			this.getUserTechComment(oEvent.getSource().getBindingContext("local").getPath(), "CC_TECH_ADJ1_CMT_OUT");
			popup.openBy(oEvent.getSource());
		},

		openTechAdjComment2: function(oEvent) {

			var popup = this._getFragment("UserComment");
			this.getUserTechComment(oEvent.getSource().getBindingContext("local").getPath(), "CC_TECH_ADJ2_CMT_OUT");
			popup.openBy(oEvent.getSource());
		},

		getUserTechComment: function(path, property) {
			this.currPath = path;
			this.currProperty = property;
			this.getView().byId("comment").setValue(this.getView().getModel("local").getProperty(this.currPath + "/" + property));
		},
		/*save the user comment in the comment field*/
		handleSavePress2: function(oEvent) {
			var popup = this._getFragment("UserComment");
			if (this.getView().byId("comment").getValueState() == "None") {
				if (this.currProperty === "CC_TECH_ADJ1_CMT_OUT") {
					this.getView().getModel("local").getProperty(this.currPath).CC_TECH_ADJ1_CMT_OUT = this.getView().byId("comment").getValue();
					if(this.getView().getModel("local").getProperty(this.currPath + '/state1') == 'Error')
					{
					    this._errorFields = this._errorFields - 1;
					}
					this.getView().getModel("local").setProperty(this.currPath + '/state1', "None");
					//this.getView().getModel().setProperty(this.currPath + '/statusText1', " ");
				} else if (this.currProperty === "CC_TECH_ADJ2_CMT_OUT") {
					this.getView().getModel("local").getProperty(this.currPath).CC_TECH_ADJ2_CMT_OUT = this.getView().byId("comment").getValue();
					if(this.getView().getModel("local").getProperty(this.currPath + '/state2') == 'Error')
					{
					    this._errorFields = this._errorFields - 1;
					}
					this.getView().getModel("local").setProperty(this.currPath + '/state2', "None");
					//	this.getView().getModel().setProperty(this.currPath + '/statusText2', " ");
				}
				this.getView().getModel("local").refresh(true);
				popup.close();
			}
		},

		onTechAdj1Change: function(oEvent) {
			this.onAdjustmentChange(oEvent.getSource().getBindingContext("local").getPath(), "state1", "statusText1");

		},

		onTechAdj2Change: function(oEvent) {
			this.onAdjustmentChange(oEvent.getSource().getBindingContext("local").getPath(), "state2", "statusText2");

		},

		onAdjustmentChange: function(path, stateProperty, statusProperty) {
			this.getView().getModel("local").setProperty(path + '/' + stateProperty, "Warning");
			this.getView().getModel("local").setProperty(path + '/' + statusProperty, "Required");

		},
		/*onAdjustmentTechChange: function(path, stateProperty, statusProperty) {
			this.getView().getModel("local").setProperty(path + '/' + stateProperty, "Warning");
			this.getView().getModel("local").setProperty(path + '/' + statusProperty, "Required");

		},*/
		/*close the popup*/
		handleCancelPress: function(oEvent) {
			var popup = this._getFragment("UserComment");
			popup.close();
		},

		/*on click of 'i' icon display popup with rate plan info*/
		onRatePlanPopover: function(oEvent) {

			var popup = this._getFragment("ratePlanInfoPopover");
			popup.openBy(oEvent.getSource());

		},

		/*on Press of genereate button display chart values*/
		generateFailureRate: function() {
			if (this.getView().getModel("FLModel").getData().portfolio == 'chassis') {
				if (this.getView().byId("vocationChassis").getValue().length == 0 || this.getView().byId("domicileChassis").getValue().length == 0 ||
					this.getView().byId("coverageChassis").getValue().length == 0) {
					MessageBox.error("Please Enter/Select Vocation, Domicile and Coverage");
				} else {
					this._GetFailureRateValue(24, this.getView().byId("coverageChassis").getSelectedItem().getText(), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/PORTFOLIO_NAME"), this.getView().byId("vocationChassis").getSelectedKey(), this.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"),
						this.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/BASELINE_YEAR"), '', this.getView().byId("domicileChassis").getSelectedKey(), 0, this._vmrsCode, this.getView().getModel(
							"local").getProperty(
							"/ViewRatePlan/RATE_PLAN_ID"));

					this._GetFailureRateValue(36, this.getView().byId("coverageChassis").getSelectedItem().getText(), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/PORTFOLIO_NAME"), this.getView().byId("vocationChassis").getSelectedKey(), this.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"),
						this.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/BASELINE_YEAR"), '', this.getView().byId("domicileChassis").getSelectedKey(), 0, this._vmrsCode, this.getView().getModel(
							"local").getProperty(
							"/ViewRatePlan/RATE_PLAN_ID"));

					this._GetFailureRateValue(48, this.getView().byId("coverageChassis").getSelectedItem().getText(), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/PORTFOLIO_NAME"), this.getView().byId("vocationChassis").getSelectedKey(), this.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"),
						this.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/BASELINE_YEAR"), '', this.getView().byId("domicileChassis").getSelectedKey(), 0, this._vmrsCode, this.getView().getModel(
							"local").getProperty(
							"/ViewRatePlan/RATE_PLAN_ID"));

					this._GetFailureRateValue(60, this.getView().byId("coverageChassis").getSelectedItem().getText(), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/PORTFOLIO_NAME"), this.getView().byId("vocationChassis").getSelectedKey(), this.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"),
						this.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/BASELINE_YEAR"), '', this.getView().byId("domicileChassis").getSelectedKey(), 0, this._vmrsCode, this.getView().getModel(
							"local").getProperty(
							"/ViewRatePlan/RATE_PLAN_ID"));
				}

			} else {

				if (this.getView().byId("vocationEngine").getValue().length == 0 || this.getView().byId("domicileEngine").getValue().length == 0 ||
					this.getView().byId("coverageEngine").getValue().length == 0 || this.getView().byId("deductibleEngine").getValue().length == 0 ||
					this.getView().byId("torqueEngine").getValue().length == 0) {
					MessageBox.error("Please Enter/Select Vocation, Domicile, Coverage, Deductible and Torque");
				} else {

					this._GetFailureRateValue(36, this.getView().byId("coverageEngine").getSelectedItem().getText(), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/PORTFOLIO_NAME"), this.getView().byId("vocationEngine").getSelectedKey(), this.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"),
						this.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/BASELINE_YEAR"), this.getView().byId("torqueEngine").getSelectedKey(), this.getView().byId("domicileEngine").getSelectedKey(),
						parseInt(this.getView().byId("deductibleEngine").getSelectedKey()), this._vmrsCode, this.getView().getModel("local").getProperty(
							"/ViewRatePlan/RATE_PLAN_ID"));

					this._GetFailureRateValue(48, this.getView().byId("coverageEngine").getSelectedItem().getText(), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/PORTFOLIO_NAME"), this.getView().byId("vocationEngine").getSelectedKey(), this.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"),
						this.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/BASELINE_YEAR"), this.getView().byId("torqueEngine").getSelectedKey(), this.getView().byId("domicileEngine").getSelectedKey(),
						parseInt(this.getView().byId("deductibleEngine").getSelectedKey()), this._vmrsCode, this.getView().getModel("local").getProperty(
							"/ViewRatePlan/RATE_PLAN_ID"));

					this._GetFailureRateValue(60, this.getView().byId("coverageEngine").getSelectedItem().getText(), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/PORTFOLIO_NAME"), this.getView().byId("vocationEngine").getSelectedKey(), this.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"),
						this.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/BASELINE_YEAR"), this.getView().byId("torqueEngine").getSelectedKey(), this.getView().byId("domicileEngine").getSelectedKey(),
						parseInt(this.getView().byId("deductibleEngine").getSelectedKey()), this._vmrsCode, this.getView().getModel("local").getProperty(
							"/ViewRatePlan/RATE_PLAN_ID"));

					this._GetFailureRateValue(72, this.getView().byId("coverageEngine").getSelectedItem().getText(), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/PORTFOLIO_NAME"), this.getView().byId("vocationEngine").getSelectedKey(), this.getView().getModel(
							"local")
						.getProperty(
							"/ViewRatePlan/PRODUCT_TYPE"),
						this.getView().getModel("local").getProperty("/NewRatePlan/RATE_PLAN_CUTOFF_DT"), this.getView().getModel("local").getProperty(
							"/ViewRatePlan/BASELINE_YEAR"), this.getView().byId("torqueEngine").getSelectedKey(), this.getView().byId("domicileEngine").getSelectedKey(),
						parseInt(this.getView().byId("deductibleEngine").getSelectedKey()), this._vmrsCode, this.getView().getModel("local").getProperty(
							"/ViewRatePlan/RATE_PLAN_ID"));

				}
			}
		},
		_GetFailureRateValue: function(cvrgMonth, cvrgGrp, prodTypeCD, vocCat, prodType, cutOffDate, inSrvcYr, torque, domicile, deductAmt,
			vmrsCode, ratePlanId) {
			//sap.ui.core.BusyIndicator.show();
			if (prodTypeCD == 'CHASSIS') {
				this.getView().byId("idVizFrameChassis" + cvrgMonth).setBusy(true);
			} else {
				this.getView().byId("idVizFrameEngine" + cvrgMonth).setBusy(true);
			}
			var that = this;

			var mParameters = {
				// filter : aFilters,
				urlParameters: {
					"$orderby": "IN_SRVC_YR,IN_SRVC_MONTH"
				},
				success: function(oData) {
					sap.ui.core.BusyIndicator.hide();

					if (cvrgMonth == 24) {
						that.getView().getModel("local").getData().failureRateChart24 = oData.results;
					} else if (cvrgMonth == 36) {
						that.getView().getModel("local").getData().failureRateChart36 = oData.results;

					} else if (cvrgMonth == 48) {
						that.getView().getModel("local").getData().failureRateChart48 = oData.results;

					} else if (cvrgMonth == 60) {
						that.getView().getModel("local").getData().failureRateChart60 = oData.results;

					} else if (cvrgMonth == 72) {
						that.getView().getModel("local").getData().failureRateChart72 = oData.results;

					}
					if (prodTypeCD == 'CHASSIS') {
						that.getView().byId("idVizFrameChassis" + cvrgMonth).setBusy(false);
					} else {
						that.getView().byId("idVizFrameEngine" + cvrgMonth).setBusy(false);
					}
				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					if (prodTypeCD == 'CHASSIS') {
						that.getView().byId("idVizFrameChassis" + cvrgMonth).setBusy(false);
					} else {
						that.getView().byId("idVizFrameEngine" + cvrgMonth).setBusy(false);
					}
					MessageBox.error(oError.responseText);

				}

			};
			/*parCVRG_GROUP='EXTENDED%20BASIC%20VEHICLE',parPRD_TYP_CD='CHASSIS',parVOC_CATEGORY='STANDARD',parIN_SRVC_YR=2015,parCVRG_MONTHS=48,parPRODUCT_TYPE='HD',
   parDATE=datetime'2018-03-01',parTORQUE='',parDOMCL_CNTRY_CD='USA%20AND%20CAN',parDEDUCT_AMT=0,parVMRS_CODE='001-001-002')/Execute*/

			/*cvrgMonth, cvrgGrp, prodTypeCD, vocCat, prodType, dat, torque, domicile, deductAmt, vmrsCode  cutOffDate,inSrvcYr*/
			/*this.getOwnerComponent().getModel().read(
				"/CV_FAILURE_RATE_LINECHART_VIEW1Parameters(parCVRG_GROUP=" + "'" + cvrgGrp + "'," + "parPRD_TYP_CD=" + "'" +
				prodTypeCD + "'," + "parVOC_CATEGORY=" + "'" + vocCat + "'," + "parIN_SRVC_YR=" + inSrvcYr + "," + "parCVRG_MONTHS=" + cvrgMonth +
				"," + "parPRODUCT_TYPE=" + "'" + prodType + "'," + "parDATE=datetime" + "'" + cutOffDate + "'," + "parTORQUE='" + torque + "'," +
				"parDOMCL_CNTRY_CD=" + "'" + domicile + "'," + "parDEDUCT_AMT=" + deductAmt + "," + "parVMRS_CODE='" + vmrsCode +
				"')/Execute",
				mParameters);*/

			this.getOwnerComponent().getModel().read(
				"/CV_FAILURE_RATE_LINECHART_ALLVMRSParameters(parCVRG_GROUP=" + "'" + cvrgGrp + "'," + "parPRD_TYP_CD=" + "'" +
				prodTypeCD + "'," + "parVOC_CATEGORY=" + "'" + vocCat + "'," + "parIN_SRVC_YR=" + inSrvcYr + "," + "parCVRG_MONTHS=" + cvrgMonth +
				"," + "parPRODUCT_TYPE=" + "'" + prodType + "'," + "parDATE=datetime" + "'" + cutOffDate + "'," + "parTORQUE='" + torque + "'," +
				"parDOMCL_CNTRY_CD=" + "'" + domicile + "'," + "parDEDUCT_AMT=" + deductAmt + "," + "parVMRS_CODE='" + vmrsCode +
				"',parRATE_PLAN_ID=" + ratePlanId + ")/Execute",
				mParameters);

		},
		/*implementation for new technical input for adjustment*/
	
		onTechAdj1Change: function(oEvent) {
			var oControl = oEvent.getSource();
			var res = this.validateFloatInput(oControl, 'state1', 'CC_TECH_ADJ1_OUT','Adj1State');
			if (res == true) {
				oControl.setValue(parseFloat(oControl.getValue()).toFixed(2));
			}
		},
		
		onTechAdj2Change: function(oEvent) {
			var oControl = oEvent.getSource();
			var res = this.validateFloatInput(oControl, 'state2', 'CC_TECH_ADJ2_OUT','Adj2State');
			if (res == true) {
				oControl.setValue(parseFloat(oControl.getValue()).toFixed(2));
			}
		},
		validateFloatInput: function(oControl, oState, techAdjProperty,adjStateProperty) {

			var oValue = oControl.getValue();

			if (oValue > 10.00 || oValue < -10.00 || !oValue) {
				//oControl.setValueState(sap.ui.core.ValueState.Error);
				oControl.setValueStateText("Value should be between 10.00 and -10.00");
				if(!this.getView().getModel("local").getProperty(oControl.getBindingContext("local").getPath() + '/' + adjStateProperty) || this.getView().getModel("local").getProperty(oControl.getBindingContext("local").getPath() + '/' + adjStateProperty) == 'None'){
				this.getView().getModel("local").setProperty(oControl.getBindingContext("local").getPath() + '/' + adjStateProperty, "Error");
				this._errorFields = 	this._errorFields + 1;
				}

			} else {

				//oControl.setValueState(sap.ui.core.ValueState.None);
				if(this.getView().getModel("local").getProperty(oControl.getBindingContext("local").getPath() + '/' + adjStateProperty) == 'Error'){
				    this._errorFields = 	this._errorFields - 1;
				}
				this.getView().getModel("local").setProperty(oControl.getBindingContext("local").getPath() + '/' + adjStateProperty, "None");
				oControl.setValue(parseFloat(oControl.getValue()).toFixed(2));

				// this.getView().getModel("local").setProperty(oControl.getBindingContext("local").getPath() + '/' + oState, "Error");

				if (techAdjProperty === 'CC_TECH_ADJ1_OUT') {
					var data = this.getView().getModel("local").getProperty(oControl.getBindingContext("local").getPath());
					data.CC_REAL_FAILURE_RATE = data.CC_SEMI_RFR * (1 + parseFloat(data.CC_TECH_ADJ1_OUT));
					data.CC_STRATAGIC_FAILURE_RATE = data.CC_REAL_FAILURE_RATE * (1 + parseFloat(data.CC_TECH_ADJ2_OUT));
					if (!data.CC_TECH_ADJ1_CMT_OUT || data.CC_TECH_ADJ1_CMT_OUT.length == 0 || data.CC_TECH_ADJ1_CMT_OUT == 'FIRST RUN') {
					    if(!this.getView().getModel("local").getProperty(oControl.getBindingContext("local").getPath() + '/' + oState) || this.getView().getModel("local").getProperty(oControl.getBindingContext("local").getPath() + '/' + oState) == 'None'){
					    this._errorFields = 	this._errorFields + 1;
					        
					    }
						this.getView().getModel("local").setProperty(oControl.getBindingContext("local").getPath() + '/' + oState, "Error");
					}

				} else if (techAdjProperty === 'CC_TECH_ADJ2_OUT') {
					var data = this.getView().getModel("local").getProperty(oControl.getBindingContext("local").getPath());
					data.CC_STRATAGIC_FAILURE_RATE = data.CC_REAL_FAILURE_RATE * (1 + parseFloat(data.CC_TECH_ADJ2_OUT));
					if (!data.CC_TECH_ADJ2_CMT_OUT || data.CC_TECH_ADJ2_CMT_OUT.length == 0 || data.CC_TECH_ADJ2_CMT_OUT == 'FIRST RUN') {
					     if(!this.getView().getModel("local").getProperty(oControl.getBindingContext("local").getPath() + '/' + oState) || this.getView().getModel("local").getProperty(oControl.getBindingContext("local").getPath() + '/' + oState) == 'None'){
					    this._errorFields = 	this._errorFields + 1;
					        
					    }
						this.getView().getModel("local").setProperty(oControl.getBindingContext("local").getPath() + '/' + oState, "Error");
					}
				}
				return true;

			}

		},
		techAdj: function(val) {
			if (!val)
				return '00.00';
		}
		/*implementation for new technical input for adjustment*/

	});
});
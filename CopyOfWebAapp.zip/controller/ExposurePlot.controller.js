sap.ui.define([
	"sap/ui/core/mvc/Controller",
		'sap/m/Dialog',
		'sap/m/Text',
		'sap/m/Button',
        'sap/m/MessageToast',
        "sap/m/MessageBox",

        'sap/ui/model/json/JSONModel',
        "sap/viz/ui5/controls/VizFrame"
], function(Controller, Dialog, Text, Button, MessageToast, MessageBox, JSONModel, VizFrame) {
		"use strict";

		return Controller.extend("DtnaAspRP_ss.controller.ExposurePlot", {

				onInit: function() {

				},
				displayDetail: function(oEvent) {
					var that = this;
					var selectedChart = oEvent.getSource().getId();
                
					if (!this.chartDialog) {
						this.chartDialog = new sap.m.Dialog({
							contentWidth: "1300px",
							contentHeight: "950px",
							title: "Chart Detail",
							beginButton: new sap.m.Button({
								text: "Close",
								press: function() {
									this.chartDialog.close();
								}.bind(this)
							})
						});
						var frame = new VizFrame({
							id: "idVizFrameDialog",
							height: "580px",
							width: "1300px",
							vizType: "line"
						});
						var dropDown = new sap.m.Select("selType", {
							change: function(oEvent) {
								var selectedKey = oEvent.getSource().getSelectedKey();
							//	sap.ui.getCore().getElementById("idVizFrameDialog").getVizProperties().title.text
								var selectedModel = that._selectedModel ;
						        var selectedMonth = that._selectedMonth ;
								that.fillChart(sap.ui.getCore().getModel(selectedModel).getProperty("/data"), "idVizFrameDialog", selectedMonth, selectedKey);
							},
							items: [new sap.ui.core.Item({
									text: "EW Only",
									key: "EW"
								}), new sap.ui.core.Item({
									text: "BW Only",
									key: "BW"
								}),
			    new sap.ui.core.Item({
									text: "BW+EW",
									key: "TW"
								})]
						});
						var vBox = new sap.m.VBox();
						var vHBox1 = new sap.m.HBox({
							alignContent: "End",
							alignItems: "End"
						});
						vHBox1.addItem(dropDown);
						vBox.addItem(vHBox1);

						var HBox2 = new sap.m.HBox();
						HBox2.addItem(frame);
						vBox.addItem(HBox2);
						
						
						
						
						
						
							var table = new sap.m.Table({id:"chartTbl", width:"800px"}).addStyleClass("sapUiLargeMarginBegin sapUiSizeCompact");
								 vBox.addItem(table);  
						this.chartDialog.addContent(vBox);
						
						//this.fillChart(sap.ui.getCore().getModel("dataCollection").getProperty("/data"),"idVizFrameDialog","12 Months");

						//to get access to the global model
						this.getView().addDependent(this.chartDialog);

					}
					
					
					
				
				
					
					var CurrDataModelData = [];

					if (selectedChart.indexOf("firstFrameBtn") > -1) {
					    CurrDataModelData = sap.ui.getCore().getModel("dataModel24").getProperty("/data");
						this.fillChart(sap.ui.getCore().getModel("dataModel24").getProperty("/data"), "idVizFrameDialog", "24 Months", "EW");
						this._selectedModel =  "dataModel24";
						this._selectedMonth =  "24 Months";
						
					} else if (selectedChart.indexOf("secondFrameBtn") > -1) {
                        CurrDataModelData = sap.ui.getCore().getModel("dataModel36").getProperty("/data");
						this.fillChart(sap.ui.getCore().getModel("dataModel36").getProperty("/data"), "idVizFrameDialog", "36 Months", "EW");
						this._selectedModel =  "dataModel36";
						this._selectedMonth =  "36 Months";
					} else if (selectedChart.indexOf("thirdFrameBtn") > -1) {
					     CurrDataModelData = sap.ui.getCore().getModel("dataModel48").getProperty("/data");
						this.fillChart(sap.ui.getCore().getModel("dataModel48").getProperty("/data"), "idVizFrameDialog", "48 Months", "EW");
							this._selectedModel =  "dataModel48";
						this._selectedMonth =  "48 Months";
					} else if (selectedChart.indexOf("fourthFrameBtn") > -1) {
					     CurrDataModelData = sap.ui.getCore().getModel("dataModel60").getProperty("/data");
						this.fillChart(sap.ui.getCore().getModel("dataModel60").getProperty("/data"), "idVizFrameDialog", "60 Months", "EW");
							this._selectedModel =  "dataModel60";
						this._selectedMonth =  "60 Months";
					}

            	var ViewRatePlan = this.getOwnerComponent().getModel("local").getData().ViewRatePlan;
                	var yearSelected = ViewRatePlan.BASELINE_YEAR;
                    var numYearSel = parseInt(yearSelected);
					var columns = [this._selectedMonth,(numYearSel - 2) + "", (numYearSel - 1) + "", (numYearSel - 0) + "", (numYearSel + 1) + "", (numYearSel + 2) + "", (
							numYearSel + 3) + ""];
					var yearsAarry = [(numYearSel - 2) + "", (numYearSel - 1) + "", (numYearSel - 0) + "", (numYearSel + 1) + "", (numYearSel + 2) + "", (
							numYearSel + 3) + ""];
                    var table =sap.ui.getCore().getElementById("chartTbl");
                    table.removeAllColumns();
                    table.removeAllItems();
						for(var i=0; i<columns.length; i++){
								var oColumn = new sap.m.Column({
							        		header:[ new sap.m.Label({text:columns[i] }).addStyleClass("blueColor")]
							        		});
							        		table.addColumn(oColumn);
						}	
                        			var totalUnits =[];
                        			var maxValues = [0,0,0,0,0,0];
                                    			for(var i = 0; i<CurrDataModelData.length;i++){
                                    				for(var j=0; j<yearsAarry.length;j++){
                                    						if(CurrDataModelData[i].TOTAL_UNITS_2013 > maxValues[j]){
                                    							maxValues[j] = CurrDataModelData[i]["TOTAL_UNITS_"+yearsAarry[j]];
                                    						}
                                    				}
                                    			
                                    			}
                        	 var item =   new sap.m.ColumnListItem({
								        cells:[
								               new sap.m.Text({text:"Contracts"}).addStyleClass("blueColor"),
								               new sap.m.Text({text:maxValues[0] }),
								               new sap.m.Text({text:maxValues[1] }),
								               new sap.m.Text({text:maxValues[2] }),
								               new sap.m.Text({text:maxValues[3] }),
								               new sap.m.Text({text:maxValues[4] }),
								               new sap.m.Text({text:maxValues[5] })
								               ]
								        });
								        table.addItem(item);
								         var item2 =   new sap.m.ColumnListItem({
								        cells:[
								               new sap.m.Text({text:"Maturity"}).addStyleClass("blueColor"),
								               new sap.m.Text({text:"25" }),
								               new sap.m.Text({text:"13"}),
								               new sap.m.Text({text:"265" }),
								               new sap.m.Text({text:"137"}),
								               new sap.m.Text({text:"1"}),
								                new sap.m.Text({text:"99"})
								               ]
								        });
								        table.addItem(item2);
                        			console.log(maxValues);


					this.chartDialog.open();
				},

				GenerateCostCurveEng: function() {
				    this.getView().byId("firstFrameBtn").setVisible(true);
                    this.getView().byId("secondFrameBtn").setVisible(true);
                    this.getView().byId("thirdFrameBtn").setVisible(true);
                    this.getView().byId("fourthFrameBtn").setVisible(true);
                    
                    var monthData = [24, 36, 48, 60];
				
					var vocCat = this.getView().byId("vocationChassis").getSelectedKey() || "STANDARD";
					var torque = '';
				//	var parDate = "datetime'2018-11-01";

					var parDOMCountryCD = this.getView().byId("domicileChassis").getSelectedKey() || 'USA AND CAN';

					var parDEDUCT_AMT = 0;
					var parCVRG_GROUP = this.getView().byId("coverageChassis").getValue();
					var ViewRatePlan = this.getOwnerComponent().getModel("local").getData().ViewRatePlan;
					var oCommonModel = this.getOwnerComponent().getModel("oCommonModel");
					
					console.log(oCommonModel.getProperty("/VMRS_33_CD"));
					var vmrsGroup = oCommonModel.getProperty("/VMRS_33_CD");
					var yearSelected = ViewRatePlan.BASELINE_YEAR;
					var parRATE_PLAN_ID = ViewRatePlan.RATE_PLAN_ID;
					var prdType = ViewRatePlan.PRODUCT_TYPE;
					var PRD_TYP_CD = ViewRatePlan.PORTFOLIO_NAME;
						var parDate = "datetime'" +ViewRatePlan.RATE_PLAN_CUTOFF_DT + "'";
					console.log(ViewRatePlan);
                    this.busyDialog = new  sap.m.BusyDialog({title : "Loading Data", text :"Fetching Data from Server"});
                    this.getView().addDependent(this.busyDialog);
                    this.busyDialog.open();
					for (var monthCounter = 0; monthCounter < monthData.length; monthCounter++) {
						var parMonths = monthData[monthCounter];

						var odataURL = "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/ASPRATEPLAN.xsodata/";
						var srvURL = "EXP_PLOTParameters(parIN_SRVC_YR=" +
							yearSelected + ",parPRODUCT_TYPE='" + prdType + "',parVOC_CATEGORY='" + vocCat + "',parTORQUE='" + torque + "',parVMRS_GROUP='" +
							vmrsGroup +
							"',parPRD_TYP_CD='" + PRD_TYP_CD + "',parDATE=" + parDate + "',parCVRG_MONTHS=" + parMonths + ",parDOMCL_CNTRY_CD='" +
							parDOMCountryCD +
							"',parRATE_PLAN_ID=" + parRATE_PLAN_ID + ",parDEDUCT_AMT=" + parDEDUCT_AMT + ",parCVRG_GROUP='" + parCVRG_GROUP +
							"')/Execute?$format=json";
						var dataModel = new sap.ui.model.json.JSONModel();
						//	 dataModel.loadData("./model/CHASSIS24.json","",false);
						dataModel.loadData(odataURL + srvURL, "", false);
						var data = dataModel.getProperty("/d/results");
						var numYearSel = parseInt(yearSelected);
						var yearsAarry = [(numYearSel - 2) + "", (numYearSel - 1) + "", (numYearSel - 0) + "", (numYearSel + 1) + "", (numYearSel + 2) + "", (
							numYearSel + 3) + ""];

						var allObj = [];

						for (var count = 0; count < parMonths && count < data.length; count++) {
							var obj = {};
							obj.MIS = data[count].MIS;
							for (var yearVal = 0; yearVal < yearsAarry.length; yearVal++) {
								obj[["EW_Year_" + yearsAarry[yearVal]]] = data[count + (parMonths * yearVal)].EW_PER_UNIT;
								obj[["BW_Year_" + yearsAarry[yearVal]]] = data[count + (parMonths * yearVal)].BW_PER_UNIT;
								obj[["TW_Year_" + yearsAarry[yearVal]]] = data[count + (parMonths * yearVal)].TW_PER_UNIT;
					        	obj[["TOTAL_UNITS_" +yearsAarry[yearVal]]] = data[count+(parMonths*yearVal)].TOTAL_UNITS;
							}
							allObj.push(obj);

						}
						if (parMonths == 24) {
							var dataModel24 = new sap.ui.model.json.JSONModel();
							dataModel24.setData({
								data: allObj
							});
							sap.ui.getCore().setModel(dataModel24, "dataModel24");
								this.fillChart(allObj, "idVizFrameOne", "24 Months", "EW");
						} else if (parMonths == 36) {
							var dataModel36 = new sap.ui.model.json.JSONModel();
							dataModel36.setData({
								data: allObj
							});
							sap.ui.getCore().setModel(dataModel36, "dataModel36");
								this.fillChart(allObj, "idVizFrameTwo", "36 Months", "EW");
						} else if (parMonths == 48) {
							var dataModel48 = new sap.ui.model.json.JSONModel();
							dataModel48.setData({
								data: allObj
							});

							sap.ui.getCore().setModel(dataModel48, "dataModel48");
								this.fillChart(allObj, "idVizFrameThree", "48 Months", "EW");
						} else if (parMonths == 60) {
							var dataModel60 = new sap.ui.model.json.JSONModel();
							dataModel60.setData({
								data: allObj
							});
							sap.ui.getCore().setModel(dataModel60, "dataModel60");
								this.fillChart(allObj, "idVizFrameFour", "60 Months", "EW");
						}
					}
					 this.busyDialog.close();

						//   console.log(allObj);
					
					
					
					/*
						var dataCollectionModel = new sap.ui.model.json.JSONModel();
						dataCollectionModel.setData({
							data: allObj
						});
						sap.ui.getCore().setModel(dataCollectionModel, "dataCollection");*/

					},

					fillChart: function(monthData, chartId, chartTitle, bindCode) {

						//	var monthData =	 this.getChartData(24);
						//	console.log(monthData);
						var LineChartOne = this.getView().byId(chartId) || sap.ui.getCore().getElementById(chartId);
						var dataModel = new sap.ui.model.json.JSONModel();
						dataModel.setData({
							data: monthData
						});
						LineChartOne.setModel(dataModel);
						LineChartOne.setUiConfig({
							"applicationSet": "fiori"
						});

						var measuresArray = [];
						var ViewRatePlan = this.getOwnerComponent().getModel("local").getData().ViewRatePlan;
						var yearSelected = ViewRatePlan.BASELINE_YEAR;
						var data = dataModel.getProperty("/d/results");
						var numYearSel = parseInt(yearSelected);
						var yearsAarry = [(numYearSel - 2) + "", (numYearSel - 1) + "", (numYearSel - 0) + "", (numYearSel + 1) + "", (numYearSel + 2) + "", (
							numYearSel + 3) + ""];
						for (var i = 0; i < yearsAarry.length; i++) {

							strYear = bindCode + "_Year_" + yearsAarry[i];
							measuresArray.push({
								name: strYear,
								value: '{' + strYear + '}'
							});
						}
						var oDataset = new sap.viz.ui5.data.FlattenedDataset({
							dimensions: [{
								axis: 1,
								name: 'MIS',
								value: '{MIS}'
				}],
							measures: measuresArray,

							data: {
								path: '/data'
							}
						});
						LineChartOne.setDataset(oDataset);

						var dimentionFeed = new sap.viz.ui5.controls.common.feeds.FeedItem({
							'uid': "categoryAxis",
							//	   'id' :"categoryAxisFeed",
							'type': "Dimension",
							'values': ["MIS"]
						});
						LineChartOne.destroyFeeds();

						for (var i = 0; i < yearsAarry.length; i++) {
							var strYear = bindCode + "_Year_" + yearsAarry[i];
							var valueFeed = new sap.viz.ui5.controls.common.feeds.FeedItem({
								'uid': "valueAxis",
								'type': "Measure",
								'values': [strYear]
							});
							LineChartOne.addFeed(valueFeed);

						}

						/*	var valueFeed1 = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "valueAxis",
				'type': "Measure",
				'values': ["Year_2013"]
			});
			var valueFeed2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "valueAxis",
				'type': "Measure",
				'values': ["Year_2014"]
			});
			var valueFeed3 = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "valueAxis",
				'type': "Measure",
				'values': ["Year_2015"]
			});
			var valueFeed4 = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "valueAxis",
				'type': "Measure",
				'values': ["Year_2016"]
			});
			var valueFeed5 = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "valueAxis",
				'type': "Measure",
				'values': ["Year_2017"]
			});
			LineChartOne.destroyFeeds();
			LineChartOne.addFeed(valueFeed1);
			LineChartOne.addFeed(valueFeed2);
			LineChartOne.addFeed(valueFeed3);
			LineChartOne.addFeed(valueFeed4);
			LineChartOne.addFeed(valueFeed5);*/

						LineChartOne.addFeed(dimentionFeed);

						LineChartOne.setVizProperties({
							dataLabel: {
								visible: true
							},
							legend: {
								title: {
									visible: true
								}
							},
							title: {
								visible: true,
								text: chartTitle
							},
							valueAxis: {

								title: {
									visible: true,
									text: "EW_PER_UNIT Cost" //Add custom title to Value Axis  
								}
							}
						});

					},

					onInitold: function() {

						var dataModel = new sap.ui.model.json.JSONModel();
						dataModel.loadData("./model/CHASSIS24.json", "", false);
						var data = dataModel.getProperty("/d/results");
						var yearsAarry = ["2013", "2014", "2015", "2016", "2017"];
						var allObj = [];
						for (var count = 0; count < 24; count++) {
							var obj = {};
							obj.MIS = data[count].MIS;
							for (var yearVal = 0; yearVal < yearsAarry.length; yearVal++) {
								obj[["Year_" + yearsAarry[yearVal]]] = data[count + (24 * yearVal)].EW_PER_UNIT;
								/*obj[yearsAarry[1]] = data[count+(24*1)].EW_PER_UNIT;
	        			obj[yearsAarry[2]] = data[count+(24*2)].EW_PER_UNIT;
	        	   		obj[yearsAarry[3]] = data[count+(24*3)].EW_PER_UNIT;
	        	  		obj[yearsAarry[4]] = data[count+(24*4)].EW_PER_UNIT;*/
							}
							allObj.push(obj);
						}
						//   console.log(allObj);
						this.fillChart(allObj, "idVizFrameChart1");

						// 36 Months Data	  
						var dataModel36 = new sap.ui.model.json.JSONModel();
						dataModel36.loadData("./model/CHASSIS36.json", "", false);
						var data36 = dataModel36.getProperty("/d/results");
						var yearsAarry36 = ["2013", "2014", "2015", "2016", "2017"];
						var allObj36 = [];
						for (var count = 0; count < 36; count++) {
							var obj36 = {};
							obj36.MIS = data36[count].MIS;
							for (var yearVal = 0; yearVal < yearsAarry36.length; yearVal++) {
								obj[["Year_" + yearsAarry36[yearVal]]] = data36[count + (36 * yearVal)].EW_PER_UNIT;
								/*obj[yearsAarry[1]] = data[count+(24*1)].EW_PER_UNIT;
	        			obj[yearsAarry[2]] = data[count+(24*2)].EW_PER_UNIT;
	        	   		obj[yearsAarry[3]] = data[count+(24*3)].EW_PER_UNIT;
	        	  		obj[yearsAarry[4]] = data[count+(24*4)].EW_PER_UNIT;*/
							}
							allObj36.push(obj36);
						}
						//   console.log(allObj);
						this.fillChart(allObj, "idVizFrameChart1");
						this.fillChart(allObj36, "idVizFrameChart2");
						this.fillChart(allObj, "idVizFrameChart3");
						this.fillChart(allObj, "idVizFrameChart4");

					},
					/* getChartData : function(range){
        	 var dataModel = new sap.ui.model.json.JSONModel();
        	 dataModel.loadData("./model/data.json","",false);
        	 var data = dataModel.getProperty("/data");
        	 var finalData = [];
        	 var total = data.length;
        	 var step = parseInt(total / range,10) * 4;
        	var stepObj={"60":4,"48":3,"36":3,"24":2};
        	 var i = total - 1;
        	 var minVal = range;
        	 var count = 0;
        	while(i >= 0){
        			finalData.push(data[i]);
        			count ++;
        			i--;
        			if(count >= range){
        				break;
        			}
        	}
        	 
        	 
        	 return finalData.reverse();
        	 
        },*/

					fillChartold: function(monthData, chartId) {

						//	var monthData =	 this.getChartData(24);
						//	console.log(monthData);
						var LineChartOne = this.getView().byId(chartId);
						var LineChart2 = this.getView().byId("idVizFrameChart2");
						var dataModel = new sap.ui.model.json.JSONModel();
						dataModel.setData({
							data: monthData
						});
						LineChartOne.setModel(dataModel);
						LineChartOne.setUiConfig({
							//	"applicationSet": "fiori"
						});
						var oDataset = new sap.viz.ui5.data.FlattenedDataset({
							dimensions: [{
								axis: 1,
								name: 'MIS',
								value: '{MIS}'
				}],
							measures: [
								{
									name: 'Year_2013',
									value: '{Year_2013}'
					},
								{
									name: 'Year_2014',
									value: '{Year_2014}'
					},
								{
									name: 'Year_2015',
									value: '{Year_2015}'
					},
								{
									name: 'Year_2016',
									value: '{Year_2016}'
					},
								{
									name: 'Year_2017',
									value: '{Year_2017}'
					}
					],
							data: {
								path: '/data'
								// Filter: "oFilters"
							}
						});
						LineChartOne.setDataset(oDataset);

						LineChartOne.setVizProperties({
							dataLabel: {
								visible: false
							},
							legend: {
								title: {
									visible: false
								}
							},
							title: {
								visible: true,
								text: "24 Months"
							},
							valueAxis: {

								title: {
									visible: true,
									text: "EW Cost Per Unit" //Add custom title to Value Axis  
								}
							}
						});

					},
					navToExpPlotChassis: function(chartClicked) {
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("ExposurePlotFrag", true);
					}

				});
		});
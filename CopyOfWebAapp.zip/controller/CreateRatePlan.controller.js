var that = this;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	'sap/m/MessagePopover',
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	'sap/ui/core/Item'
], function(Controller, MessageBox, MessagePopover, Filter, FilterOperator, Item) {
	"use strict";

	// Code after adding as contributor
	return Controller.extend("DtnaAspRP_ss.controller.CreateRatePlan", {

		onInit: function() {
			this.router = this.getOwnerComponent().getRouter();
			this._formFragments = [];
			this.getView().byId("CreateRatePlanWizard").mAggregations._progressNavigator.attachStepChanged(this._attachStepChanged);
			this.router.getRoute("createrateplan").attachPatternMatched(this._onPatternMatched, this);

		},

		_onPatternMatched: function(oEvent) {

			var ratePlanID = oEvent.getParameter("arguments").rate_plan_id;

			var that = this;
			if (ratePlanID) {

				this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen = 2;
				//this.getView().byId("saverate").setEnabled(false);
				this.getView().byId("generatedriver").setEnabled(true);

				var mParameters = {

					success: function(oData) {

						if (that.getView().getModel("local").getData().rateplanvisibility.selectedStep == 1) {

							/*that.getView().byId('CreateRatePlanWizard').goToStep("blSelection");
										that.getView().byId('CreateRatePlanWizard').nextStep();*/

							that.getView().byId('CreateRatePlanWizard').goToStep("blSelection");
							that.getView().byId('CreateRatePlanWizard').nextStep();
							that.getView().byId('CreateRatePlanWizard').nextStep();

							that.getView().byId('CreateRatePlanWizard')._getProgressNavigator()._moveToStep(1);

						} else {

							that.getView().byId('CreateRatePlanWizard').goToStep(that.getView().getId() + "--" + "CostDriver");
							that.getView().byId('CreateRatePlanWizard')._getProgressNavigator()._moveToStep(3);

						}

						that.getView().getModel("local").getData().NewRatePlan = oData.results[0];

						var cutoffdate = oData.results[0].RATE_PLAN_CUTOFF_DT;
						var createdDate = oData.results[0].CREATED_DT;

						var formateddate = cutoffdate.split("/")[2] + "-" + cutoffdate.split("/")[0] + "-" + cutoffdate.split("/")[1];
						that.getView().getModel("local").getData().ViewRatePlan = oData.results[0];
						that.getView().getModel("local").getData().NewRatePlan.RATE_PLAN_CUTOFF_DT = formateddate;
						that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_CUTOFF_DT = that.getView().getModel("local").getData().NewRatePlan
							.RATE_PLAN_CUTOFF_DT;

						formateddate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
						that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT = formateddate;
						that.getView().getModel("local").getData().NewRatePlan.CREATED_DT = that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;

						if (that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_STATUS == "FINALIZED") {
							that.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen = 3;
						}

					},
					error: function(oError) {
						this.router.navTo("Main");

					}

				};

				that.getOwnerComponent().getModel().read("/CV_RP_UPDATE_RATE_PLANParameters(ParRATE_PLAN_ID=" + ratePlanID + ")/Execute",
					mParameters);
			} else {
				this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen = 1;
				this.getView().byId("saverate").setEnabled(true);
				this.getView().byId("generatedriver").setEnabled(false);
			}

		},

		_attachStepChanged: function(oEvent) {
			var view = oEvent.getSource().getParent().getParent().getParent().getParent();
			view.getModel("local").getData().rateplanvisibility.selectedStep = oEvent.getSource().getCurrentStep();

			if (oEvent.getSource().getCurrentStep() == 2) {

				view.getController().costDriver();
			} else if (oEvent.getSource().getCurrentStep() == 3) {
                if (view.byId('port').getValue() == "Engine" || view.byId('port').getValue() == "ENGINE") {
							view.getModel("local").getData().rateplanvisibility.costCurveBtn = 2;
						}
						
						else {
						   view.getModel("local").getData().rateplanvisibility.costCurveBtn = 1;
						}
				view.getModel("local").refresh(true);
				var mParameters = {

					success: function(oData) {
						
						view.getController()._showFormFragment("CostDriversForSelection", "costdriverlayout");
						view.getModel("local").getData().rateplanvisibility.selectedStep = 3;

						view.getModel("local").getData().vmrsSelection = oData.results;

						view.getModel("local").refresh(true);

						sap.ui.core.BusyIndicator.hide();
					},
					error: function(error) {

					}
				};
				view.getController().getOwnerComponent().getModel().read("/CV_VMRS_SELECTION_ALL_OTHERSParameters(ParRATE_PLAN_ID=" + view.getModel(
					"local").getData().NewRatePlan.RATE_PLAN_ID + ")/Execute", mParameters);

			}

		},

		_onRouteObjectMatched: function() {
			var oCommonModel = this.getOwnerComponent().getModel("oCommonModel");
			oCommonModel.setProperty("/CostPerClaimSave", false);

		},

		onBeforeRendering: function() {
			this.getView().byId("DPEF").setMaxDate(new Date());
		},

		refresh: function() {

			if (!this.getView().byId("DPEF").getValue().length == 0)

			{

				var temp = [];

				var year = this.getView().byId("DPEF").getDateValue().getFullYear();
				var month = this.getView().byId("DPEF").getDateValue().getMonth();

				var maxyear = year + 1;

				temp.push({
					years: maxyear,
					months: 0
				});

				for (var i = this.getView().byId("DPEF").getDateValue().getFullYear(); i <= this.getView().byId("DPEF").getDateValue().getFullYear(); i--)

					if (i == this.getView().byId("DPEF").getDateValue().getFullYear() - 7) {
					break;
				} else if (i == this.getView().byId("DPEF").getDateValue().getFullYear()) {

					temp.push({
						years: i,
						months: 0

					});
				} else if (i == this.getView().byId("DPEF").getDateValue().getFullYear() - 1) {

					temp.push({
						years: i,
						months: month

					});
				} else {

					temp.push({
						years: i,
						months: month = month + 12

					});
				}

				temp.reverse();

				this.getView().getModel("local").getData().Baseline = temp;

			} else {

				this.getView().byId("DPEF").setValueState(sap.ui.core.ValueState.Warning);
				this.getView().byId("DPEF").setValueStateText("Please enter valid date");
			}
		},

		handleChange: function() {
			this.getView().byId("DPEF").setValueState(sap.ui.core.ValueState.none);

		},

		saveRate: function() {

			if (this.getView().byId("port").getValue().length == 0 || this.getView().byId("product").getValue().length == 0 || this.getView().byId(
					"inflation").getValue().length == 0 || this.getView().byId("DPEF").getValue().length == 0 || this.getView().byId("rateplandes").getValue()
				.length == 0 || this.getView().byId("ratetable").getSelectedItem() ==
				null && this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen == 1) {

				MessageBox.error("Please Enter/Select all mandatory fields ");

			} else {

				if (this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen == 1) {
					var path = this.getView().byId("ratetable").getSelectedItem().getBindingContextPath();
					var inserviceYear = this.getView().byId("ratetable").getModel("local").getProperty(path).years;
				}

				this.getView().byId("generatedriver").setEnabled(true);
				that = this;
				var newData = this.getView().getModel("local").getProperty("/NewRatePlan");

				var user = this.getView().getModel("UserInfo").getData().userName;
				this.insertData = {};
				this.insertData.PORTFOLIO_NAME = newData.PORTFOLIO_NAME.toUpperCase();
				this.insertData.PRODUCT_TYPE = newData.PRODUCT_TYPE;
				this.insertData.RATE_PLAN_CUTOFF_DT = newData.RATE_PLAN_CUTOFF_DT;
				var newDate = new Date();
				var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
				this.insertData.CREATED_DT = currentDate;
				this.insertData.RATE_PLAN_START_DT = this.insertData.CREATED_DT;
				this.insertData.BASELINE_YEAR = inserviceYear;
				this.insertData.INFLATION_RATE = newData.INFLATION_RATE;
				this.insertData.RATE_PLAN_DESC = newData.RATE_PLAN_DESC
				this.insertData.CREATED_USER = user;
				this.insertData.RATE_PLAN_STATUS = "DRAFT"; // To Be removed later once added to XSJS
				this.insertData.EMISSION = this.getView().byId("Emission").getText();

				if (this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen === 2) {

					this.insertData.RATE_PLAN_ID = this.getView().getModel("local").getData().NewRatePlan.RATE_PLAN_ID;
				}

				//new xsjs for Create
				var newData = JSON.stringify(this.insertData);
				jQuery.ajax({

					url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CreateNewRatePlan.xsjs",
					type: "POST",
					async: false,
					method: 'GET',
					dataType: 'text',
					data: {
						dataObject: newData
					},
					success: function(data) {
						/*refresh the table data after successful insertion*/
						if (data) {
							that.getView().getModel("local").getData().ViewRatePlan = JSON.parse(data)[0];
							that.getView().getModel().refresh(true);

							if (that.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen === 1) {
								sap.m.MessageBox.show("Rate Plan " + that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID +
									" is Created Successfully", {
										icon: sap.m.MessageBox.Icon.SUCCESS,
										title: "Success",
										actions: [sap.m.MessageBox.Action.CLOSE],

										contentWidth: "100px"

									});

							} else {

								sap.m.MessageBox.show("Rate Plan " + that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID +
									" is Updated Successfully", {
										icon: sap.m.MessageBox.Icon.SUCCESS,
										title: "Success",
										actions: [sap.m.MessageBox.Action.CLOSE],

										contentWidth: "100px"

									});

							}

						}
					},
					error: function(oError) {
						sap.m.MessageBox.error(oError.responseText);
					}
				});
				// new sxjs

			}

		},
		_getFormFragment: function(sFragmentName) {
			var oFormFragment = this._formFragments[sFragmentName];

			if (oFormFragment) {
				return oFormFragment;
			}

			oFormFragment = sap.ui.xmlfragment(this.getView().getId(), "DtnaAspRP_ss.Fragment." + sFragmentName, this);

			this._formFragments[sFragmentName] = oFormFragment;
			return this._formFragments[sFragmentName];
		},

		_showFormFragment: function(sFragmentName, sLayout) {

			var layout = this.getView().byId(sLayout);
			var oPage = this.getView().byId('rateplangrid');
			oPage.setVisible(false);
			layout.insertContent(this._getFormFragment(sFragmentName));
		},

		costDriver: function() {
			this.getView().getModel("local").getData().pareto = [];
			this.getView().getModel("local").refresh(true);
			sap.ui.core.BusyIndicator.show();
			/*bug selected step*/
			var wizard = this.getView().byId('CreateRatePlanWizard');
			var wnav = wizard._getProgressNavigator();
			if (wizard.getCurrentStep() == this.getView().getId() + "--" + "blSelection") {
				wizard.nextStep();
			} else {
				wizard.goToStep(this.getView().getId() + "--" + "CostDriverSelection");
				wnav._moveToStep(2);
			}

			/*end of bug selected step*/

			this.getView().getModel("local").getData().rateplanvisibility.selectedStep = 2;

			if (this.frag) {
				this.frag.destroy();
				this.frag = null;
				this.frag = sap.ui.xmlfragment(this.getView().getId(), "DtnaAspRP_ss.Fragment." + "Vmrspareto", this);
				var layout = this.getView().byId("paretolayout");
				layout.insertContent(this.frag);
			} else {
				this.frag = sap.ui.xmlfragment(this.getView().getId(), "DtnaAspRP_ss.Fragment." + "Vmrspareto", this);

				var layout = this.getView().byId("paretolayout");
				layout.insertContent(this.frag);
			}

			if (this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen === 1) {

				/*var path = this.getView().byId("ratetable").getSelectedItem().getBindingContextPath();
				var inserviceYear = this.getView().byId("ratetable").getModel("local").getProperty(path).years;*/
				var model = this.getOwnerComponent().getModel();
				var dt = this.getView().byId('DPEF').getValue();
				var mParameters;
				var results;

				var that = this;

				mParameters = {
					urlParameters: {
						"$orderby": "VMRS_33_CD,IN_SRVC_YR"
					},
					async: false,
					success: function(oData) {

						if (oData.results.length == 0) {
							sap.ui.core.BusyIndicator.hide();
							MessageBox.information("No Data exists , Please contact HANA Technical team");

						} else {
							results = oData.results;

							var newData = [];
							var rankdet = [];

							var length = results.length;
							var SUM_EXT_CLAIM_COST_USD;
							var CLAIM_COUNT;
							var rank;
							var nval = results[0].VMRS_33_CD;
							var i = 0;
							var inserviceYear;
							//to be changed later
							if (that.getView().byId("ratetable").getSelectedItem()) {
								var path = that.getView().byId("ratetable").getSelectedItem().getBindingContextPath();
								inserviceYear = that.getView().byId("ratetable").getModel("local").getProperty(path).years;

							} else {
								inserviceYear = that.getView().getModel("local").getData().ViewRatePlan.BASELINE_YEAR;

							}

							//new for loop
							var data = oData.results;
							for (var i = 0; i < data.length; i++) {

								if (data[i].VMRS_33_CD == nval) {
									rankdet.push({
										rank: data[i].RANK,
										yr: data[i].IN_SRVC_YR
									});

								}

								if (data[i].VMRS_33_CD != nval || i == length - 1) {

									newData.push({
										VMRS_33_CD: nval,
										VMRS_33_ASSEMB_DESC: data[i - 1].VMRS_33_ASSEMB_DESC,
										CLAIM_COUNT: CLAIM_COUNT,
										RANK: rank,
										SUM_EXT_CLAIM_COST_USD: SUM_EXT_CLAIM_COST_USD,

										rankInfo: rankdet
									});
									nval = data[i].VMRS_33_CD;
									rankdet = [];
									rank = "";
									CLAIM_COUNT = "";
									SUM_EXT_CLAIM_COST_USD = "";

									rankdet.push({
										rank: data[i].RANK,
										yr: data[i].IN_SRVC_YR
									});

								}
								if (data[i].IN_SRVC_YR == inserviceYear) {

									rank = data[i].RANK;
									CLAIM_COUNT = data[i].CLAIM_COUNT;
									SUM_EXT_CLAIM_COST_USD = data[i].SUM_EXT_CLAIM_COST_USD;

								}
							}

							that.getView().getModel("local").getData().pareto = newData;
							that.getView().getModel("local").refresh(true);
							sap.ui.core.BusyIndicator.hide();

						}

					},
					error: function(oError) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageBox.show("ASPRP application encountered an Error", {
							icon: sap.m.MessageBox.Icon.ERROR,
							contentWidth: "100px"

						});

					}

				};

				model.read(
					"/CV_PARETOParameters(ParIN_SRVC_YR=" + this.getView().getModel("local").getData().ViewRatePlan.BASELINE_YEAR +
					",ParENDDATE=datetime'" + this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_CUTOFF_DT +
					"',ParPRD_TYP_CD='" + this.getView().getModel("local").getData().ViewRatePlan.PORTFOLIO_NAME + "',ParEMISSION='" + this.getView().getModel(
						"local").getData().ViewRatePlan.EMISSION + "')/Execute",
					mParameters);

			} else {
				var createdDate = this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_CUTOFF_DT;
				//var formateddate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
				var that = this;
				var oModel = new sap.ui.model.odata.v2.ODataModel("/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/ASPRATEPLAN.xsodata");
				this.getView().setModel(oModel, "oModel");

				var mParametersOne = {
					success: function(oData) {

						if (oData.results.length == 0) {

							that.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen = 1;
							that.costDriver();

						} else {

							results = oData.results;

							var newData = [];
							var rankdet = [];

							var length = results.length;
							var SUM_EXT_CLAIM_COST_USD;

							var CLAIM_COUNT;
							var rank;
							var SELECTION_FLAG;
							var nval = results[0].VMRS_33_CD;
							var i = 0;
							//to be changed later

							//var path = that.getView().byId("ratetable").getSelectedItem().getBindingContextPath();
							var inserviceYear = that.getView().getModel("local").getData().ViewRatePlan.BASELINE_YEAR;

							//new for loop
							var data = oData.results;
							for (var i = 0; i < data.length; i++) {

								if (data[i].VMRS_33_CD == nval) {
									rankdet.push({
										rank: data[i].RANK,
										yr: data[i].IN_SRVC_YR
									});

								}

								if (data[i].VMRS_33_CD != nval || i == length - 1) {

									newData.push({
										VMRS_33_CD: nval,
										VMRS_33_ASSEMB_DESC: data[i - 1].VMRS_33_ASSEMB_DESC,
										CLAIM_COUNT: CLAIM_COUNT,
										RANK: rank,
										SUM_EXT_CLAIM_COST_USD: SUM_EXT_CLAIM_COST_USD,
										SELECTION_FLAG: SELECTION_FLAG,

										rankInfo: rankdet
									});
									nval = data[i].VMRS_33_CD;
									rankdet = [];
									SELECTION_FLAG = "";
									rank = "";
									CLAIM_COUNT = "";
									SUM_EXT_CLAIM_COST_USD = "";

									rankdet.push({
										rank: data[i].RANK,
										yr: data[i].IN_SRVC_YR
									});

								}
								if (data[i].IN_SRVC_YR == inserviceYear) {

									rank = data[i].RANK;
									SELECTION_FLAG = data[i].SELECTION_FLAG;
									CLAIM_COUNT = data[i].CLAIM_COUNT;
									SUM_EXT_CLAIM_COST_USD = data[i].SUM_EXT_CLAIM_COST_USD;

								}
							}

							that.getView().getModel("local").getData().pareto = newData;

							that.getView().getModel("local").refresh(true);

							sap.ui.core.BusyIndicator.hide();
						}

					},
					error: function(oError) {
						sap.ui.core.BusyIndicator.hide();
						alert("error");
					}

				};

				oModel.read("/CV_RP_SELECTED_VMRS_PARETOParameters(ParRATE_PLAN_ID=" + this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID +
					"," + "ParENDDATE=" + "datetime'" + createdDate + "'" + "," + "ParEMISSION='" + this.getView().getModel("local").getData().ViewRatePlan
					.EMISSION + "'," + "ParPRD_TYP_CD='" + this.getView().getModel("local").getData().ViewRatePlan.PORTFOLIO_NAME + "',ParIN_SRVC_YR=" +
					this.getView().getModel("local").getData().ViewRatePlan.BASELINE_YEAR + ")/Execute", mParametersOne);

			}

		},

		viewRatePlanning: function(oEvent) {

			if (this.getView().byId("vmrscodetab").getSelectedItem() == null) {

				MessageBox.error("Please select VMRS code for Rate Planning ");

			} else {
				if (this.getView().byId('port').getValue() == "Engine" || this.getView().byId('port').getValue() == "ENGINE") {
					this.getView().getModel("local").getData().rateplanvisibility.costCurveBtn = 2;
				}
				else {
				    this.getView().getModel("local").getData().rateplanvisibility.costCurveBtn = 1;
				    
				}
				this.getView().byId('CreateRatePlanWizard').nextStep();
				this.getView().getModel("local").getData().rateplanvisibility.selectedStep = 3;
				this._showFormFragment("CostDriversForSelection", "costdriverlayout");

				/*sending the selected vmrs,inserted time,created user, rateplan id */
				var model = this.getView().byId("vmrscodetab").getModel("local");
				var contexts = this.getView().byId("vmrscodetab").getSelectedContextPaths();
				var SelectedData = []; //selected rows to insert to table
				this.selectedVMRS = []; //selected VMRS code for view

				var ratePlanId = this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID;
				var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
				var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];

				//new changes
				var tableItems = this.getView().byId("vmrscodetab").getItems();
				var newRecords = [];
				var final = [];
				var that = this;
				var flag, path, existFlag = false;
				var modelData = this.getView().getModel("local").getData().pareto;

				for (var i = 0; i < tableItems.length; i++) {
					path = tableItems[i].getBindingContextPath("local");
					if (!model.getProperty(path).VMRS_33_ASSEMB_DESC) {
						model.getProperty(path).VMRS_33_ASSEMB_DESC = " ";
					}
					if (tableItems[i].getSelected()) {
						flag = 1;
					} else {
						flag = 0;
					}

					newRecords.push({
						VMRS_33_CD: model.getProperty(path).VMRS_33_CD,
						RATE_PLAN_ID: this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID,
						CREATED_DT: createdDate,
						CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
						SELECTION_FLAG: flag,
						VMRS_33_DESC: model.getProperty(path).VMRS_33_ASSEMB_DESC
					});

				}

				for (i = 0; i < modelData.length; i++) {
					for (var j = 0; j < newRecords.length; j++) {
						if (modelData[i].VMRS_33_CD == newRecords[j].VMRS_33_CD) {
							existFlag = true;
							break;
						}

					}
					if (existFlag == false) {
						if (!modelData[i].VMRS_33_ASSEMB_DESC) {
							modelData[i].VMRS_33_ASSEMB_DESC = " ";
						}
						final.push({
							VMRS_33_CD: modelData[i].VMRS_33_CD,
							RATE_PLAN_ID: this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID,
							CREATED_DT: createdDate,
							CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
							SELECTION_FLAG: 0,
							VMRS_33_DESC: modelData[i].VMRS_33_ASSEMB_DESC
						});
						existFlag = false;

					} else {
						existFlag = false;
					}
				}
				newRecords = newRecords.concat(final);
				jQuery.ajax({
					url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/VMRSInsert.xsjs",
					type: "POST",
					async: false,
					method: 'POST',
					dataType: 'text',
					data: {
						dataObject: JSON.stringify(newRecords)

					},
					success: function(data) {
						var omodel = that.getOwnerComponent().getModel();
						var rateplanId = that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID;
						var mParameters = {
							/*	urlParameters: {
								"$orderby": "SEQ"
							},*/
							success: function(oData) {
								that.getView().byId('CreateRatePlanWizard').goToStep(that.getView().getId() + "--" + "costdriverplan");
								that.getView().byId('CreateRatePlanWizard')._getProgressNavigator()._moveToStep(3);
								that.getView().getModel("local").getData().vmrsSelection = oData.results;
								that.getView().getModel("local").refresh(true);
								sap.ui.core.BusyIndicator.hide();
							},
							error: function(error) {

							}
						};
						omodel.read("/CV_VMRS_SELECTION_ALL_OTHERSParameters(ParRATE_PLAN_ID=" + rateplanId + ")/Execute", mParameters);

						//end of vmrsselection view

						/*new VMRS selection view*/
						/*	var mParameters = {
						
							success: function(oData) {
								that.getView().getModel("local").getData().vmrsSelection = oData.results;
								sap.ui.core.BusyIndicator.hide();
							},
							error: function(error) {

							}
						};
						omodel.read("/CV_VMRS_SELECTION_ALL_OTHERS_NKONGOVParameters(ParRATE_PLAN_ID=" + rateplanId + ")/Execute", mParameters);
						
						
						//view code
							<Text text="{local>CC_VMRS_33_CD}"/>
									<Text text="{local>CC_VMRS_33_DESC}"/> 
									
									items="{ path:'local>/vmrsSelection',	sorter: { path: 'CC_RANK_VMRS', descending: false}}" */

						/*end of new VMRS selection*/

					},
					error: function(err) {
						alert("error");
					}
				});

			}

		},
		/* Send all the values in pareto table as non-selected */
		onSelectAllVMRS: function(oEvent) {

			if (this.getView().byId('port').getValue() == "Engine" || this.getView().byId('port').getValue() == "ENGINE") {
				this.getView().getModel("local").getData().rateplanvisibility.costCurveBtn = 2;
			}
			
			else {
			    this.getView().getModel("local").getData().rateplanvisibility.costCurveBtn = 1;
			}
			this.getView().byId('CreateRatePlanWizard').nextStep();
			this.getView().getModel("local").getData().rateplanvisibility.selectedStep = 3;
			this._showFormFragment("CostDriversForSelection", "costdriverlayout");

			/*sending the selected vmrs,inserted time,created user, rateplan id */
			var ratePlanId = this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID;
			var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
			var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
			var insertRows = [];
			var that = this;
			var modelData = this.getView().getModel("local").getData().pareto;

			for (var i = 0; i < modelData.length; i++) {

				if (!modelData[i].VMRS_33_ASSEMB_DESC) {
					modelData[i].VMRS_33_ASSEMB_DESC = " ";
				}

				insertRows.push({
					VMRS_33_CD: modelData[i].VMRS_33_CD,
					RATE_PLAN_ID: this.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID,
					CREATED_DT: createdDate,
					CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
					SELECTION_FLAG: 0,
					VMRS_33_DESC: modelData[i].VMRS_33_ASSEMB_DESC
				});

			}
			jQuery.ajax({
				url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/VMRSInsert.xsjs",
				type: "POST",
				async: false,
				method: 'POST',
				dataType: 'text',
				data: {
					dataObject: JSON.stringify(insertRows)

				},
				success: function(data) {
					//alert("success");
					//load vmrsselection voew 
					var omodel = that.getOwnerComponent().getModel();
					var rateplanId = that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID;
					var mParameters = {

						success: function(oData) {
							that.getView().byId('CreateRatePlanWizard').goToStep(that.getView().getId() + "--" + "costdriverplan");
							that.getView().byId('CreateRatePlanWizard')._getProgressNavigator()._moveToStep(3);
							that.getView().getModel("local").getData().vmrsSelection = oData.results;
							that.getView().getModel("local").refresh(true);
							sap.ui.core.BusyIndicator.hide();
						},
						error: function(error) {

						}
					};
					omodel.read("/CV_VMRS_SELECTION_ALL_OTHERSParameters(ParRATE_PLAN_ID=" + rateplanId + ")/Execute", mParameters);
					//end of vmrsselection view

				},
				error: function(err) {
					alert("error");
				}
			});
			//end of ajax call to insert records

		},
		/*value help for inflation rate*/
		onHelp: function(oEvent) {

			if (!this._oPopover) {
				this._oPopover = this._getFormFragment("popover");
				this.getView().addDependent(this._oPopover);
			}

			this._oPopover.openBy(oEvent.getSource());

		},
		onChassisCostCurvePress: function() {
			var that = this;

			if (this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen === 2 || this.getView().getModel("local").getData()
				.rateplanvisibility.createRatePlanScreen === 3) {

				var mParameters = {

					success: function(oData) {

						if (oData.results[0]) {
						     that.getView().getModel("local").getData().CostCurveViewRatePlan = oData.results[0];
						    for (var i=0; i<=oData.results.length; i++){
						        
						        if (oData.results[i].CVRG_MONTHS == 24){
							    that.getView().getModel("local").getData().CostCurveViewRatePlan24 = oData.results[i];}
							    
							    if (oData.results[i].CVRG_MONTHS == 36){
							    that.getView().getModel("local").getData().CostCurveViewRatePlan36 = oData.results[i];}
							    
							    if (oData.results[i].CVRG_MONTHS == 48){
							    that.getView().getModel("local").getData().CostCurveViewRatePlan48 = oData.results[i];}
							    
							    if (oData.results[i].CVRG_MONTHS == 60){
							    that.getView().getModel("local").getData().CostCurveViewRatePlan60 = oData.results[i];}
							    
							    
						        
						        
						    }
						}
					},
					error: function(oError) {

					}

				};

				this.getOwnerComponent().getModel().read("/CV_RATE_PLANParameters(ParRATE_PLAN_ID=" + this.getView().getModel("local").getProperty(
					"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute", mParameters);

			}
			sap.ui.core.BusyIndicator.show();
			this.router.navTo("CostCurveChassis");

		},
		onCostClaimPress: function(oEvent) {
			console.log(oEvent);
			var vmrsCode = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
			var vmrsDescription = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
			var oData = this.getView().getModel("local").getData().vmrsSelection;
			var oCommonModel = this.getOwnerComponent().getModel("oCommonModel");
			oCommonModel.setProperty("/VMRS_33_CD", oData[vmrsCode].VMRS_33_CD);
			oCommonModel.setProperty("/VMRS_33_ASSEMB_DESC", oData[vmrsCode].VMRS_33_DESC);
			this.router.navTo("CostPerClaim");
		},

		onExposurePlotEngine: function(oEvent) {
		    var vmrsCode = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
			var vmrsDescription = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
			var oData = this.getView().getModel("local").getData().vmrsSelection;
			var oCommonModel = this.getOwnerComponent().getModel("oCommonModel");
			oCommonModel.setProperty("/VMRS_33_CD", oData[vmrsCode].VMRS_33_CD);
				oCommonModel.setProperty("/VMRS_33_ASSEMB_DESC", oData[vmrsCode].VMRS_33_DESC);
		   // Check if the Portfolio is Engine /Chassis
		    //If Chassis : 
		    var  portFolioName =this.getOwnerComponent().getModel("local").oData.ViewRatePlan.PORTFOLIO_NAME;
		
		if(portFolioName == "ENGINE"){
		    this.router.navTo("ExpPlotEngine");
		}	
		else{
		    this.router.navTo("ExpPlotChassis");
		}
			// If Engine 
			//this.router.navTo("ExpPlotEngine");

		},

		onEngineCostCurvePress: function() {
			var that = this;
			if (this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen === 2 || this.getView().getModel("local").getData()
				.rateplanvisibility.createRatePlanScreen === 3) {
			
				var mParameters = {

					success: function(oData) {
					if (oData.results[0])  {
						     that.getView().getModel("local").getData().CostCurveViewRatePlan = oData.results[0];
						    for (var i=0; i<=oData.results.length; i++){
						        
						        
							    
							    if (oData.results[i].CVRG_MONTHS == 36){
							    that.getView().getModel("local").getData().CostCurveViewRatePlan36 = oData.results[i];}
							    
							    if (oData.results[i].CVRG_MONTHS == 48){
							    that.getView().getModel("local").getData().CostCurveViewRatePlan48 = oData.results[i];}
							    
							    if (oData.results[i].CVRG_MONTHS == 60){
							    that.getView().getModel("local").getData().CostCurveViewRatePlan60 = oData.results[i];}
							    
							    if (oData.results[i].CVRG_MONTHS == 72){
							    that.getView().getModel("local").getData().CostCurveViewRatePlan72 = oData.results[i];}
							    
							    
						        
						        
						    }
						}
					},
					error: function(oError) {

					}

				};

				this.getOwnerComponent().getModel().read("/CV_RATE_PLANParameters(ParRATE_PLAN_ID=" + this.getView().getModel("local").getProperty(
					"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute", mParameters);

			}
		
			this.router.navTo("CostCurveEngine");
		},
		/*value help for Rateplan Info*/
		onRatePlanPopover: function(oEvent) {
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("DtnaAspRP_ss.Fragment.ratePlanInfoPopover", this);
				this.getView().addDependent(this._oPopover);
			}

			this._oPopover.openBy(oEvent.getSource());
		},
		/*Getting the values for Product according to the selected Portfolio*/
		onPortfolioSelect: function(oEvent) {
			var selectedKey = oEvent.getSource().getSelectedItem().getText().toUpperCase();
			var productCombobox = this.getView().byId("product");
			var productBinding;
			var filter = new Filter("PRD_TYP_CD", sap.ui.model.FilterOperator.Contains, selectedKey);
			var oItemTemplate = new sap.ui.core.ListItem({
				text: "{BASE_MDL_CD}",
				key: "{BASE_MDL_CD}"
			});

			productCombobox.bindAggregation("items", "/PRODUCT_TYPE", oItemTemplate);
			productBinding = this.getView().byId("product").getBinding("items");
			productBinding.filter(filter, "Application");

			//resetting the value of product type
			this.getView().getModel("local").setProperty("/NewRatePlan/PRODUCT_TYPE", "");
			this.getView().byId("Emission").setText("");
			if (this.getView().byId('port').getValue() == "Engine" || this.getView().byId('port').getValue() == "ENGINE") {
				this.getView().getModel("local").getData().rateplanvisibility.costCurveBtn = 2;
			}

		},
		//getting the value for Emission once the Product_Type is set.
		onProductSelect: function(oEvent) {
			var sPath = oEvent.getSource().getSelectedItem().getBindingContext().getPath();
			var emission;
			if (sPath) {
				emission = oEvent.getSource().getModel().getProperty(sPath).EMISSION;
			}
			if (emission) {
				this.getView().byId("Emission").setText(emission);
			}
		},
		/*initialising the value of Inservice year table on change of date*/
		onCutoffDateChange: function() {
			this.getView().byId("ratetable").removeSelections();
			this.getView().getModel("local").getData().Baseline = [];
			this.getView().getModel("local").refresh(true);
		},
		/*navigate to Failure rate screen*/
		onFailureRatePress: function(oEvent) {
			//this.router.navTo("FailureRate");
			var vmrs = this.getView().getModel("local").getProperty(oEvent.getSource().getBindingContext("local").getPath()).VMRS_33_CD;
			var vmrsDesc = this.getView().getModel("local").getProperty(oEvent.getSource().getBindingContext("local").getPath()).VMRS_33_DESC;
			sap.ui.core.BusyIndicator.show();
			this.router.navTo("FailureRate", {
				vmrsCode: vmrs,
				vmrsDesc: vmrsDesc
			});
		},

		_DisableParetoCheckBox(enabled) {

			var tbl = this.getView().byId('vmrscodetab');
			tbl.addDelegate({
				onAfterRendering: function() {
					var header = this.$().find('thead');
					var selectAllCb = header.find('.sapMCb');
					selectAllCb.remove();

					this.getItems().forEach(function(r) {

						var cb = r.$().find('.sapMCb');
						var oCb = sap.ui.getCore().byId(cb.attr('id'));
						oCb.setEnabled(enabled);
					});
				}
			}, tbl);

		}

	});

});
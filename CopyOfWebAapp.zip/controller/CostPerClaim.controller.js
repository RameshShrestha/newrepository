sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function(Controller,History) {
	"use strict";

	return Controller.extend("DtnaAspRP_ss.controller.CostPerClaim", {
		onInit: function() {
		    this.router = this.getOwnerComponent().getRouter();
	
            this.router.getRoute("CostPerClaim").attachPatternMatched(this._onRouteObjectMatched,this);
            
			var oFirstTable = this.getOwnerComponent().getModel("FirstTable");
			var oSecondTable = this.getOwnerComponent().getModel("SecondTable");

		},
		
		onNavBack: function () {
		    
		    this.nav.to("CreateRatePlan", context);
		},
		
		onCPCGoBack: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("overview", true);
			}
		},
	
		
		_onFirstTablePost : function(){
		    var url = "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostPerClaim.xsjs";
		    var oEntry = [];
		    var date = new Date();
		    var oMonth = date.getMonth() + 1;
		    var oDate = date.getDate();
		    var oYear = date.getFullYear();
		    var dateString = oYear + '-' + oMonth + '-' + oDate;
 		    var oFirstTable = this.getOwnerComponent().getModel("FirstTable");
 		   
		    var oFirstData =  oFirstTable.getProperty("/FirstData");
		    var bStopSave = false;
		    for(var i=0;i<oFirstData.length;i++){
		        if(oFirstData[i].ROW_EDITED && (oFirstData[i].CPC_COMMENT == null || oFirstData[i].CPC_COMMENT.trim() === "")){
		            oFirstData[i].ROW_EDITED_FINAL = true;
		            bStopSave = true;
		        }
		    }
		    
		    if(bStopSave){
		        oFirstTable.setProperty("/FirstData",oFirstData);
		        return;
		    }else{
		         for(var i=0;i<oFirstData.length;i++){
		       
		            oFirstData[i].ROW_EDITED_FINAL = false;
		        }
		        oFirstTable.setProperty("/FirstData",oFirstData);
		    }
		    
		    var oViewRatePlan=this.getOwnerComponent().getModel("local").getData().ViewRatePlan;
			for(var i=0 ; i<oFirstData.length;i++){
			    var aData = {
                    "RATE_PLAN_ID":     oViewRatePlan.RATE_PLAN_ID, 
                    "RATE_PLAN_TERM":   oFirstData[i].RATE_PLAN_TERM_P, 
                    "YEAR":             oFirstData[i].IN_SRVC_YR,
                    //"PRD_TYPE":         oFirstData[i].PRODUCT_TYPE,
                    "PRD_TYPE":         oViewRatePlan.PORTFOLIO_NAME,
                    "VMRS_33_CD":       oFirstData[i].VMRS_33_CD,
                    "EW_CPC_REAL":      oFirstData[i].CC_EW_CPC_REAL, 
                    "EW_CPC_STRATEGIC": oFirstData[i].CC_EW_CPC_STRATEGIC, 
                    "CPC_COMMENT":      oFirstData[i].CPC_COMMENT, 
                    "DATE_OPERATION":   dateString, 
                    "USER":             oViewRatePlan.CREATED_USER,
                    "MODIFIED_USER":    oViewRatePlan.MODIFIED_USER,
                    "FLAG":             oFirstData[i].RATE_PLAN_TERM_FLAG
                };
                oEntry.push(aData);
			}

			jQuery.ajax({
				url:url,
				type: 'POST',
                 contentType: 'application/json',
                 data:JSON.stringify(oEntry),
                 dataType: 'JSON',
				success: function(result) {
				//	sap.m.MessageToast.show("'Adjustments to Cost Per Claim(s) Saved successfully'");
				sap.m.MessageBox.show("Adjustments to Cost Per Claim Saved successfully", {
									icon: sap.m.MessageBox.Icon.SUCCESS,
									title: "Success",
									actions: [sap.m.MessageBox.Action.CLOSE],
									onClose: function() {},
									contentWidth: "100px"

								});
				},
				error: function(e) {
					console.log("error: " + e);
					sap.m.MessageToast.show("Error while saving the CPC Records to Database");
					
				},
				
			});
		},
		
        _onRouteObjectMatched : function(){
            var that = this;
            
            //Clear Dataa in tables and Graohs
        	
        	var oFirstTable = that.getOwnerComponent().getModel("FirstTable");
        	oFirstTable.setProperty("/FirstData",[]);
    		var oTotalCostGraphModel = that.getOwnerComponent().getModel("oTotalCostGraphModel");
			oTotalCostGraphModel.setProperty("/CV_CPC_LINE", []);
			var oSecondTable = that.getOwnerComponent().getModel("SecondTable");
			oSecondTable.setProperty("/SecondData",[]);
			var oCostPerClaimModel = that.getOwnerComponent().getModel("CostPerClaimModel");
			oCostPerClaimModel.setProperty("/GraphData",[]);
            
            // Clearing all the Data in the tables and Graphs before loading.
            
            var idFirstTable = that.getView().byId("idFirstTable");
            
			var oHANADBSERVICE = this.getOwnerComponent().getModel("HANADBSERVICE");
			var oViewRatePlan=this.getOwnerComponent().getModel("local").getData().ViewRatePlan;
			var oColumnChart = that.getView().byId("sIdColumnChart");
			oColumnChart.setBusy(true);
		    
			idFirstTable.setBusy(true);
			var cutoff_dt = oViewRatePlan.RATE_PLAN_CUTOFF_DT;
			//var aCutOff = cutoff_dt.split("-");
            //cutoff_dt = aCutOff[2] + "-" + aCutOff[0] + "-" + aCutOff[1];
            var oCommonModel = this.getOwnerComponent().getModel("oCommonModel");
            var VMRS_33_CD = oCommonModel.getProperty("/VMRS_33_CD");
            var VMRS_33_ASSEMB_DESC = oCommonModel.getProperty("/VMRS_33_ASSEMB_DESC");
            var oInputParam = {
                planID :oViewRatePlan.RATE_PLAN_ID,
                portfolioName : oViewRatePlan.PORTFOLIO_NAME,
                baseyear : oViewRatePlan.BASELINE_YEAR,
                cutoff_dt : cutoff_dt,
                prodType : oViewRatePlan.PRODUCT_TYPE,
                VMRS_33_CD : VMRS_33_CD == 'ALL OTHERS' ? 'ALL%20OTHERS' : VMRS_33_CD,
                VMRS_33_ASSEMB_DESC:VMRS_33_ASSEMB_DESC
			}
            
            oCommonModel.setProperty("/Input",oInputParam);
            
            
			var mParams = {
				success: function(oData) {
				    if(oData.results.length > 0){
					that.fnFormCostPerClaimGraphData(oData.results, that);
					
						var oFirstData = oData.results;
					
					// Sorting the data by Rate Plan Term Flag ( 1 or 0 - Present vs Previous)
					
						 oFirstData = oFirstData.sort(function(a, b) {
                				return parseInt(a.RATE_PLAN_TERM_FLAG) - parseInt(b.RATE_PLAN_TERM_FLAG);
                			});
                			oFirstData.map(function(oEntry){
                			    oEntry.ROW_EDITED = false;
                			    oEntry.ROW_EDITED_FINAL = false;
                			    return oEntry;
                			});
                // 11-7-2018 : New requirement to push the future year into the Table for CPC. The values should be defaulted to 0.
                
                        var nFutObj = {"BW_CPC": "0",
                            "CC_EW_CPC_REAL": "0",
                            "CC_EW_CPC_STRATEGIC": "0",
                            "CLAIM_COUNT":0,
                            "CPC_COMMENT": "",
                            "EMISSION": "",
                            "EW_CPC": "553",
                            "ID": "219475131452854113",
                            "IN_SRVC_YR": "2019",
                            "PRD_TYP_CD": "CHASSIS",
                            "PRODUCT_TYPE": "HD",
                            "RATE_PLAN_ID": 5978,
                            "RATE_PLAN_TERM_FLAG": 1,
                            "RATE_PLAN_TERM_P": "CH-HD-11-2018",
                            "VMRS_33_CD": "032-002-001",
                             "VMRS_33_DESC": "MOTOR ASSEMBLY - STARTER"
                        }
                        var oLastRecord = oFirstData[oFirstData.length - 1];
                        var newObject = jQuery.extend(true, {}, oLastRecord);
                        newObject.CLAIM_COUNT = "0";
                        newObject.BW_CPC = "0";
                        newObject.EW_CPC = "0";
                        newObject.CC_EW_CPC_REAL = "0";
                        newObject.CC_EW_CPC_STRATEGIC = "0";
                        var year = parseInt(newObject.IN_SRVC_YR) + 1;
                        newObject.IN_SRVC_YR = year + '';
                        newObject.ID = newObject.ID + 1;
                         if (year<="2019"){
                        oFirstData.push(newObject); 
                        };
						oFirstTable.setProperty("/FirstData",oFirstData);
				    }
				    var idFirstTable = that.getView().byId("idFirstTable");
			idFirstTable.setBusy(false);
				    
				},
				error: function(err) {
				    
					console.log(err);
					var oColumnChart = that.getView().byId("sIdColumnChart");
			        oColumnChart.setBusy(false);
			        var idFirstTable = that.getView().byId("idFirstTable");
			       idFirstTable.setBusy(false);
				}
			};
		//	var oCommonModel = this.getOwnerComponent().getModel("oCommonModel");
			oCommonModel.setProperty("/CostPerClaimSave", true);
		
	 oHANADBSERVICE.read("/CV_CPC_BAR_REALParameters(parSRVC_RPR_DT=datetime'" + oInputParam.cutoff_dt  +"',parIN_SRVC_YEAR=" + oInputParam.baseyear  + ",parVMRS_33_CD='" + oInputParam.VMRS_33_CD + "',parPRD_TYP_CD='" +  oInputParam.portfolioName  + "',parPRODUCT_TYPE='"+  oInputParam.prodType  +"',ParRATE_PLAN_ID=" + oInputParam.planID  + ")/Execute",
				mParams);
					
				var idVizFrame = that.getView().byId("idVizFrame");
			idVizFrame.setBusy(true);
				var idSecondTable = that.getView().byId("idSecondTable");
			idSecondTable.setBusy(true);
			that._fnSecondGraph();
			that.fnSecondTable();
        },
		onAfterRendering: function() {
			

			var vizProperties = {
				timeAxis: {
					levels: ["year", "quarter"],
					title: {
						visible: true,
						text :'ISY/Repair Years'
					}
				},
				plotArea: {
					window: {
						start: "firstDataPoint",
						end: "lastDataPoint"
					}
				},
				valueAxis: {
					title: {
						visible: true,
						text :'Cost Per Claim'
					}
				},
				title: {
					visible: false
				},
				legend: {
					visible: true
				}
			};
			
				var vizProperties2 = {
				categoryAxis: {
					   title: {
						visible: true,
						text :'ISY'
					}
				},
			
				valueAxis: {
					title: {
						visible: true,
						text :'EW CPC'
						
					}
				},
				title: {
					visible: false
				},
				legend: {
					visible: true
				},
				
				
				interaction : {
                          selectability : {
                          mode : "single"
                          }
                          },
				
			};
			
			this.getView().byId("sIdColumnChart").setVizProperties(vizProperties2);
            var oVizFrame = this.getView().byId("idVizFrame");
            oVizFrame.setVizProperties(vizProperties);
            
            //var oPopOver = this.getView().byId("idPopOver");
            //oPopOver.connect(oVizFrame.getVizUid());
     new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrame").getVizUid());
		
		},

		_fnSecondGraph: function() {
			var dRetireDate = new Date();
			var that = this;
			var oHANADBSERVICE = this.getOwnerComponent().getModel("HANADBSERVICE");
			var mParams = {
				success: function(oData) {
					var aData = oData.results;
					for (var i = 0; i < aData.length; i++) {
						aData[i].REPAIR_YEAR_MONTH = aData[i].REPAIR_YEAR_MONTH.replace("-", "/1/");
					}
					var oTotalCostGraphModel = that.getOwnerComponent().getModel("oTotalCostGraphModel");
					oTotalCostGraphModel.setProperty("/CV_CPC_LINE", aData);
					var idVizFrame = that.getView().byId("idVizFrame");
		        	idVizFrame.setBusy(false);
					
					},
				error: function(err) {
					console.log(err);
					var idVizFrame = that.getView().byId("idVizFrame");
			idVizFrame.setBusy(false);
				}
			};

		
	 var oCommonModel = that.getOwnerComponent().getModel("oCommonModel");
            var oInputParam =  oCommonModel.getProperty("/Input");
	
		oHANADBSERVICE.read(
		"/CV_CPC_LINEParameters(ParRATE_PLAN_ID=" + oInputParam.planID  + ",parSRVC_RPR_DT=datetime'" + oInputParam.cutoff_dt  +"',parIN_SRVC_YEAR='" + oInputParam.baseyear  + "',parVMRS_33_CD='" + oInputParam.VMRS_33_CD + "',parPRD_TYP_CD='" +  oInputParam.portfolioName  + "',parPRODUCT_TYPE='"+  oInputParam.prodType  +"')/Execute",
				mParams)
				
		},

		/**
		 * Method to fetch and form data for table 2
		 */
		fnSecondTable: function() {
		    	var that = this;
		    var oCommonModel = that.getOwnerComponent().getModel("oCommonModel");
            var oInputParam =  oCommonModel.getProperty("/Input");
            
			var sUrl =
			
				"/CV_CPC_TABLEParameters(parSRVC_RPR_DT=datetime'" + oInputParam.cutoff_dt  +"',parIN_SRVC_YEAR='" + oInputParam.baseyear  + "',parVMRS_33_CD='" + oInputParam.VMRS_33_CD + "',parPRD_TYP_CD='" +  oInputParam.portfolioName  + "',parPRODUCT_TYPE='"+  oInputParam.prodType  +"',ParRATE_PLAN_ID=" + oInputParam.planID  + ")/Execute";
			
				var oHANADBSERVICE = this.getOwnerComponent().getModel("HANADBSERVICE");
     			var mParams = {
				success: function(oData) {
					/*that.fnFormCostPerClaimGraphData(oData.results,that);*/
					var oSecondTable = that.getOwnerComponent().getModel("SecondTable");
					var oData = oData.results;
					var oCounter=oData.length;
					var iCount3M = 0,
						iCount6M = 0,
						iCount12M = 0,
						iSum3M = 0,
						iSum6M = 0,
						iSum12M = 0;
					var	flagCounter=0;
					for (var i = 0; i < oCounter; i++) {
					    
						if (oData[i].LAST_3M_FLAG === 1) {
						    flagCounter++;
							iCount3M += oData[i].CLAIM_COUNT;
							iSum3M += parseInt((oData[i].COST_PER_CLAIM_TOTAL)/flagCounter);
							
						}
						if (oData[i].LAST_6M_FLAG === 1) {
						    flagCounter++;
							iCount6M += oData[i].CLAIM_COUNT;
							iSum6M += parseInt((oData[i].COST_PER_CLAIM_TOTAL)/flagCounter);
						}
						if (oData[i].LAST_12M_FLAG === 1) {
						    flagCounter++;
							iCount12M += oData[i].CLAIM_COUNT;
							iSum12M += parseInt((oData[i].COST_PER_CLAIM_TOTAL)/flagCounter);
							
						}
					}
					var aSecondData = [{
						EPA10: "Last 3M",
						CPC: iSum3M,
						Price: iCount3M
			}, {
						EPA10: "Last 6M",
						CPC: iSum6M,
						Price: iCount6M
			}, {
						EPA10: "Last 12M",
						CPC: iSum12M,
						Price: iCount12M
			}];

					oSecondTable.setProperty("/SecondData", aSecondData);
						var idSecondTable = that.getView().byId("idSecondTable");
			idSecondTable.setBusy(false);


				},
				error: function(err) {
					console.log(err);
						var idSecondTable = that.getView().byId("idSecondTable");
			idSecondTable.setBusy(false);

				}
			};
		
			oHANADBSERVICE.read(sUrl, mParams);
		},
		onRatePlanPopover: function(oEvent) {
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("DtnaAspRP_ss.Fragment.CPCratePlanInfoPopover", this);
				this.getView().addDependent(this._oPopover);
			}
			this._oPopover.openBy(oEvent.getSource());
		},
		onExit: function() {
			var oCommonModel = this.getOwnerComponent().getModel("oCommonModel");
			oCommonModel.setProperty("/CostPerClaimSave", false);
		},
		fnFormCostPerClaimGraphData: function(aData, that) {
			var oCostPerClaimModel = that.getOwnerComponent().getModel("CostPerClaimModel");
			aData = aData.sort(function(a, b) {
				return parseInt(a.IN_SRVC_YR) - parseInt(b.IN_SRVC_YR);
			});
			var aFinalData = [{
				IN_SRVC_YR: parseInt(aData[0].IN_SRVC_YR) - 1,
				BW_CPC: 0,
				EW_CPC: 0
			}];
			var iBW_CPC = 0;
			var iEW_CPC = 0;
			var iPreviousYear = aData[0].IN_SRVC_YR;
			for (var i = 0; i < aData.length; i++) {
			    if (aData[i].RATE_PLAN_TERM_FLAG === 1){
			 	if (iPreviousYear !== aData[i].IN_SRVC_YR) {
					aFinalData.push({
						IN_SRVC_YR: parseInt(iPreviousYear),
						BW_CPC: iBW_CPC,
						EW_CPC: iEW_CPC
					});
					iBW_CPC = 0;
					iEW_CPC = 0;
				}
				
				// H
				iBW_CPC += parseFloat(aData[i].BW_CPC);
				iEW_CPC += parseFloat(aData[i].EW_CPC);
				iPreviousYear = aData[i].IN_SRVC_YR;
			    }
			}
			aFinalData.push({
				IN_SRVC_YR: parseInt(iPreviousYear),
				BW_CPC: iBW_CPC,
				EW_CPC: iEW_CPC
			});
			oCostPerClaimModel.setProperty("/GraphData", aFinalData);
			var oColumnChart = that.getView().byId("sIdColumnChart");
			oColumnChart.setBusy(false);
		},
		
	    fnValueChanged :function(oEvent){
	        //debugger;
	        var iSelectedIndex = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
			//var vmrsDescription = oEvent.getSource().getParent().getParent().indexOfItem(oEvent.getSource().getParent());
		//	var oData = this.getView().getModel("local").getData().vmrsSelection;
			var FirstTable = this.getOwnerComponent().getModel("FirstTable");
			FirstTable.setProperty("/FirstData/" + iSelectedIndex + "/ROW_EDITED",true);

	        console.log(oEvent);
	    }
		
	});
});
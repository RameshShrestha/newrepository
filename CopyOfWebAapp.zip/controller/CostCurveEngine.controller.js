sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/m/MessageBox",
	"sap/viz/ui5/controls/Popover",
	"sap/m/MessageToast",
	"DtnaAspRP_ss/model/formatter",
		"sap/m/Dialog",
	"sap/m/Text",
	"sap/m/Button"

], function(Controller, ChartFormatter, MessageBox, Popover, MessageToast, formatter, Dialog, Text, Button ) {
	"use strict";

	return Controller.extend("DtnaAspRP_ss.controller.CostCurveEngine", {
		formatter: formatter,
		onInit: function() {
			this.router = this.getOwnerComponent().getRouter();
			var json = new sap.ui.model.json.JSONModel(jQuery.sap.getModulePath("DtnaAspRP_ss.model", "/testmodel.json"));
			this.getView().setModel(json);
			this._Fragments = [];

			this.router.getRoute("CostCurveEngine").attachPatternMatched(this._onRouteObjectMatched, this);

		},
		_onRouteObjectMatched: function() {
			sap.ui.core.BusyIndicator.hide();
		},
		onAfterRendering: function() {

			/*this.getView().byId("idVizFrame").addEventDelegate({
				onclick: function(oEvent) {
					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					view.getController()._showFormFragment(view, "EngineChart36months");
				}
			});

			this.getView().byId("idVizFrame2").addEventDelegate({
				onclick: function(oEvent) {
					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					view.getController()._showFormFragment(view, "EngineChart48months");

				}
			});

			this.getView().byId("idVizFrame3").addEventDelegate({
				onclick: function(oEvent) {
					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					view.getController()._showFormFragment(view, "EngineChart60months");
				}
			});
			this.getView().byId("idVizFrame4").addEventDelegate({
				onclick: function(oEvent) {
					var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
					view.getController()._showFormFragment(view, "EngineChart72months");

				}
			});*/
		},

		_showFormFragment: function(view, sFragmentname, vizId) {

			var controller = view.getController();
			var dialog = controller._Fragments[sFragmentname]
			if (!dialog) {

				dialog = sap.ui.xmlfragment(view.getId(), "DtnaAspRP_ss.Fragment." + sFragmentname, this);
				controller._Fragments[sFragmentname] = dialog;
				view.addDependent(dialog);

				//add tooltip
				if (vizId) {
					new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId(vizId).getVizUid());
				}

			}
			if (sFragmentname == "CostCurveEngineStatus") {
				view.byId("multiheader").setHeaderSpan([4, 1]);
			}

			dialog.open();

		},
		_hideFormFragment: function(controller, sFragmentname) {

			//var controller = view.getController();
			var dialog = controller._Fragments[sFragmentname]
			if (dialog) {

				dialog.close();
			}

		},
		onRatePlanPopover: function(oEvent) {

			var dialog = this._Fragments["ratePlanInfoPopover"]
			if (!dialog) {

				dialog = sap.ui.xmlfragment(this.getView().getId(), "DtnaAspRP_ss.Fragment." + "ratePlanInfoPopover", this);
				this._Fragments["ratePlanInfoPopover"] = dialog;
				this.getView().addDependent(dialog);
			}
			dialog.openBy(oEvent.getSource());

		},

		GenerateCostCurveEng: function() {
			var that = this;
			if (this.getView().byId("vocation").getValue().length == 0 || this.getView().byId("domicile").getValue().length == 0 || this.getView()
				.byId("coverage").getValue() == 0 ||
				this.getView().byId("Deductible").length == 0 || this.getView().byId("Torque").getValue().length == 0) {

				sap.m.MessageBox.error("Please Enter/Select all the required fields");
			} else {
				//popover
				for (var i = 1; i <= 4; i++) {
					/*  var oPopOver = this.getView().byId("idPopOver");
                 oPopOver.connect(this.getView().byId("idVizFrame"+i).getVizUid());*/
					new sap.viz.ui5.controls.VizTooltip({}).connect(this.getView().byId("idVizFrame" + i).getVizUid());

					// oPopOver.setFormatString(formatPattern.STANDARDFLOAT);
				}
				//end of popover
				//	sap.ui.core.BusyIndicator.show();

				this.getView().byId("idVizFrame1").addEventDelegate({
					onclick: function(oEvent) {
						var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
						that._showFormFragment(that.getView(), "EngineChart36months", "vizChart36");
						that._GetMilegeData(36);
						that.getView().getModel("local").getData().AUFValue = [];
						that.getView().byId("auffactor36").setBusy(true);

						/*get the AUF value*/

						var mParameters = {
							success: function(oData) {
								//	alert("success");

								var data = [];
								for (var i = 0; i < oData.results.length; i++) {

									data[oData.results[i].GROUP_ID] = oData.results[i];
								}
								that.getView().getModel("local").getData().AUFValue = data;
								that.getView().byId("auffactor36").setBusy(false);

							},
							error: function(oError) {
								that.getView().byId("auffactor36").setBusy(false);
								alert("error");

							}

						};
						//parameterized
						view.getController().getOwnerComponent().getModel().read("/CV_TF_COST_CURVE_AUFParameters(parIN_SRVC_YR=" + view.getModel("local")
							.getProperty("/ViewRatePlan/BASELINE_YEAR") + ",parVOC_CATEGORY='" + view.byId("vocation").getValue().toUpperCase() +
							"',parPRODUCT_TYPE='" + view.getModel("local").getProperty("/ViewRatePlan/PRODUCT_TYPE") + "',parPRD_TYP_CD='" + view.getModel(
								"local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "',parDATE=datetime'" + view.getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "',parCVRG_MONTHS=36,parDOMCL_CNTRY_CD='" + that._CountryCode() +
							"',parRATE_PLAN_ID=" + view.getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID") + ",parDEDUCT_AMT=" + parseInt(that._DeductAmnt()) +
							",parCVRG_GROUP='" + view.byId("coverage").getValue() + "',parTORQUE='" + view.byId("Torque").getValue()
							.toUpperCase() + "')/Execute", mParameters);

					}
				});

				this.getView().byId("idVizFrame2").addEventDelegate({
					onclick: function(oEvent) {
						var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
						that._showFormFragment(that.getView(), "EngineChart48months", "vizChart48");
						that._GetMilegeData(48);
						that.getView().getModel("local").getData().AUFValue = [];
						that.getView().byId("auffactor48").setBusy(true);

						var mParameters = {
							success: function(oData) {
								//	alert("success");

								var data = [];
								for (var i = 0; i < oData.results.length; i++) {

									data[oData.results[i].GROUP_ID] = oData.results[i];
								}
								that.getView().getModel("local").getData().AUFValue = data;
								that.getView().byId("auffactor48").setBusy(false);

							},
							error: function(oError) {
								that.getView().byId("auffactor48").setBusy(false);
								alert("error");

							}

						};
						//parameterized
						view.getController().getOwnerComponent().getModel().read("/CV_TF_COST_CURVE_AUFParameters(parIN_SRVC_YR=" + view.getModel("local")
							.getProperty("/ViewRatePlan/BASELINE_YEAR") + ",parVOC_CATEGORY='" + view.byId("vocation").getValue().toUpperCase() +
							"',parPRODUCT_TYPE='" + view.getModel("local").getProperty("/ViewRatePlan/PRODUCT_TYPE") + "',parPRD_TYP_CD='" + view.getModel(
								"local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "',parDATE=datetime'" + view.getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "',parCVRG_MONTHS=48,parDOMCL_CNTRY_CD='" + that._CountryCode() +
							"',parRATE_PLAN_ID=" + view.getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID") + ",parDEDUCT_AMT=" + parseInt(that._DeductAmnt()) +
							",parCVRG_GROUP='" + view.byId("coverage").getValue() + "',parTORQUE='" + view.byId("Torque").getValue()
							.toUpperCase() + "')/Execute", mParameters);

					}
				});

				this.getView().byId("idVizFrame3").addEventDelegate({
					onclick: function(oEvent) {
						var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
						that._showFormFragment(that.getView(), "EngineChart60months", "vizChart60");
						that._GetMilegeData(60);
						that.getView().getModel("local").getData().AUFValue = [];
						that.getView().byId("auffactor60").setBusy(true);

						//view.getController()._showFormFragment(view, "EngineChart60months", "vizChart60");
						var mParameters = {
							success: function(oData) {
								//	alert("success");

								var data = [];
								for (var i = 0; i < oData.results.length; i++) {

									data[oData.results[i].GROUP_ID] = oData.results[i];
								}
								that.getView().getModel("local").getData().AUFValue = data;

								that.getView().byId("auffactor60").setBusy(false);

							},
							error: function(oError) {
								that.getView().byId("auffactor60").setBusy(false);
								alert("error");

							}

						};
						//parameterized
						view.getController().getOwnerComponent().getModel().read("/CV_TF_COST_CURVE_AUFParameters(parIN_SRVC_YR=" + view.getModel("local")
							.getProperty("/ViewRatePlan/BASELINE_YEAR") + ",parVOC_CATEGORY='" + view.byId("vocation").getValue().toUpperCase() +
							"',parPRODUCT_TYPE='" + view.getModel("local").getProperty("/ViewRatePlan/PRODUCT_TYPE") + "',parPRD_TYP_CD='" + view.getModel(
								"local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "',parDATE=datetime'" + view.getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "',parCVRG_MONTHS=60,parDOMCL_CNTRY_CD='" + that._CountryCode() +
							"',parRATE_PLAN_ID=" + view.getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID") + ",parDEDUCT_AMT=" + parseInt(that._DeductAmnt()) +
							",parCVRG_GROUP='" + view.byId("coverage").getValue() + "',parTORQUE='" + view.byId("Torque").getValue()
							.toUpperCase() + "')/Execute", mParameters);
					}
				});
				this.getView().byId("idVizFrame4").addEventDelegate({
					onclick: function(oEvent) {
						var view = oEvent.srcControl.getParent().getParent().getParent().getParent();
						that._showFormFragment(that.getView(), "EngineChart72months", "vizChart72");
						that._GetMilegeData(72);
						that.getView().getModel("local").getData().AUFValue = [];
						that.getView().byId("auffactor72").setBusy(true);

						var mParameters = {
							success: function(oData) {
								var data = [];
								for (var i = 0; i < oData.results.length; i++) {

									data[oData.results[i].GROUP_ID] = oData.results[i];
								}
								that.getView().getModel("local").getData().AUFValue = data;
								that.getView().byId("auffactor72").setBusy(false);

							},
							error: function(oError) {
								that.getView().byId("auffactor72").setBusy(false);
								alert("error");

							}

						};

						//parameterized
						view.getController().getOwnerComponent().getModel().read("/CV_TF_COST_CURVE_AUFParameters(parIN_SRVC_YR=" + view.getModel("local")
							.getProperty("/ViewRatePlan/BASELINE_YEAR") + ",parVOC_CATEGORY='" + view.byId("vocation").getValue().toUpperCase() +
							"',parPRODUCT_TYPE='" + view.getModel("local").getProperty("/ViewRatePlan/PRODUCT_TYPE") + "',parPRD_TYP_CD='" + view.getModel(
								"local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "',parDATE=datetime'" + view.getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "',parCVRG_MONTHS=72,parDOMCL_CNTRY_CD='" + that._CountryCode() +
							"',parRATE_PLAN_ID=" + view.getModel("local").getProperty("/ViewRatePlan/RATE_PLAN_ID") + ",parDEDUCT_AMT=" + parseInt(that._DeductAmnt()) +
							",parCVRG_GROUP='" + view.byId("coverage").getValue() + "',parTORQUE='" + view.byId("Torque").getValue()
							.toUpperCase() + "')/Execute", mParameters);

					}
				});

				this._GetcostCurveValue("36M");
				this._GetcostCurveValue("48M");
				this._GetcostCurveValue("60M");
				this._GetcostCurveValue("72M");

			}

		},
		//on Coverage Change
		onCoverageChange: function(oEvent) {
			var coverageValue = oEvent.getSource().getValue();
			this.getView().getModel("local").getData().costCurveTitle.engineTitle = coverageValue;
		},
		//end of  coverage change
		RefreshMinMax72: function() {

			if (this.getView().byId("maxinput72").getValue() > this.getView().byId("mininput72").getValue()) {

				var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
				var that = this;
				//	var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
				var newDate = new Date();
				var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
				var currentUser = that.getView().getModel("UserInfo").getData().userName;

				var insertData = {
					RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
					VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
					CVRG_GROUP: this.getView().byId("coverage").getValue(),
					DOMCL_CNTRY_CD_GRP: this._CountryCode(),
					ENGINE_TORQUE: this.getView().byId("Torque").getValue().toUpperCase(),
					DEDUCT_AMT: parseInt(that._DeductAmnt()),
					CVRG_MONTHS: 72,
					MIN_MIS: parseInt(this.getView().byId("mininput72").getValue()),
					MAX_MIS: parseInt(this.getView().byId("maxinput72").getValue()),
					SELECTED_FCST_MTHD: "LINEAR",
					CREATED_DATE: createdDate,
					CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
					MODIFIED_DATE: currentDate,
					MODIFIED_USER: currentUser
				};

				var newData = JSON.stringify(insertData);
				jQuery.ajax({

					url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
					type: "POST",
					async: false,
					method: 'GET',
					dataType: 'text',
					data: {
						dataObject: newData
					},
					success: function(data) {

						alert("success");
						var mParameters = {

							success: function(oData) {
								sap.ui.core.BusyIndicator.hide();
								that.getView().getModel("local").getData().Overlay72 = oData.results;
								that.getView().byId("vizChart72").getDataset().bindData("local>/Overlay72");

							},
							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageBox.error(oError.responseText);

							}
						};

						sap.ui.core.BusyIndicator.show();
						that.getOwnerComponent().getModel().read(
							"/CV_COST_CURVE_FINALParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" +
							"'" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=72M" + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel("local")
							.getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE='" + that.getView().byId("Torque").getValue().toUpperCase() +
							"'," + "parDOMCL_CNTRY_CD=" + "'" + that._CountryCode() + "'," + "parDEDUCT_AMT=" +
							parseInt(that._DeductAmnt()) + "," + "parRATE_PLAN_ID=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute",
							mParameters);

					},

					error: function(oError) {
						sap.m.MessageBox.error(oError.responseText);
					}

				});
			} else {
				sap.m.MessageBox.error("MIN should be less than MAX ");
			}
		},
		RefreshMinMax36: function() {

			if (parseInt(this.getView().byId("mininput36").getValue()) < parseInt(this.getView().byId("maxinput36").getValue())) {

				var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
				var that = this;
				//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
				var newDate = new Date();
				var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
				var currentUser = that.getView().getModel("UserInfo").getData().userName;

				var insertData = {
					RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
					VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
					CVRG_GROUP: this.getView().byId("coverage").getValue(),
					DOMCL_CNTRY_CD_GRP: this._CountryCode(),
					ENGINE_TORQUE: this.getView().byId("Torque").getValue().toUpperCase(),
					DEDUCT_AMT: parseInt(that._DeductAmnt()),
					CVRG_MONTHS: 36,
					MIN_MIS: parseInt(this.getView().byId("mininput36").getValue()),
					MAX_MIS: parseInt(this.getView().byId("maxinput36").getValue()),
					SELECTED_FCST_MTHD: " ",
					CREATED_DATE: createdDate,
					CREATED_USER: his.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
					MODIFIED_DATE: currentDate,
					MODIFIED_USER: currentUser
				};

				var newData = JSON.stringify(insertData);
				jQuery.ajax({

					url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
					type: "POST",
					async: false,
					method: 'GET',
					dataType: 'text',
					data: {
						dataObject: newData
					},
					success: function(data) {

						alert("success");
						var mParameters = {

							success: function(oData) {
								sap.ui.core.BusyIndicator.hide();
								that.getView().getModel("local").getData().Overlay36 = oData.results;
								that.getView().byId("vizChart36").getDataset().bindData("local>/Overlay36");

							},
							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageBox.error(oError.responseText);

							}
						};

						sap.ui.core.BusyIndicator.show();
						that.getOwnerComponent().getModel().read(
							"/CV_COST_CURVE_FINALParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" +
							"'" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=36M" + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel("local")
							.getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE='" + that.getView().byId("Torque").getValue().toUpperCase() +
							"'," + "parDOMCL_CNTRY_CD=" + "'" + that._CountryCode() + "'," + "parDEDUCT_AMT=" +
							parseInt(that._DeductAmnt()) + "," + "parRATE_PLAN_ID=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute",
							mParameters);

					},

					error: function(oError) {
						sap.m.MessageBox.error(oError.responseText);
					}

				});

			} else {
				sap.m.MessageBox.error("MIN should be less than MAX ");
			}

		},

		RefreshMinMax48: function() {
			if (this.getView().byId("maxinput48").getValue() > this.getView().byId("mininput48").getValue()) {

				var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
				//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
				var that = this;
				var newDate = new Date();
				var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
				var currentUser = that.getView().getModel("UserInfo").getData().userName;

				var insertData = {
					RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
					VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
					CVRG_GROUP: this.getView().byId("coverage").getValue(),
					DOMCL_CNTRY_CD_GRP: this._CountryCode(),
					ENGINE_TORQUE: this.getView().byId("Torque").getValue().toUpperCase(),
					DEDUCT_AMT: parseInt(that._DeductAmnt()),
					CVRG_MONTHS: 48,
					MIN_MIS: parseInt(this.getView().byId("mininput48").getValue()),
					MAX_MIS: parseInt(this.getView().byId("maxinput48").getValue()),
					SELECTED_FCST_MTHD: " ",
					CREATED_DATE: currentDate,
					CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
					MODIFIED_DATE: currentDate,
					MODIFIED_USER: currentUser
				};
				var newData = JSON.stringify(insertData);
				jQuery.ajax({

					url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
					type: "POST",
					async: false,
					method: 'GET',
					dataType: 'text',
					data: {
						dataObject: newData
					},
					success: function(data) {

						//	alert("success");
						var mParameters = {

							success: function(oData) {
								sap.ui.core.BusyIndicator.hide();
								that.getView().getModel("local").getData().Overlay48 = oData.results;
								that.getView().byId("vizChart48").getDataset().bindData("local>/Overlay48");

							},
							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageBox.error(oError.responseText);

							}
						};

						sap.ui.core.BusyIndicator.show();
						that.getOwnerComponent().getModel().read(
							"/CV_COST_CURVE_FINALParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" +
							"'" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=48M" + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel("local")
							.getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE='" + that.getView().byId("Torque").getValue().toUpperCase() +
							"'," + "parDOMCL_CNTRY_CD=" + "'" + that._CountryCode() + "'," + "parDEDUCT_AMT=" +
							parseInt(that._DeductAmnt()) + "," + "parRATE_PLAN_ID=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute",
							mParameters);

					},

					error: function(oError) {
						sap.m.MessageBox.error(oError.responseText);
					}

				});
			} else {
				sap.m.MessageBox.error("MIN should be less than MAX ");
			}
		},

		RefreshMinMax60: function() {
			if (this.getView().byId("maxinput60").getValue() > this.getView().byId("mininput60").getValue()) {
				var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
				var that = this;
				//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
				var newDate = new Date();
				var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
				var currentUser = that.getView().getModel("UserInfo").getData().userName;

				var insertData = {
					RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
					VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
					CVRG_GROUP: this.getView().byId("coverage").getValue(),
					DOMCL_CNTRY_CD_GRP: this._CountryCode(),
					ENGINE_TORQUE: this.getView().byId("Torque").getValue().toUpperCase(),
					DEDUCT_AMT: parseInt(that._DeductAmnt()),
					CVRG_MONTHS: 60,
					MIN_MIS: parseInt(this.getView().byId("mininput60").getValue()),
					MAX_MIS: parseInt(this.getView().byId("maxinput60").getValue()),
					SELECTED_FCST_MTHD: " ",
					CREATED_DATE: currentDate,
					CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
					MODIFIED_DATE: currentDate,
					MODIFIED_USER: currentUser
				};

				var newData = JSON.stringify(insertData);
				jQuery.ajax({

					url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
					type: "POST",
					async: false,
					method: 'GET',
					dataType: 'text',
					data: {
						dataObject: newData
					},
					success: function(data) {

						//	alert("success");
						var mParameters = {

							success: function(oData) {
								sap.ui.core.BusyIndicator.hide();
								that.getView().getModel("local").getData().Overlay60 = oData.results;
								that.getView().byId("vizChart60").getDataset().bindData("local>/Overlay60");

							},
							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageBox.error(oError.responseText);

							}
						};

						sap.ui.core.BusyIndicator.show();
						that.getOwnerComponent().getModel().read(
							"/CV_COST_CURVE_FINALParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" +
							"'" +
							that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
								"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=60M" + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel("local")
							.getProperty(
								"/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
								"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE='" + that.getView().byId("Torque").getValue().toUpperCase() +
							"'," + "parDOMCL_CNTRY_CD=" + "'" + that._CountryCode() + "'," + "parDEDUCT_AMT=" +
							parseInt(that._DeductAmnt()) + "," + "parRATE_PLAN_ID=" + that.getView().getModel("local").getProperty(
								"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute",
							mParameters);

					},

					error: function(oError) {
						sap.m.MessageBox.error(oError.responseText);
					}

				});
			} else {
				sap.m.MessageBox.error("MIN should be less than MAX ");
			}
		},

		save36: function() {
			if (!this.getView().byId("ForecastMthd36").getSelectedKey()) {

				sap.m.MessageBox.error("Please select Forecast method to be applied");

			} else if ((this.getView().byId("ForecastMthd36").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd36").getSelectedKey() ==
				'QUADRATIC WITH POINTS') && (!this.getView().byId("mininput36").getValue() || !this.getView().byId("maxinput36").getValue())) {

				MessageBox.error("MIN MAX cannot be blank");

			} else {
				if ((this.getView().byId("ForecastMthd36").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd36").getSelectedKey() ==
					'QUADRATIC WITH POINTS') && (this.getView().byId("mininput36").getValue() > this.getView().byId("maxinput36").getValue())) {
					MessageBox.error("MIN should be less than MAX");
				} else {
					if (this.getView().byId("maxinput36").getValue() && parseInt(this.getView().byId("maxinput36").getValue()) > 36) {
						MessageBox.error("Max Value should be less than term Limit");
					} else {
						sap.ui.core.BusyIndicator.show();
						var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
						var that = this;
						//	var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];

						var createdDate = that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
						//	var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
						var newDate = new Date();
						var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
						var currentUser = that.getView().getModel("UserInfo").getData().userName;

						var insertData = {
							RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
							VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
							CVRG_GROUP: this.getView().byId("coverage").getValue(),
							DOMCL_CNTRY_CD_GRP: this._CountryCode(),
							ENGINE_TORQUE: this.getView().byId("Torque").getValue().toUpperCase(),
							DEDUCT_AMT: parseInt(that._DeductAmnt()),
							CVRG_MONTHS: 36,
							MIN_MIS: parseInt(this.getView().byId("mininput36").getValue()),
							MAX_MIS: parseInt(this.getView().byId("maxinput36").getValue()),
							SELECTED_FCST_MTHD: this.getView().byId("ForecastMthd36").getValue().toUpperCase(),
							CREATED_DATE: createdDate,
							CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
							MODIFIED_DATE: currentDate,
							MODIFIED_USER: currentUser
						};

						var newData = JSON.stringify(insertData);
						jQuery.ajax({

							url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
							type: "POST",
							async: false,
							method: 'GET',
							dataType: 'text',
							data: {
								dataObject: newData
							},
							success: function(data) {

								//	alert("success");
								var jsonData = JSON.parse(data);
								that.getView().getModel("local").getData().ViewRatePlan = jsonData[0];
								that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT = jsonData[0].CREATED_DT.split("/")[2] + "-" + jsonData[0].CREATED_DT
									.split("/")[0] + "-" + jsonData[0].CREATED_DT.split("/")[1];
								that.getView().getModel("local").getData().ViewRatePlan.MODIFIED_DT = jsonData[0].MODIFIED_DT.split("/")[2] + "-" + jsonData[0]
									.MODIFIED_DT.split("/")[0] + "-" + jsonData[0].MODIFIED_DT.split("/")[1];

								//sap.ui.core.BusyIndicator.hide();
								/*	MessageToast.show("Forecast Saved");
								that._hideFormFragment(that, "EngineChart36months");
								that._GetcostCurveValue("36M");*/
								//AUF
								/*	var createdDate = that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT_P;
						var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
						var newDate = new Date();
						var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
						var currentUser = that.getView().getModel("UserInfo").getData().userName;*/

								var AufInsertData = [{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 36,
										GROUP_ID: 1,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/1/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/1/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group1_36").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_36")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group1_36").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},
									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 36,
										GROUP_ID: 2,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/2/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/2/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group2_36").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_36")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group2_36").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},

									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 36,
										GROUP_ID: 3,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/3/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/3/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group3_36").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_36")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group3_36").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},
									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 36,
										GROUP_ID: 4,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/4/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/4/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group4_36").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_36")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group4_36").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					}
				];
								newData = JSON.stringify(AufInsertData);
								// Start of AUF insert   
								jQuery.ajax({

									url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUFInsertUpdate.xsjs",
									type: "POST",
									async: false,
									method: 'POST',
									dataType: 'text',
									data: {
										dataObject: newData
									},
									success: function(data) {
										that._AUFMCFCall(that.getView().byId("coverage").getValue(), that.getView().byId("vocation").getValue().toUpperCase(), 36,
											that
											.getView().byId("Torque").getValue().toUpperCase(), that._CountryCode(), parseInt(that._DeductAmnt()), parseInt(that.getView()
												.getModel("local").getData().ViewRatePlan.RATE_PLAN_ID));
									},

									error: function(error) {
										sap.ui.core.BusyIndicator.hide();
									}

								});

								// End of AUF insert  

							},

							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageBox.error(oError.responseText);
							}

						});

					}
				}
			}

		},

		save72: function() {
			if (!this.getView().byId("ForecastMthd72").getSelectedKey()) {

				sap.m.MessageBox.error("Please select Forecast method to be applied");

			} else if ((this.getView().byId("ForecastMthd72").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd72").getSelectedKey() ==
				'QUADRATIC WITH POINTS') && (!this.getView().byId("mininput72").getValue() || !this.getView().byId("maxinput72").getValue())) {

				MessageBox.error("MIN MAX cannot be blank");

			} else {
				if ((this.getView().byId("ForecastMthd72").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd72").getSelectedKey() ==
					'QUADRATIC WITH POINTS') && (this.getView().byId("mininput72").getValue() > this.getView().byId("maxinput72").getValue())) {
					MessageBox.error("MIN should be less than MAX");
				} else { //values fine
					if (this.getView().byId("maxinput72").getValue() && parseInt(this.getView().byId("maxinput72").getValue()) > 72) {
						MessageBox.error("Max Value should be less than term Limit");
					} else {

						sap.ui.core.BusyIndicator.show();
						var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
						var that = this;
						//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
						var newDate = new Date();
						var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
						var currentUser = that.getView().getModel("UserInfo").getData().userName;

						var insertData = {
							RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
							VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
							CVRG_GROUP: this.getView().byId("coverage").getValue(),
							DOMCL_CNTRY_CD_GRP: this._CountryCode(),
							ENGINE_TORQUE: this.getView().byId("Torque").getValue().toUpperCase(),
							DEDUCT_AMT: parseInt(that._DeductAmnt()),
							CVRG_MONTHS: 72,
							MIN_MIS: parseInt(this.getView().byId("mininput72").getValue()),
							MAX_MIS: parseInt(this.getView().byId("maxinput72").getValue()),
							SELECTED_FCST_MTHD: this.getView().byId("ForecastMthd72").getValue().toUpperCase(),
							CREATED_DATE: createdDate,
							CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
							MODIFIED_DATE: currentDate,
							MODIFIED_USER: currentUser
						};

						var newData = JSON.stringify(insertData);
						jQuery.ajax({

							url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
							type: "POST",
							async: false,
							method: 'GET',
							dataType: 'text',
							data: {
								dataObject: newData
							},
							success: function(data) {

								var jsonData = JSON.parse(data);
								that.getView().getModel("local").getData().ViewRatePlan = jsonData[0];
								that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT = jsonData[0].CREATED_DT.split("/")[2] + "-" + jsonData[0].CREATED_DT
									.split("/")[0] + "-" + jsonData[0].CREATED_DT.split("/")[1];
								that.getView().getModel("local").getData().ViewRatePlan.MODIFIED_DT = jsonData[0].MODIFIED_DT.split("/")[2] + "-" + jsonData[0]
									.MODIFIED_DT.split("/")[0] + "-" + jsonData[0].MODIFIED_DT.split("/")[1];
								/*	MessageToast.show("Forecast Saved");
								that._hideFormFragment(that, "EngineChart72months");
								that._GetcostCurveValue("72M");*/
								//MessageToast.show("Forecast Saved");
								//hide the dialog

								//AUF
								/*	var createdDate = that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
						var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
						var newDate = new Date();
						var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
						var currentUser = that.getView().getModel("UserInfo").getData().userName;*/

								var AufInsertData = [{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 72,
										GROUP_ID: 1,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/1/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/1/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group1_72").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_72")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group1_72").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},
									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 72,
										GROUP_ID: 2,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/2/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/2/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group2_72").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_72")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group2_72").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},

									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 72,
										GROUP_ID: 3,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/3/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/3/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group3_72").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_72")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group3_72").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},
									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 72,
										GROUP_ID: 4,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/4/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/4/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group4_72").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_72")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group4_72").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					}
				];
								newData = JSON.stringify(AufInsertData);
								// Start of AUF insert   
								jQuery.ajax({

									url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUFInsertUpdate.xsjs",
									type: "POST",
									async: false,
									method: 'POST',
									dataType: 'text',
									data: {
										dataObject: newData
									},
									success: function(data) {
										that._AUFMCFCall(that.getView().byId("coverage").getValue(), that.getView().byId("vocation").getValue().toUpperCase(), 72,
											that
											.getView().byId("Torque").getValue().toUpperCase(), that._CountryCode(), parseInt(that._DeductAmnt()), parseInt(that.getView()
												.getModel("local").getData().ViewRatePlan.RATE_PLAN_ID));
									},

									error: function(error) {
										sap.ui.core.BusyIndicator.hide();
									}

								});

								// End of AUF insert  

							},

							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageBox.error(oError.responseText);
							}

						});

					}
				}
			}

		},

		save48: function() {
			if (!this.getView().byId("ForecastMthd48").getSelectedKey()) {

				sap.m.MessageBox.error("Please select Forecast method to be applied");

			} else if ((this.getView().byId("ForecastMthd48").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd48").getSelectedKey() ==
				'QUADRATIC WITH POINTS') && (!this.getView().byId("mininput48").getValue() || !this.getView().byId("maxinput48").getValue())) {

				MessageBox.error("MIN MAX cannot be blank");

			} else {
				if ((this.getView().byId("ForecastMthd48").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd48").getSelectedKey() ==
					'QUADRATIC WITH POINTS') && (this.getView().byId("mininput48").getValue() > this.getView().byId("maxinput48").getValue())) {
					MessageBox.error("MIN should be less than MAX");
				} else { //values fine
					if (this.getView().byId("maxinput48").getValue() && parseInt(this.getView().byId("maxinput48").getValue()) > 48) {
						MessageBox.error("Max Value should be less than term Limit");
					} else {
						sap.ui.core.BusyIndicator.show();
						var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
						var that = this;
						var newDate = new Date();
						var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
						var currentUser = that.getView().getModel("UserInfo").getData().userName;
						//var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];

						var insertData = {
							RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
							VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
							CVRG_GROUP: this.getView().byId("coverage").getValue(),
							DOMCL_CNTRY_CD_GRP: this._CountryCode(),
							ENGINE_TORQUE: this.getView().byId("Torque").getValue().toUpperCase(),
							DEDUCT_AMT: parseInt(that._DeductAmnt()),
							CVRG_MONTHS: 48,
							MIN_MIS: parseInt(this.getView().byId("mininput48").getValue()),
							MAX_MIS: parseInt(this.getView().byId("maxinput48").getValue()),
							SELECTED_FCST_MTHD: this.getView().byId("ForecastMthd48").getValue().toUpperCase(),
							CREATED_DATE: createdDate,
							CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
							MODIFIED_DATE: currentDate,
							MODIFIED_USER: currentUser
						};

						var newData = JSON.stringify(insertData);
						jQuery.ajax({

							url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
							type: "POST",
							async: false,
							method: 'GET',
							dataType: 'text',
							data: {
								dataObject: newData
							},
							success: function(data) {

								var jsonData = JSON.parse(data);
								that.getView().getModel("local").getData().ViewRatePlan = jsonData[0];
								that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT = jsonData[0].CREATED_DT.split("/")[2] + "-" + jsonData[0].CREATED_DT
									.split("/")[0] + "-" + jsonData[0].CREATED_DT.split("/")[1];
								that.getView().getModel("local").getData().ViewRatePlan.MODIFIED_DT = jsonData[0].MODIFIED_DT.split("/")[2] + "-" + jsonData[0]
									.MODIFIED_DT.split("/")[0] + "-" + jsonData[0].MODIFIED_DT.split("/")[1];
								/*	MessageToast.show("Forecast Saved");
								that._hideFormFragment(that, "EngineChart48months");
								that._GetcostCurveValue("48M");*/
								//AUF
								/*	var createdDate = that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
						var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
						var newDate = new Date();
						var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
						var currentUser = that.getView().getModel("UserInfo").getData().userName;
*/
								var AufInsertData = [{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 48,
										GROUP_ID: 1,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/1/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/1/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group1_48").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_48")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group1_48").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},
									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 48,
										GROUP_ID: 2,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/2/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/2/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group2_48").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_48")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group2_48").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},

									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 48,
										GROUP_ID: 3,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/3/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/3/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group3_48").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_48")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group3_48").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},
									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 48,
										GROUP_ID: 4,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/4/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/4/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group4_48").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_48")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group4_48").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					}
				];
								newData = JSON.stringify(AufInsertData);
								// Start of AUF insert   
								jQuery.ajax({

									url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUFInsertUpdate.xsjs",
									type: "POST",
									async: false,
									method: 'POST',
									dataType: 'text',
									data: {
										dataObject: newData
									},
									success: function(data) {
										that._AUFMCFCall(that.getView().byId("coverage").getValue(), that.getView().byId("vocation").getValue().toUpperCase(), 48,
											that
											.getView().byId("Torque").getValue().toUpperCase(), that._CountryCode(), parseInt(that._DeductAmnt()), parseInt(that.getView()
												.getModel("local").getData().ViewRatePlan.RATE_PLAN_ID));
									},

									error: function(error) {
										sap.ui.core.BusyIndicator.hide();
									}

								});

								// End of AUF insert 
							},

							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageBox.error(oError.responseText);
							}

						});

					}
				}
			}

		},

		save60: function() {
			if (!this.getView().byId("ForecastMthd60").getSelectedKey()) {

				sap.m.MessageBox.error("Please select Forecast method to be applied");

			} else if ((this.getView().byId("ForecastMthd60").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd60").getSelectedKey() ==
				'QUADRATIC WITH POINTS') && (!this.getView().byId("mininput60").getValue() || !this.getView().byId("maxinput60").getValue())) {

				MessageBox.error("MIN MAX cannot be blank");

			} else {
				if ((this.getView().byId("ForecastMthd60").getSelectedKey() == 'LINEAR' || this.getView().byId("ForecastMthd60").getSelectedKey() ==
					'QUADRATIC WITH POINTS') && (this.getView().byId("mininput60").getValue() > this.getView().byId("maxinput60").getValue())) {
					MessageBox.error("MIN should be less than MAX");
				} else { //values fine
					if (this.getView().byId("maxinput60").getValue() && parseInt(this.getView().byId("maxinput60").getValue()) > 60) {
						MessageBox.error("Max Value should be less than term Limit");
					} else {
						sap.ui.core.BusyIndicator.show();
						var createdDate = this.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
						var that = this;
						var newDate = new Date();
						var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
						var currentUser = that.getView().getModel("UserInfo").getData().userName;

						var insertData = {
							RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
							VOC_CATEGORY_GRP: this.getView().byId("vocation").getValue().toUpperCase(),
							CVRG_GROUP: this.getView().byId("coverage").getValue(),
							DOMCL_CNTRY_CD_GRP: this._CountryCode(),
							ENGINE_TORQUE: this.getView().byId("Torque").getValue().toUpperCase(),
							DEDUCT_AMT: parseInt(that._DeductAmnt()),
							CVRG_MONTHS: 60,
							MIN_MIS: parseInt(this.getView().byId("mininput60").getValue()),
							MAX_MIS: parseInt(this.getView().byId("maxinput60").getValue()),
							SELECTED_FCST_MTHD: this.getView().byId("ForecastMthd60").getValue().toUpperCase(),
							CREATED_DATE: createdDate,
							CREATED_USER: this.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
							MODIFIED_DATE: currentDate,
							MODIFIED_USER: currentUser
						};

						var newData = JSON.stringify(insertData);
						jQuery.ajax({

							url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/CostCurveInsertUpdate.xsjs",
							type: "POST",
							async: false,
							method: 'GET',
							dataType: 'text',
							data: {
								dataObject: newData
							},
							success: function(data) {
								var jsonData = JSON.parse(data);
								that.getView().getModel("local").getData().ViewRatePlan = jsonData[0];
								that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT = jsonData[0].CREATED_DT.split("/")[2] + "-" + jsonData[0].CREATED_DT
									.split("/")[0] + "-" + jsonData[0].CREATED_DT.split("/")[1];
								that.getView().getModel("local").getData().ViewRatePlan.MODIFIED_DT = jsonData[0].MODIFIED_DT.split("/")[2] + "-" + jsonData[0]
									.MODIFIED_DT.split("/")[0] + "-" + jsonData[0].MODIFIED_DT.split("/")[1];
								/*MessageToast.show("Forecast Saved");
								that._hideFormFragment(that, "EngineChart60months");
								that._GetcostCurveValue("60M");*/
								//AUF
								/*	var createdDate = that.getView().getModel("local").getData().ViewRatePlan.CREATED_DT;
						var formatedDate = createdDate.split("/")[2] + "-" + createdDate.split("/")[0] + "-" + createdDate.split("/")[1];
						var newDate = new Date();
						var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
						var currentUser = that.getView().getModel("UserInfo").getData().userName;
*/
								var AufInsertData = [{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 60,
										GROUP_ID: 1,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/1/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/1/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group1_60").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group1_60")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group1_60").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},
									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 60,
										GROUP_ID: 2,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/2/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/2/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group2_60").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group2_60")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group2_60").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},

									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 60,
										GROUP_ID: 3,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/3/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/3/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group3_60").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group3_60")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group3_60").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					},
									{
										RATE_PLAN_ID: parseInt(that.getView().getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
										VOC_CATEGORY_GRP: that.getView().byId("vocation").getValue().toUpperCase(),
										CVRG_GROUP: that.getView().byId("coverage").getValue(),
										DOMCL_CNTRY_CD_GRP: that._CountryCode(),
										ENGINE_TORQUE: that.getView().byId("Torque").getValue().toUpperCase(),
										DEDUCT_AMT: parseInt(that._DeductAmnt()),
										CVRG_MONTHS: 60,
										GROUP_ID: 4,
										EW_UNITS: parseInt(that.getView().getModel("local").getProperty("/AUFValue/4/EW_UNITS")),
										AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/4/ACCELERATED_USAGE_FACTOR")),
										SELECTED_GROUP_ID: parseInt(that.getView().byId("group4_60").getSelectedKey()),
										CREATED_DATE: createdDate,
										CREATED_USER: that.getView().getModel("local").getData().ViewRatePlan.CREATED_USER,
										MODIFIED_DATE: currentDate,
										MODIFIED_USER: currentUser,
										SELECTED_AUF_FACTOR: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId("group4_60")
											.getSelectedKey() +
											"/ACCELERATED_USAGE_FACTOR")),
										AVG_CONTRACTUAL_MILES: parseFloat(that.getView().getModel("local").getProperty("/AUFValue/" + that.getView().byId(
												"group4_60").getSelectedKey() +
											"/AVG_CONTRACTUAL_MILES"))

					}
				];
								newData = JSON.stringify(AufInsertData);
								// Start of AUF insert   
								jQuery.ajax({

									url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUFInsertUpdate.xsjs",
									type: "POST",
									async: false,
									method: 'POST',
									dataType: 'text',
									data: {
										dataObject: newData
									},
									success: function(data) {
										that._AUFMCFCall(that.getView().byId("coverage").getValue(), that.getView().byId("vocation").getValue().toUpperCase(), 60,
											that
											.getView().byId("Torque").getValue().toUpperCase(), that._CountryCode(), parseInt(that._DeductAmnt()), parseInt(that.getView()
												.getModel("local").getData().ViewRatePlan.RATE_PLAN_ID));
									},

									error: function(error) {
										sap.ui.core.BusyIndicator.hide();
									}

								});

								// End of AUF insert  

							},

							error: function(oError) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageBox.error(oError.responseText);

							}

						});

					}
				}

			}
		},
		_GetcostCurveValue: function(month) {
			sap.ui.core.BusyIndicator.show();
			var that = this;

			var mParameters = {

				success: function(oData) {
					sap.ui.core.BusyIndicator.hide();

					if (month == "72M") {
						that.getView().getModel("local").getData().costcurve72 = oData.results;
					} else if (month == "36M") {
						that.getView().getModel("local").getData().costcurve36 = oData.results;

					} else if (month == "48M") {
						that.getView().getModel("local").getData().costcurve48 = oData.results;

					} else if (month == "60M") {
						that.getView().getModel("local").getData().costcurve60 = oData.results;

					}
				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageBox.error(oError.responseText);

				}

			};

			this.getOwnerComponent().getModel().read(
				"/CV_COST_CURVE_FINALParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" +
				"'" +
				that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
					"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
					"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=" + month + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel("local")
				.getProperty(
					"/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
					"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE='" + that.getView().byId("Torque").getValue().toUpperCase() +
				"'," + "parDOMCL_CNTRY_CD=" + "'" + that._CountryCode() + "'," + "parDEDUCT_AMT=" + that._DeductAmnt() + "," + "parRATE_PLAN_ID=" +
				that.getView().getModel("local").getProperty(
					"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute",
				mParameters);

		},

		_GetMilegeData: function(month) {
			var that = this
			that.getView().getModel("local").getData().Milege = [];
			that.getView().byId("milege" + month).setBusy(true);
			var mParameters = {

				success: function(oData) {
					that.getView().byId("milege" + month).setBusy(false);
					that.getView().getModel("local").getData().Milege = oData.results;
				},
				error: function(oError) {
					that.getView().byId("milege" + month).setBusy(false);
					sap.m.MessageBox.error(oError.responseText);

				}

			};

			that.getOwnerComponent().getModel().read(
				"/CVRG_UNITSParameters(parCVRG_GROUP=" + "'" + that.getView().byId("coverage").getValue() + "'," + "parPRD_TYP_CD=" +
				"'" +
				that.getView().getModel("local").getProperty("/ViewRatePlan/PORTFOLIO_NAME") + "'," + "parVOC_CATEGORY=" + "'" + that.getView().byId(
					"vocation").getValue().toUpperCase() + "'," + "parIN_SRVC_YR=" + that.getView().getModel("local").getProperty(
					"/ViewRatePlan/BASELINE_YEAR") + "," + "parCVRG_MONTHS=" + month + "," + "parPRODUCT_TYPE=" + "'" + that.getView().getModel("local")
				.getProperty("/ViewRatePlan/PRODUCT_TYPE") + "'," + "parDATE=datetime" + "'" + that.getView().getModel("local").getProperty(
					"/NewRatePlan/RATE_PLAN_CUTOFF_DT") + "'," + "parTORQUE='" + that.getView().byId("Torque").getValue().toUpperCase() +
				"'," + "parDOMCL_CNTRY_CD=" + "'" + that._CountryCode() + "'," + "parDEDUCT_AMT=" +
				that._DeductAmnt() + ")/Execute", mParameters);

		},

		_CountryCode: function() {
			var countrygrp;
			if (this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen === 1) {

				countrygrp = this.getView().byId("domicile").getSelectedItem().getKey();

			} else if (this.getView().byId("domicile").getSelectedItem()) {

				countrygrp = this.getView().byId("domicile").getSelectedItem().getKey();

			} else {

				countrygrp = this.getView().byId("domicile").getValue().toUpperCase();
			}

			return countrygrp;

		},

		_DeductAmnt: function() {
			var deductamnt;
			if (this.getView().getModel("local").getData().rateplanvisibility.createRatePlanScreen === 1) {

				deductamnt = parseInt(this.getView().byId("Deductible").getSelectedKey());

			} else if (this.getView().byId("Deductible").getSelectedItem()) {

				deductamnt = parseInt(this.getView().byId("Deductible").getSelectedKey());

			} else {
				deductamnt = parseInt(this.getView().byId("Deductible").getValue());

			}

			return deductamnt;

		},

		ForecastStatus: function() {

			var that = this;
			that.getView().getModel("local").getData().CostCurveStatus = [];

			that._showFormFragment(this.getView(), "CostCurveEngineStatus");

			var mParameters = {

				success: function(oData) {
					that.getView().getModel("local").getData().CostCurveStatus = oData.results;

				},
				error: function(oError) {

				}

			};

			that.getOwnerComponent().getModel().read("/CV_COST_CURVE_STATUSParameters(Par_RATE_PLAN_ID=" + that.getView().getModel("local").getProperty(
				"/ViewRatePlan/RATE_PLAN_ID") + ")/Execute", mParameters);

		},
		_AUFMCFCall: function(cvrgGroup, vocation, cvrgMonth, torque, domicile, deductAmt, ratePlanId) {
			var that = this;
			/*/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUF_MCF_Procedure_Call.xsjs?cvrgGroup=EXTENDED BASIC VEHICLE&vocation=STANDARD&cvrgMonth=24&torque=
		    &domicile=USA AND CAN&deductAmt=0&ratePlanId=5555*/
			var serviceUrl = '/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/AUF_MCF_Procedure_Call.xsjs?cvrgGroup=' + cvrgGroup +
				'&vocation=' + vocation + '&cvrgMonth=' + cvrgMonth + '&torque=' + torque + '&domicile=' + domicile + '&deductAmt=' + deductAmt +
				'&ratePlanId=' + ratePlanId;
			jQuery.ajax({

				url: serviceUrl,
				type: "POST",
				async: true,
				method: 'GET',
				success: function(data) {

					//alert("success");
					that._GetcostCurveValue(cvrgMonth + "M");

					that._hideFormFragment(that, "EngineChart" + cvrgMonth + "months");

					sap.m.MessageBox.success("Cost Curve updates have been saved successfully", {

						actions: [sap.m.MessageBox.Action.CLOSE],

						contentWidth: "100px"

					});
					sap.ui.core.BusyIndicator.hide();
					//	sap.ui.core.BusyIndicator.hide();

				},

				error: function(error) {
					sap.ui.core.BusyIndicator.hide();

				}

			});

		},

			Reference36: function() {

			var RplCoverageMonth;
			var CvrgMonth = 36;
			var minMis;
			var maxMis;
			var selectedForecastMethod;
		

			if (this.getView().byId("Enginecopy36").getValue() == "72 Months") {

				RplCoverageMonth = 72;
				minMis = this.getView().getModel("local").getData().costcurve72[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve72[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan72.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("Enginecopy36").getValue() == "48 Months") {

				RplCoverageMonth = 48;
				minMis = this.getView().getModel("local").getData().costcurve48[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve48[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan48.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("Enginecopy36").getValue() == "60 Months") {

				RplCoverageMonth = 60;
				minMis = this.getView().getModel("local").getData().costcurve60[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve60[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan60.SELECTED_FCST_MTHD;
			}

			this._ReferenceMonthInsert(RplCoverageMonth, CvrgMonth, minMis, maxMis, selectedForecastMethod);
		},

		Reference48: function() {

			var RplCoverageMonth;
			var CvrgMonth = 48;
			var minMis;
			var maxMis;
			
			var selectedForecastMethod;  
			

			if (this.getView().byId("Enginecopy48").getValue() == "36 Months") {

				RplCoverageMonth = 36;
				minMis = this.getView().getModel("local").getData().costcurve36[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve36[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan36.SELECTED_FCST_MTHD;

			}

			if (this.getView().byId("Enginecopy48").getValue() == "72 Months") {

				RplCoverageMonth = 72;
				minMis = this.getView().getModel("local").getData().costcurve72[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve72[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan72.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("Enginecopy48").getValue() == "60 Months") {

				RplCoverageMonth = 60;
				minMis = this.getView().getModel("local").getData().costcurve60[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve60[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan60.SELECTED_FCST_MTHD;
			}

			this._ReferenceMonthInsert(RplCoverageMonth, CvrgMonth, minMis, maxMis, selectedForecastMethod);
		},

		Reference60: function() {

			var RplCoverageMonth;
			var CvrgMonth = 60;
			var minMis;
			var maxMis;
			var selectedForecastMethod;
			

			if (this.getView().byId("Enginecopy60").getValue() == "36 Months") {

				RplCoverageMonth = 36;
				minMis = this.getView().getModel("local").getData().costcurve36[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve36[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan36.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("Enginecopy60").getValue() == "72 Months") {

				RplCoverageMonth = 24;
				minMis = this.getView().getModel("local").getData().costcurve72[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve72[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan72.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("Enginecopy60").getValue() == "48 Months") {

				RplCoverageMonth = 48;
				minMis = this.getView().getModel("local").getData().costcurve48[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve48[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan48.SELECTED_FCST_MTHD;
			}

			this._ReferenceMonthInsert(RplCoverageMonth, CvrgMonth, minMis, maxMis, selectedForecastMethod);
		},
		Reference72: function() {

			var RplCoverageMonth;
			var CvrgMonth = 72;
			var minMis;
			var maxMis;
			var selectedForecastMethod;
			

			if (this.getView().byId("Enginecopy72").getValue() == "36 Months") {

				RplCoverageMonth = 36;
				minMis = this.getView().getModel("local").getData().costcurve36[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve36[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan36.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("Enginecopy72").getValue() == "60 Months") {

				RplCoverageMonth = 60;
				minMis = this.getView().getModel("local").getData().costcurve60[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve60[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan60.SELECTED_FCST_MTHD;
			}

			if (this.getView().byId("Enginecopy72").getValue() == "48 Months") {

				RplCoverageMonth = 48;
				minMis = this.getView().getModel("local").getData().costcurve48[0].MIN_MIS;
				maxMis = this.getView().getModel("local").getData().costcurve48[0].MAX_MIS;
				selectedForecastMethod = this.getView().getModel("local").getData().CostCurveViewRatePlan48.SELECTED_FCST_MTHD;
			}

			this._ReferenceMonthInsert(RplCoverageMonth, CvrgMonth, minMis, maxMis, selectedForecastMethod);
		},
		_ReferenceMonthInsert: function(RplCoverageMonth, CvrgMonth, minMis, maxMis, selectedForecastMethod) {
			var dialog = this.getView().byId("Reference");
			var that = this;
			var newData;
			var view = this.getView();

			if (!dialog) {
				dialog = new Dialog({
					id: "Reference",
					title: 'Confirm',
					type: 'Message',
					content: new Text({
						text: "Are you sure you want " +  CvrgMonth + " Month Cost Curve to be based on " + RplCoverageMonth + " Month data ?"
					}),
					beginButton: new Button({
						text: 'Yes',
						press: function(oEvent) {
							var newDate = new Date();
							var currentDate = newDate.getFullYear() + "-" + (newDate.getMonth() + 1) + "-" + newDate.getDate();
							var currentUser = view.getModel("UserInfo").getData().userName;

							var referenceInsertData = {
								RATE_PLAN_ID: parseInt(view.getModel("local").getData().ViewRatePlan.RATE_PLAN_ID),
								VOC_CATEGORY_GRP: view.byId("vocation").getValue().toUpperCase(),
								CVRG_GROUP: view.byId("coverage").getValue(),
								DOMCL_CNTRY_CD_GRP: that._CountryCode(),
								ENGINE_TORQUE: view.byId("Torque").getValue().toUpperCase(),
								DEDUCT_AMT: parseInt(that._DeductAmnt()),
								MIN_MIS: parseInt(minMis),
								MAX_MIS: parseInt(maxMis),
                                SELECTED_FCST_MTHD: selectedForecastMethod,
								CVRG_MONTHS: CvrgMonth,
								REPL_CVRG_MONTHS: RplCoverageMonth,
								CREATED_DATE: view.getModel("local").getData().ViewRatePlan.CREATED_DT,
								CREATED_USER: view.getModel("local").getData().ViewRatePlan.CREATED_USER,
								MODIFIED_DATE: currentDate,
								MODIFIED_USER: view.getModel("UserInfo").getData().userName

							}
							var newData = JSON.stringify(referenceInsertData);

							// ajax call  to insert Reference term the rateplan ID
							jQuery.ajax({

								url: "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/Referenceterm.xsjs",
								type: "POST",
								async: false,
								method: 'GET',
								dataType: 'text',
								data: {
									dataObject: newData
								},
								success: function(data) {
								    sap.ui.core.BusyIndicator.show();
								    that._AUFMCFCall(that.getView().byId("coverage").getValue(), that.getView().byId("vocation").getValue().toUpperCase(), CvrgMonth,
											that.getView().byId("Torque").getValue().toUpperCase(), that._CountryCode(), parseInt(that._DeductAmnt()), parseInt(that.getView()
												.getModel("local").getData().ViewRatePlan.RATE_PLAN_ID))

								/*	sap.m.MessageBox.show(+ CvrgMonth + "Month copied from " + RplCoverageMonth + " Successfully", {
										icon: sap.m.MessageBox.Icon.SUCCESS,
										title: "Success",
										actions: [sap.m.MessageBox.Action.CLOSE],

										contentWidth: "100px"

									});*/

								},
								error: function(oError) {
									sap.m.MessageBox.error(oError.responseText);
								}
							});
							//close the dialog
							dialog.close();

						}
					}),
					endButton: new Button({
						text: 'No',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				this.getView().addDependent(dialog);
			}

			dialog.open();

		}

	});
});
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"DtnaAspRP_ss/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("DtnaAspRP_ss.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			// initializing the Router
			this.getRouter().initialize();
			var sServiceUrl = "/DTNA_PRD/Aftermarket/ASP/SS_Views/Costing/WebServices/ASPRATEPLAN.xsodata";
			this._initODataModel(sServiceUrl);

			//logged in user
			var loggedInUser = "";
			var UserModel;

			// Check the session user using SAP's provided xsjs
			jQuery.ajax({
				url: "/sap/hana/xs/formLogin/checkSession.xsjs",
				type: "GET",
				async: false,
				beforeSend: function(request) {
					request.setRequestHeader("X-CSRF-Token", "Fetch");
				},
				success: jQuery.proxy(function(data, textStatus, XMLHttpRequest) {
					if (data) {
						loggedInUser = data.username;
					}
				}, this)
			});
			UserModel = new sap.ui.model.json.JSONModel({
				"userName": loggedInUser
			});
			this.setModel(UserModel, "UserInfo");
		},

		_initODataModel: function(sServiceUrl) {

			var config = {
				metadataUrlParams: {},
				json: true,
				defaultBindingMode: "TwoWay",
				defaultCountMode: "Inline",
				useBatch: false
			};

			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, config);
			this.setModel(oModel);

		}
	});
});
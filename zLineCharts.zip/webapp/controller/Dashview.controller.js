sap.ui.define([
        'jquery.sap.global',
        'sap/ui/core/mvc/Controller',
        'sap/ui/model/json/JSONModel',
        'sap/viz/ui5/data/FlattenedDataset',
        'sap/viz/ui5/format/ChartFormatter',
        'sap/viz/ui5/api/env/Format',
         './InitPage'
    ], function(jQuery, Controller, JSONModel, FlattenedDataset, ChartFormatter, Format,InitPageUtil) {
    "use strict";
    
     Controller = Controller.extend("com.chartszLineCharts.controller.Dashview", {
        onInit : function (evt) {
            this.myFunc();
               InitPageUtil.initPageSettings(this.getView());
        },
        
        getChartData : function(range){
        	 var dataModel = new JSONModel();
        	 dataModel.loadData("./model/data.json","",false);
        	 var data = dataModel.getProperty("/data");
        	 var finalData = [];
        	 var total = data.length;
        	 var step = parseInt(total / range,10) * 4;
        	var stepObj={"60":4,"48":3,"36":3,"24":2};
        	 var i = total - 1;
        	 var minVal = range;
        	 var count = 0;
        	while(i >= 0){
        			finalData.push(data[i]);
        			count ++;
        			i--;
        			if(count >= range){
        				break;
        			}
        	}
        	 
        	 
        	 return finalData.reverse();
        	 
        },
        myFunc : function(){
        	 var monthCounter = this.getView().byId("monthCount");
        	 var monthCount = 24;
        	
        	 if(monthCounter){
        	 	monthCount = monthCounter.getSelectedKey();
        	 }
        	 var chartTitle = monthCount + " Month Data";
    		var monthData =	 this.getChartData(monthCount);
    		console.log(monthData);
        			var PPChart=this.getView().byId("idVizFrame");
        				 var dataModel = new JSONModel();
        				 dataModel.setData({data:monthData});
            PPChart.setModel(dataModel);
		
			PPChart.setUiConfig({
				"applicationSet": "fiori"
			});
			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					axis: 1,
					name: 'Month',
					value: '{Month}'
				}],
				measures: [{
					name: 'Base_Line_2015',
					value: '{Base_Line_2015}'
				},{
					name: 'Cost_Per_Unit_2016',
					value: '{Cost_Per_Unit_2016}'
				},{
					name: 'Cost_Per_Unit_2017',
					value: '{Cost_Per_Unit_2017}'
				},{
					name: 'Cost_Per_Unit_2018',
					value: '{Cost_Per_Unit_2018}'
				}],
				data: {
					path: '/data'
						// Filter: "oFilters"
				}
			});
			PPChart.setDataset(oDataset);

			var valueFeed = new sap.viz.ui5.controls.common.feeds.FeedItem({
					uid: "size",
					'type': "Measure",
					'values': ["Base_Line_2015","Cost_Per_Unit_2016","Cost_Per_Unit_2017","Cost_Per_Unit_2018"]
				});
			PPChart.addFeed(valueFeed);
		//	PPChart.addFeed(categoryFeed);
			PPChart.setVizProperties({
				dataLabel: {
                    visible: true
                },
				legend: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text : chartTitle
				},
				valueAxis: {

					title: {
						visible: true,
						text: "2015 BaseLine Cost" //Add custom title to Value Axis  
					}
				}
			});	
        },
        onAfterRendering : function(){
           /* var datasetRadioGroup = this.getView().byId('datasetRadioGroup');
            datasetRadioGroup.setSelectedIndex(this.settingsModel.dataset.defaultSelected);
            
            var seriesRadioGroup = this.getView().byId('seriesRadioGroup');
            seriesRadioGroup.setSelectedIndex(this.settingsModel.series.defaultSelected);*/
        },
        onDatasetSelected : function(oEvent){
            var datasetRadio = oEvent.getSource();
            if(this.oVizFrame && datasetRadio.getSelected()){
                var bindValue = datasetRadio.getBindingContext().getObject();
                var dataset = {
                    data: {
                        path: "/milk"
                    }
                };
                var dim = this.settingsModel.dimensions[bindValue.name];
                dataset.dimensions = dim;
                dataset.measures = this.settingsModel.measures;
                var oDataset = new FlattenedDataset(dataset);
                this.oVizFrame.setDataset(oDataset);
                var dataModel = new JSONModel(this.dataPath + bindValue.value);
                this.oVizFrame.setModel(dataModel);

                var feedCategoryAxis = this.getView().byId('categoryAxisFeed');
                this.oVizFrame.removeFeed(feedCategoryAxis);
                var feed = [];
                for (var i = 0; i < dim.length; i++) {
                    feed.push(dim[i].name);
                }
                feedCategoryAxis.setValues(feed);
                this.oVizFrame.addFeed(feedCategoryAxis);
            }
        },
        onSeriesSelected : function(oEvent){
            var seriesRadio = oEvent.getSource();
            if(this.oVizFrame && seriesRadio.getSelected()){
                var bindValue = seriesRadio.getBindingContext().getObject();
                
                var feedValueAxis = this.getView().byId('valueAxisFeed');
                this.oVizFrame.removeFeed(feedValueAxis);
                feedValueAxis.setValues(bindValue.value);
                this.oVizFrame.addFeed(feedValueAxis);
            }
        },
        onDataLabelChanged : function(oEvent){
            if(this.oVizFrame){
                this.oVizFrame.setVizProperties({
                    plotArea: {
                        dataLabel: {
                            visible: oEvent.getParameter('state')
                        }
                    }
                });
            }
        },
        onAxisTitleChanged : function(oEvent){
            if(this.oVizFrame){
                var state = oEvent.getParameter('state');
                this.oVizFrame.setVizProperties({
                    valueAxis: {
                        title: {
                            visible: state
                        }
                    },
                    categoryAxis: {
                        title: {
                            visible: state
                        }
                    }
                });
            }
        }
    }); 
 
    return Controller;
 
});